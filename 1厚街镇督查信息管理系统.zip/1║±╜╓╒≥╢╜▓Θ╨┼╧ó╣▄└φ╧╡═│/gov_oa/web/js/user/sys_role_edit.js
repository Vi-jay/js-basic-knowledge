/**
 * @author 谭文广
 */
$(document).ready(function(){
	/**为页面指定提交按钮注册是否倒计时事件*/
	Utils.submitCountDown();
	
	$("form#edit_form").validate({
		rules : {
			"formMap[dept_id]" : {required : true},
			"formMap[role_name]" : {required : true},
			"formMap[role_index]" : {required : true,digits : true},
			"formMap[role_code]" : {required : true}
		},
		messages : {
			"formMap[dept_id]" : {required : ""},
			"formMap[role_name]" : {required : ""},
			"formMap[role_index]" : {required : "",digits : "格式有误"},
			"formMap[role_code]" : {required : ""}
		}
	});
	
});


/**验证角色编码*/
function verificationRoleCode(val){
	$("#font_tip").hide();
	if(val && val != ""){
		var role_id = $("#role_id_hidden").val();
		$.post("/pc/role/verificationRoleCode",{"formMap[role_code]":val,"formMap[role_id]":role_id},function(data){
			if(data.result == "Y"){
				$("input[name='formMap[role_code]']").val("");
				$("#font_tip").show();
			}else{
				$("#font_tip").hide();
			}
		},"json");
	}
}