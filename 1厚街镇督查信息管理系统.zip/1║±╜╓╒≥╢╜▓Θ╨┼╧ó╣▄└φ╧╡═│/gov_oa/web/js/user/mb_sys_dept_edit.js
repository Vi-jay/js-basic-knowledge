/**
 * @author 谭文广
 */
$(document).ready(function(){
	/**为页面指定提交按钮注册是否倒计时事件*/
	Utils.submitCountDown();
	
	$("form#edit_form").validate({
		rules : {
			"formMap[dept_name]" : {required : true},
			"formMap[dept_sort]" : {required : true,digits : true},
			"formMap[dept_code]" : {required : true}
		},
		messages : {
			"formMap[dept_name]" : {required : ""},
			"formMap[dept_sort]" : {required : "",digits : "格式有误"},
			"formMap[dept_code]" : {required : ""}
		}
	});
	
});
