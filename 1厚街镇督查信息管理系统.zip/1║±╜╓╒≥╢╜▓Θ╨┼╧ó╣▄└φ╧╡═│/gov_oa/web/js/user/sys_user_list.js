/**
 * @author 谭文广
 */
$(document).ready(function(){
	/**注册全选、反选事件*/
	Utils.selectCheckbox();
	
	/**为页面指定按钮注册是否已经选择数据事件*/
	Utils.verifySelection();
	
	/**为页面按钮添加单数据操作提示*/
	Utils.singleDataOperate();
	
});


function modifyPwd(uid){
	art.dialog.confirm("确定重置密码？", function () {
		art.dialog({
		    content: '&emsp;&emsp;密码：<input type="password" id="password" style="height: 20px;" maxlength="30"/><br/>'+
		    	'<font color="red" style="font-size:12px;padding-left: 65px;">密码长度不少于6位</font><br/>'+
		    	'确认密码：<input type="password" id="confirm_password" style="height: 20px;" maxlength="30"/>',
		    title:'重置密码',fixed: true,id: 'Fm7',okVal: '确认',
		    ok: function () {
		    	var flag = true;
		    	var password = $("#password").val();
		    	password = $.trim(password);
		    	var confirm_password = $("#confirm_password").val();
		    	confirm_password = $.trim(confirm_password);
		    	if(password == "" || confirm_password == ""){
		    		art.dialog.tips("信息不能为空");
		    		flag = false;
		    		return false;
		    	}
		    	if(password.length < 6){
		    		art.dialog.tips("密码长度不少于6位");
		    		flag = false;
		    		return false;
		    	}
		    	if(password != confirm_password){
		    		art.dialog.tips("两次密码不一致");
		    		flag = false;
		    		return false;
		    	}
		    	if(flag){
		    		$.post('/pc/user/modifyPwd',{"formMap[user_id]":uid,"formMap[password]":password,"formMap[confirm_password]":confirm_password},function(data){
		    			if(data.result == "Y"){
		    				art.dialog.tips("密码重置成功");
		    			}else{
		    				art.dialog.tips("信息填写有误，请重新输入");
		    				return false;
		    			}
		    		},"json");
		    	}
//		    	if(password && password != "" && confirm_password && confirm_password != ""){//非空验证
//					
//		    	}else{
//		    		art.dialog.tips("信息不能为空");
//		    		return false;
//		    	}
		    },
		    cancel: true
		});
	}, function () {
	});
}