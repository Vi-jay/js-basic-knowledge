/**
 * @author twg
 */
$(document).ready(function(){
	/**为页面指定提交按钮注册是否倒计时事件*/
	Utils.submitCountDown();
	
	$("form#edit_form").validate({
		rules : {
			"formMap[sg_name]" : {required : true},
			"formMap[sg_num]" : {required : true},
			"formMap[dept_ids]" : {required : true}
		},
		messages : {
			"formMap[sg_name]" : {required : ""},
			"formMap[sg_num]" : {required : ""},
			"formMap[dept_ids]" : {required : "请选择部门"}
		}
	});
});

if(dgList.length){
	for(index in dgList){
		if(dgList[index].sd_dept_id){
			$("#"+dgList[index].sd_dept_id).attr("checked",true);
		}
	}
}