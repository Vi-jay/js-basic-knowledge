/**
 * @author 谭文广
 */

var setting = {
	data: {
		simpleData: {
			enable: true,
			idKey: "id",
			pIdKey: "pid",
			rootPId: "all"
		}
	},
	check: {
		autoCheckTrigger: true,
		enable: true,
		chkStyle: "checkbox"
	},
	view: {
		showLine: true
	}
};

var zTree;
$(document).ready(function(){
	/**为页面指定提交按钮注册是否倒计时事件*/
	Utils.submitCountDown();
	
	zTree = $.fn.zTree.init($("#tree"), setting, treeNodes);
	for (var j=0;j<menuToRole.length;j++) {
    	var node = zTree.getNodeByParam("check", (menuToRole[j].menuopt_id)+"_check" ,null);
    	if(node){
    		zTree.checkNode(node, true, true);
    	}
    }
});




/**保存分配结果*/
function submitForm(){
	var nodes = zTree.getCheckedNodes(true);
	var str="";
	if(nodes){
		for(var n=0; n<nodes.length; n++){
			if(nodes[n].temp){
				str+=nodes[n].temp+";";
			}
		}
	}
	if(str.length > 0){
		$("input#menuOptIds").val(str);
		if(confirm("是否确定授权？") == true){
			$("#edit_form").submit();
			//alert(str);
		}
	}else{
		alert("请选择菜单");
	}
}
