/**
 * @author 谭文广
 */
$(document).ready(function(){
	/**为页面指定提交按钮注册是否倒计时事件*/
	Utils.submitCountDown();
	
	$("form#edit_form").validate({
		rules : {
			"formMap[join_time]" : {required : true},
			"formMap[password]" : {required : true,minlength : 6},
			"formMap[confirm_password]" : {required : true,minlength : 6,equalTo : "#password"},
			"formMap[real_name]" : {required : true},
			"formMap[mobile_phone]" : {required : true,digits : true,minlength:"11"},
			"formMap[qq]" : {digits : true},
			"formMap[role_id]" : {required : true},
			"formMap[dept_id]" : {required : true},
			"formMap[title_explain]" : {required : true},
			"formMap[user_email]" : {email : true},
			"formMap[month_prize]" : {required : true,digits : true},
			"formMap[sort]" : {required : true,digits : true},
			"formMap[month_deducted]" : {required : true,digits : true}
		},
		messages : {
			"formMap[join_time]" : {required : ""},
			"formMap[password]" : {required : "",minlength : "密码长度必须大于5位"},
			"formMap[confirm_password]" : {required : "",minlength : "两次密码不一致",equalTo : "两次密码不一致"},
			"formMap[real_name]" : {required : ""},
			"formMap[mobile_phone]" : {required : "",digits : "手机号码格式出错",minlength:"手机号码格式出错"},
			"formMap[qq]" : {digits : "QQ号码格式出错"},
			"formMap[role_id]" : {required : "请选择角色"},
			"formMap[dept_id]" : {required : "请选择部门"},
			"formMap[title_explain]" : {required : "请输入职务/职称"},
			"formMap[user_email]" : {email : "格式有误"},
			"formMap[month_prize]" : {required : "",digits : "分值填写出错"},
			"formMap[sort]" : {required : "",digits : "格式有误"},
			"formMap[month_deducted]" : {required : "",digits : "分值填写出错"}
		},
		errorPlacement:function(error,element){}
	});
	
});

/**设置用户基地*/
/*function set_user_seedling_field(obj){
	var role_id = $(obj).attr("id");
	var sf_id = $(obj).attr("sf");
	$("input[sf='"+sf_id+"']").each(function(){
		if(role_id != $(this).attr("id")){
			$(this).attr("checked",false);
		}
	});
}*/


/**验证用户帐号*/
function verificationAccount(val){
	$("#font_tip").hide();
	if(val && val != ""){
		var user_id = $("#user_id_hidden").val();
		$.post("/pc/user/verificationAccount",{"formMap[account]":val,"formMap[user_id]":user_id},function(data){
			if(data.result == "Y"){
				$("input[name='formMap[account]']").val("");
				$("#font_tip").show();
			}else{
				$("#font_tip").hide();
			}
		},"json");
	}
}

/**验证真实姓名唯一性*/
function verificationRealName(val){
	$("#font_tip_real_name").hide();
	if(val && val != ""){
		var user_id = $("#user_id_hidden").val();//当前修改用户ID
		$.post('/pc/judge/fieldRepeat',{"formMap[id]":"user_id","formMap[table]":"mb_sys_user","formMap[con]":"real_name="+val},function(data){
			if(data.result != "N" && user_id != data.id){
				$("input#real_name").val("");
				$("#font_tip_real_name").show();
			}else{
				$("#font_tip_real_name").hide();
			}
		},"json");
	}
}

/**验证用户手机号码*/
function verificationMobilePhone(val){
	$("#font_tip_mobile_phone").hide();
	if(val && val != ""){
		var user_id = $("#user_id_hidden").val();//当前修改用户ID
		$.post('/pc/judge/fieldRepeat',{"formMap[id]":"user_id","formMap[table]":"mb_sys_user","formMap[con]":"mobile_phone="+val},function(data){
			if(data.result != "N" && user_id != data.id){
				$("input#mobile_phone").val("");
				$("#font_tip_mobile_phone").show();
			}else{
				$("#font_tip_mobile_phone").hide();
			}
		},"json");
	}
}


/**提交*/
function toSubmit(){
	if($(":checkbox[name='formMap[role_id]']").val() && $(":checkbox[name='formMap[role_id]']").val() != ""){
		$("#edit_form").submit();
	}else{
		alert("在添加用户前，请先添加角色");
	}
}

if($(":checkbox[name='formMap[role_id]']").val() && $(":checkbox[name='formMap[role_id]']").val() != ""){
}else{
	alert("在添加用户前，请先添加角色");
	window.location.href="/pc/role/entryEdit";
}

if(role_list_json.length){
	for(index in role_list_json){
		if(role_list_json[index].role_id){
			$("#"+role_list_json[index].role_id).attr("checked",true);
		}
	}
}

//if(dept_list_json.length){
//	for(index in dept_list_json){
//		if(dept_list_json[index].dept_id){
//			$("#"+dept_list_json[index].dept_id).attr("checked",true);
//		}
//	}
//}