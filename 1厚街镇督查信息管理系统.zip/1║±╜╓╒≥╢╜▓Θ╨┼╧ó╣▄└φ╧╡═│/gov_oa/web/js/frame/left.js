/**
 * @author 谭文广
 */
$(document).ready(function(){
	$(".m_group").click(function(){
		changeMenu($(this).attr("id"));
		var first_second_menu = $("a[MARK='"+$(this).attr("id")+"']").first();
		toPage(first_second_menu,first_second_menu.attr("url"));
	});
});

/**切换菜单显示*/
function changeMenu(id){
	$("ul").hide();
	$("ul#"+id+"_ul").show();
	$("ul#first_ul").show();
}

/**默认打开第一个二级菜单*/
//toPage($("#second_menu").first(),$("#second_menu").first().attr("url"));