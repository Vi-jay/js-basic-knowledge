$.post("/pc/depttask/unitTaskByPageCount",{"formMap[task_status]":$("#search_task_status").val()},function(data){
	$("[VM_VALUE='A']").html("主办任务（"+data.A+"）");
	$("[VM_VALUE='B']").html("协办任务（"+data.B+"）");
},"json");

/**查看任务详情*/
function view_report_detail(url){
	window.open(url);
}