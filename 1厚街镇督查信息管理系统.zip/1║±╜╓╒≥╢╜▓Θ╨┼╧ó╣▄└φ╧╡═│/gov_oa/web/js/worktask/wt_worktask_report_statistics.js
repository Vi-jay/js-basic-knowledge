var LODOP;
function table(id){
	LODOP=getLodop();
	LODOP.PRINT_INIT("报表");//首先一个初始化语句
	LODOP.SET_PRINT_PAGESIZE(1,"21.1cm","9.3cm","");
	LODOP.ADD_PRINT_TABLE("2cm","0.29cm","21.1cm","9.3cm",document.getElementById(id).innerHTML);//然后多个ADD语句及SET语句
	LODOP.PREVIEW();
}
function outToFile(id){
	LODOP=getLodop();
  	LODOP.PRINT_INIT(""); 
  	LODOP.ADD_PRINT_TABLE(5,5,"99%","100%",document.getElementById(id).innerHTML);
  	//LODOP.SET_SAVE_MODE("QUICK_SAVE",true);//快速生成（无表格样式,数据量较大时或许用到）
  	LODOP.SAVE_TO_FILE("导出报表.xlsx");
};
function to_print(obj){
	var mark = $(obj).attr("mark");
	if(mark == "first_print_button"){
//		$("div#first").print();
		outToFile('first');
	}else if(mark == "second_print_button"){
//		$("div#second").print();
		outToFile('second');
	}else{
//		$("div#third").print();
		outToFile('third');
	}
}
$("div#tab").live("click",function(){
	var mark = $(this).attr("mark");
	if(mark == "first"){
		$("#first").show();
		$("#second").hide();
		$("#third").hide();
		$(".title_button").attr("mark","first_print_button");
	}else if(mark == "second"){
		$("#first").hide();
		$("#second").show();
		$("#third").hide();
		$(".title_button").attr("mark","second_print_button");
	}else{
		$("#first").hide();
		$("#second").hide();
		$("#third").show();
		$(".title_button").attr("mark","third_print_button");
	}
	$("div#tab").each(function(){
		$(this).attr("class","tab_button");
	});
	$(this).attr("class","tab_button_curr");
});