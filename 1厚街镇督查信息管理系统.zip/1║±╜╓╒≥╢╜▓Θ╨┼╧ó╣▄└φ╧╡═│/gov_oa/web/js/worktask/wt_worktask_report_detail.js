/**
$("#print").live("click",function(){
	$("#page1").print();
});*/

var LODOP;
function table(){
	LODOP=getLodop();
	LODOP.PRINT_INIT("虎门能源配送收据");//首先一个初始化语句
	LODOP.SET_PRINT_PAGESIZE(1,"21.1cm","9.3cm","");
	LODOP.ADD_PRINT_TABLE("2cm","0.29cm","21.1cm","9.3cm",document.getElementById("f_div").innerHTML);//然后多个ADD语句及SET语句
	LODOP.PREVIEW();
}
function outToFile(){
	LODOP=getLodop();
  	LODOP.PRINT_INIT(""); 
  	LODOP.ADD_PRINT_TABLE(5,5,"99%","100%",document.getElementById("f_div").innerHTML);
  	//LODOP.SET_SAVE_MODE("QUICK_SAVE",true);//快速生成（无表格样式,数据量较大时或许用到）
  	LODOP.SAVE_TO_FILE("新文件名.xlsx");
};

function td_merge(tdIds){
	var tdIdArr = tdIds.split(",");
	for(var i=0;i<tdIdArr.length;i++){
		var startTdMark = $("td#"+tdIdArr[i]).first();//开始位置td对象
		var backContent;//上一次内容
		var tdIndex = 1;//合并开始位置
		var tdCount = 1;//合并数量
		var tdAllCount = $("td#"+tdIdArr[i]).length;
		var currTd = 1;
		var index_num = 1;
		$("td#"+tdIdArr[i]).each(function(){
			if($(this).html() == backContent){//相等
				tdIndex++;
				tdCount++;
				//从最远的td开始删除，否则元素顺序出现错乱
				$(this).next().next().next().remove();//
				$(this).next().next().remove();
				$(this).next().remove();
				$(this).prev().remove();
				$(this).remove();
				if(tdAllCount == currTd){//最后一行合并
					$(startTdMark).attr("rowspan",tdCount);//title
					$(startTdMark).prev().attr("rowspan",tdCount);//第一列序号
					$(startTdMark).prev().html(index_num-1);//第一列序号
					$(startTdMark).next().attr("rowspan",tdCount);//工作内容
					$(startTdMark).next().next().attr("rowspan",tdCount);//责任领导
					$(startTdMark).next().next().next().next().next().attr("rowspan",tdCount);//协助单位
				}
			}else{//不相等
					index_num++;
				if(tdIndex == 1){//开始第一行即使不相等也不合并
					startTdMark = $(this);
					tdIndex++;
				}else{//非开始第一行合并
					//必须先合并
					$(startTdMark).attr("rowspan",tdCount);//title
					$(startTdMark).prev().attr("rowspan",tdCount);//第一列序号
					
					$(startTdMark).next().attr("rowspan",tdCount);//工作内容
					$(startTdMark).next().next().attr("rowspan",tdCount);//责任领导
					$(startTdMark).next().next().next().next().next().attr("rowspan",tdCount);//协助单位
					//再赋值
					startTdMark = $(this);//
					tdIndex = 1;//合并开始位置
					tdCount = 1;//合并数量
				}
				$(startTdMark).prev().html(index_num-1);
			}
			backContent = $(this).html();
			currTd++;
		});
	}
}
//td_merge("title");


function changeDate(type){
	var submit_year = $("#submit_year").val();
	var submit_month = $("#submit_month").val();
	var submit_week = $("#submit_week").val();
	if(type == "year"){
		if(submit_year != "" && (submit_month != "" || submit_week != "")){
			$("#LIST_SEARCH_FORM").submit();
		}
	}else if(type == "month"){
		$("#submit_week").val("");
		if(submit_year != "" && submit_month != ""){
			$("#LIST_SEARCH_FORM").submit();
		}
	}else if(type == "week"){
		$("#submit_month").val("");
		if(submit_year != "" && submit_week != ""){
			$("#LIST_SEARCH_FORM").submit();
		}
	}
}
