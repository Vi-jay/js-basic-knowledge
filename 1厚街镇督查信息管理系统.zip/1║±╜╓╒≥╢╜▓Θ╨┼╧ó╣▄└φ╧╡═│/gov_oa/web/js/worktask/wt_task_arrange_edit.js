/**
 * @author twg
 */
$(document).ready(function(){
	/**为页面指定提交按钮注册是否倒计时事件*/
	Utils.submitCountDown();
	
	$("form#edit_form").validate({
		rules : {
			"formMap[schedule]" : {required : true},
			"formMap[next_plan]" : {required : true},
			"formMap[schedule_description]" : {required : true},
			"formMap[submit_cycle_select]" : {required : true},
			"formMap[execution_content]" : {required : true}
		},
		messages : {
			"formMap[schedule]" : {required : ""},
			"formMap[next_plan]" : {required : ""},
			"formMap[schedule_description]" : {required : ""},
			"formMap[submit_cycle_select]" : {required : ""},
			"formMap[execution_content]" : {required : ""}
		},
		errorPlacement:function(error,element){}
	});
	
});

///**选择协助用户*/
//function choose_user_result(attr,ids,names){
//	if($.trim(ids) != $.trim($("#current_login_user").val())){
//		var userIds = '<input type="hidden" id="assist_user" value="'+ids+'" name="formMap[assist_user]"/>';
//		userIds += '<input type="hidden" id="user_names" value="'+names+'" name="formMap[user_names]"/>';
//		$("#"+attr).html("协助人："+names+userIds);
//	}
//	close_dialog();
//}

/**设置年份以及月份*/
function choose_cycle(obj){
	var o_year = $("option[value='"+($(obj).val())+"']").attr("o_year");
	var o_date = $("option[value='"+($(obj).val())+"']").attr("o_date");
	$("#submit_year").val(o_year);
	$("#submit_time").val(o_date);
}

/**提交*/
function to_submit(type){
	if(type == "save"){
		$("form#edit_form").attr("action","/pc/temporarysave/create");//暂存
	}else{
		$("form#edit_form").attr("action","/pc/taskexecution/create");//提交
	}
	$("form#edit_form").submit();
}

/**查看职员往期进度*/
function viewUserSchedule(worktask_id,task_arrange_id,user_id){
	var opt_url = "/pc/taskexecution/lastTime?formMap[worktask_id]="+worktask_id+"&formMap[task_arrange_id]="+task_arrange_id+"&formMap[user_id]="+user_id;
	var opt_title = "往期进度";
	art.dialog.open(opt_url,{id: 'viewUserSchedule',background: 'white',opacity: 0.6,lock:true,fixed: true, title: opt_title,height:"450px", width:"800px"});
}

$("input[class^='opt_button']").remove();