/**
 * @author twg
 */
$(document).ready(function(){
	/**为页面指定提交按钮注册是否倒计时事件*/
	Utils.submitCountDown();
	
	$("form#edit_form").validate({
		rules : {
			"formMap[wpt_type_name]" : {required : true},
			"formMap[wpt_alias]" : {required : true}
		},
		messages : {
			"formMap[wpt_type_name]" : {required : ""},
			"formMap[wpt_alias]" : {required : ""}
		}
	});
	
});


function changeDate(obj){
	var val = $(obj).val();
	if(val == "A" || val == "B"){
		$("#wpt_opt_date_day").attr("name","formMap[wpt_opt_date]");
		$("#wpt_opt_date_week").attr("name","temp");
		$("#wpt_opt_date_daytext").attr("name","temp");
		$("#wpt_opt_date_day").show();
		$("#wpt_opt_date_week").hide();
		$("#wpt_opt_date_daytext").hide();
	}else if(val == "C" || val == "D"){
		$("#wpt_opt_date_day").attr("name","temp");
		$("#wpt_opt_date_daytext").attr("name","temp");
		$("#wpt_opt_date_week").attr("name","formMap[wpt_opt_date]");
		$("#wpt_opt_date_day").hide();
		$("#wpt_opt_date_daytext").hide();
		$("#wpt_opt_date_week").show();
	}else{
		$("#wpt_opt_date_day").attr("name","temp");
		$("#wpt_opt_date_week").attr("name","temp");
		$("#wpt_opt_date_daytext").attr("name","formMap[wpt_opt_date]");
		$("#wpt_opt_date_day").hide();
		$("#wpt_opt_date_week").hide();
		$("#wpt_opt_date_daytext").show();
	}
}
if($("#wpt_opt_type_val").val() != ""){
	changeDate($("#wpt_opt_type"));
}