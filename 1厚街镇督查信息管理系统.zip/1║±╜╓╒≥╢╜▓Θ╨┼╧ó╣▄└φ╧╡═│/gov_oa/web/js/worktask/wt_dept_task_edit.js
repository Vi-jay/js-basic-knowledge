/**
 * @author twg
 */
$(document).ready(function(){
	/**为页面指定提交按钮注册是否倒计时事件*/
	Utils.submitCountDown();
	
	$("form#edit_form").validate({
		rules : {
			"formMap[wpt_type_id]" : {required : true},
			"formMap[title]" : {required : true},
			"formMap[task_content]" : {required : true},
			"formMap[estimate_start_time]" : {required : true},
			"formMap[estimate_end_time]" : {required : true}
		},
		messages : {
			"formMap[wpt_type_id]" : {required : ""},
			"formMap[title]" : {required : ""},
			"formMap[task_content]" : {required : ""},
			"formMap[estimate_start_time]" : {required : ""},
			"formMap[estimate_end_time]" : {required : ""}
		},
		errorPlacement:function(error,element){}
	});
	
});

var changeStime = $("#dt_change_stime").val();
var changeEtime = $("#dt_change_etime").val();

/**选择发布用户*/
function choose_user_result(attr,ids,names){
	var idVals = ids.toString().split(",");
	var nameVals = names.toString().split(",");
	var html_content = "";
	for(var i=0;i<idVals.length;i++){
		if($("#"+(idVals[i])).val() && $("#"+(idVals[i])).val() != undefined && $("#"+(idVals[i])).val() != null){
		}else{
			html_content += '<tr id="'+(idVals[i])+'_tr"><td style="width: 70px;text-align: center;"><input type="hidden" id="'+(idVals[i])+'" value="'+(idVals[i])+'" name="formMap[user_ids]"/>'+nameVals[i]+'</td>';
			html_content += '<td><textarea style="width: 513px;height: 75px;" name="formMap[arrange_explain]" placeholder="任务说明"></textarea>';
			html_content += "<br/><input MARK='VERIFICATION' value='"+changeStime+"' class='input_text_date input_style1' style='width: 105px;' type='text' id='d25"+i+"s' name='formMap[arr_start_time]' onclick=\"javascript:WdatePicker({dateFmt:'yyyy-MM-dd HH:mm',maxDate:'#F{$dp.$D(\\'d25"+i+"e\\',{d:-1})}'});\" readonly='readonly' placeholder='计划开始时间'> ";
			html_content += "- <input MARK='VERIFICATION' value='"+changeEtime+"' class='input_style1' style='width: 105px;margin: 5px 12px 2px 0px;' type='text' id='d25"+i+"e' name='formMap[arr_end_time]' onclick=\"javascript:WdatePicker({dateFmt:'yyyy-MM-dd HH:mm',minDate:'#F{$dp.$D(\\'d25"+i+"s\\',{d:1})}'});\" readonly='readonly' placeholder='计划结束时间'>";
			html_content += "<input style='padding: 2px 7px;' type='button' value='上传附件' id='"+idVals[i]+"_button' onclick=javascript:upload_attr('"+idVals[i]+"','no'); />";
			html_content += '<input type="hidden" name="formMap[attr_name]" value="" id="'+idVals[i]+'_name"/>';
			html_content += '<input type="hidden" name="formMap[attr_url]" value="" id="'+idVals[i]+'_url"/>';
			html_content += '<span style="color: red;cursor: pointer;" onclick=javascript:remove_user("'+(idVals[i])+'","");>&emsp;删除</span></td></tr>';
		}
	}
	$("#"+attr).append(html_content);
	close_dialog();
}

/**修改执行者说明*/
function modify_arrange(obj,user_id,task_arrange_id,type){
	var worktask_id = $("#worktask_id").val();
	if(worktask_id != "" && task_arrange_id != 'no'){//修改
		if(type == "arrange_explain"){
			var arrange_explain = $(obj).val();
			$.post("/pc/taskarrange/modifyTaskArrange",{"formMap[worktask_id]":worktask_id,"formMap[user_id]":user_id,"formMap[task_arrange_id]":task_arrange_id,"formMap[arrange_explain]":arrange_explain},function(data){
			},"json");
		}else if(type == "arr_start_time"){
			var arr_start_time = $(obj).val();
			$.post("/pc/taskarrange/modifyTaskArrange",{"formMap[worktask_id]":worktask_id,"formMap[user_id]":user_id,"formMap[task_arrange_id]":task_arrange_id,"formMap[arr_start_time]":arr_start_time},function(data){
			},"json");
		}else if(type == "arr_end_time"){
			var arr_end_time = $(obj).val();
			$.post("/pc/taskarrange/modifyTaskArrange",{"formMap[worktask_id]":worktask_id,"formMap[user_id]":user_id,"formMap[task_arrange_id]":task_arrange_id,"formMap[arr_end_time]":arr_end_time},function(data){
			},"json");
		}else if(type == "attr"){
			var attr_name = $("#"+user_id+"_name").val();
			var attr_url = $("#"+user_id+"_url").val();
			$.post("/pc/taskarrange/modifyTaskArrange",{"formMap[worktask_id]":worktask_id,"formMap[user_id]":user_id,"formMap[task_arrange_id]":task_arrange_id,"formMap[attr_name]":attr_name,"formMap[attr_url]":attr_url},function(data){
			},"json");
		}
	}
}

/**删除执行者*/
function remove_user(user_id,task_arrange_id){
	$("#"+user_id+"_tr").remove();
}

var upload_attr_id;//用户ID
var task_arrange_id;//部门任务主键ID
/**异步上传附件*/
function upload_attr(userId,taskArrangeId){
	upload_attr_id = userId;
	task_arrange_id = taskArrangeId;
	$("#dept_attr_file").click();
}
$("input#dept_attr_file").live("change",function(){
	$.ajaxFileUpload({
        url             : "/pc/common/uploadAttr", //需要链接到服务器地址
        secureuri       : false,
        fileElementId   : "dept_attr_file", //文件选择框的id属性
        dataType        : "JSON", //服务器返回的格式
        success     	: function(data,status){
//        	$("[name='formMap[task_content]']").val(data);
        	var dataStr = (data+"").replace('<pre style="word-wrap: break-word; white-space: pre-wrap;">',"").replace("</pre>","");
        	var dataJSON = jQuery.parseJSON(dataStr);
        	$("#"+upload_attr_id+"_button").val("附件："+dataJSON.attachment_name);
        	$("#"+upload_attr_id+"_name").val(dataJSON.attachment_name);
        	$("#"+upload_attr_id+"_url").val(dataJSON.attachment);
        	modify_arrange(this,upload_attr_id,task_arrange_id,'attr');
        },
        error : function(data, status, e){alert("上传附件失败，请联系系统管理员");}
    });
});

/**提交*/
function to_submit(){
	if(isNull()){art.dialog.tips("执行说明、计划时间不能为空",4);return false;}
	var user_count = 0;
	$("input[name='formMap[user_ids]']").each(function(count){
		user_count = count+1;
	});
	if(user_count > 0){
		if(window.confirm("是否确认提交？")){
			$("form#edit_form").submit();
		}
	}else{
		alert("请分配任务");
	}
}