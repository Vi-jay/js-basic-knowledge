/**
 * @author twg
 */
$(document).ready(function(){
	/**为页面指定提交按钮注册是否倒计时事件*/
	Utils.submitCountDown();
	
	$("form#edit_form").validate({
		rules : {
			"formMap[wpt_title]" : {required : true},
			"formMap[wpt_num]" : {required : true}
		},
		messages : {
			"formMap[wpt_title]" : {required : ""},
			"formMap[wpt_num]" : {required : ""}
		}
	});
	
});