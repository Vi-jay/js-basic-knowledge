/**
 * @author twg
 */
$(document).ready(function(){
	/**为页面指定提交按钮注册是否倒计时事件*/
	Utils.submitCountDown();
	
});

/**开始执行事项（查看页面）*/
function startPerformTasks(){
	if(window.confirm("开始执行当前任务")){
		$("#startPerformTasks").submit();
	}
}

/**结束事项（查看页面）*/
function over_tasks(){
//	$.post('/pc/worktask/isOverTasks',{"formMap[worktask_id]":$("#worktask_id").val()},function(data){
//		if(data.result == "N"){
//			var url = "/pc/worktask/isOverTasksPage?formMap[worktask_id]="+$("#worktask_id").val();
//			art.dialog.open(url,{id: 'opt_to_execution',background: 'white',opacity: 0.6,lock:true,fixed: true, title: "待处理任务",height:"90%", width:"90%"});
//		}else{
//			art.dialog.confirm("结束当前事项？", function () {
//				$("#over_tasks").submit();
//			}, function () {});
//		}
//	},"json");
	art.dialog.confirm("结束当前事项？", function () {
		$("#over_tasks").submit();
	}, function () {});
}

/**更新项目进度评价*/
function projectEvaluate(obj){
	var evaluate_html = '<div style="margin: 20px 30px;">进度评价：<select id="evaluate"><option value="正常">正常</option><option value="较慢">较慢</option><option value="完成">完成</option>';
	evaluate_html += '</select></div>';
	art.dialog({
	    content: evaluate_html,
	    title:'更新进度评价',fixed: true,id: 'Fm7',okVal: '确认',
	    ok: function () {
	    	var evaluate = $("#evaluate").val();
	    	$.post('/pc/worktask/updateEvaluate',{"formMap[worktask_id]":$("#worktask_id").val(),"formMap[evaluate]":evaluate},function(data){
				$("#project_evaluate").html(evaluate);
				return true;
			},"json");
	    },
	    cancel: true
	});
}

function opt_to_execution(task_execution_id,dt_dept_task_id,opt){
	var opt_h = "450px";
	var opt_w = "800px";
	var opt_url="";
	var opt_title="";
	if(opt == "tx"){//提醒
		opt_url = "/pc/newsremind/entryEdit?formMap[task_execution_id]="+task_execution_id+"&formMap[dt_dept_task_id]="+dt_dept_task_id+"&formMap[wnr_type]=0";
		opt_title = "提醒";
	}else if(opt == "db"){//督办
		opt_url = "/pc/newsremind/entryEdit?formMap[task_execution_id]="+task_execution_id+"&formMap[dt_dept_task_id]="+dt_dept_task_id+"&formMap[wnr_type]=1";
		opt_title = "督办";
	}else if(opt == "pj"){//评价
		opt_h = "200px";
		opt_w = "500px";
		opt_url = "/pc/evaluate/entryEdit?formMap[task_execution_id]="+task_execution_id;
		opt_title = "评价";
	}else if(opt == "xg"){//修改
		opt_url = "/pc/taskexecution/entryEdit?formMap[task_execution_id]="+task_execution_id;
		opt_title = "修改阶段信息";
	}
	art.dialog.open(opt_url,{id: 'opt_to_execution',background: 'white',opacity: 0.6,lock:true,fixed: true, title: opt_title,height:opt_h, width:opt_w});
}

/**手机微信端请求*/
function updateTaskForMobile(id,deptTaskId,type){
	var opt_url;
	if(type == "tx"){//提醒
		opt_url = "/pc/newsremind/entryEdit?formMap[task_execution_id]="+id+"&formMap[wnr_type]=0&formMap[worktask_id]="+$("#worktask_id").val();
	}else if(type == "db"){//督办
		opt_url = "/pc/newsremind/entryEdit?formMap[task_execution_id]="+id+"&formMap[wnr_type]=1&formMap[worktask_id]="+$("#worktask_id").val();
	}else if(type == "xg"){//修改
		opt_url = "/pc/taskexecution/entryEdit?formMap[task_execution_id]="+id;
	}else if(type == "tg"){//通过（更新部门进度）
		opt_url="/pc/depttask/entryUpdatePage?formMap[task_execution_id]="+id+"&formMap[dt_dept_task_id]="+deptTaskId;
	}
	$("form#opt_form").attr("action",opt_url);
	$("form#opt_form").submit();
}

/**查看部门往期进度*/
function viewDeptSchedule(worktask_id,dt_dept_task_id,dept_id){
	var opt_url = "/pc/deptschedule/listByPage?formMap[worktask_id]="+worktask_id+"&formMap[dt_dept_task_id]="+dt_dept_task_id+"&formMap[dept_id]="+dept_id;
	var opt_title = "往期进度";
	art.dialog.open(opt_url,{id: 'viewDeptSchedule',background: 'white',opacity: 0.6,lock:true,fixed: true, title: opt_title,height:"450px", width:"800px"});
}
/**查看职员往期进度*/
function viewUserSchedule(worktask_id,task_arrange_id,user_id){
	var opt_url = "/pc/taskexecution/lastTime?formMap[worktask_id]="+worktask_id+"&formMap[task_arrange_id]="+task_arrange_id+"&formMap[user_id]="+user_id;
	var opt_title = "往期进度";
	art.dialog.open(opt_url,{id: 'viewUserSchedule',background: 'white',opacity: 0.6,lock:true,fixed: true, title: opt_title,height:"450px", width:"800px"});
}


/**申请改期*/
function changeTime(id){
	var opt_url = "/pc/changetime/entryEdit?formMap[dt_dept_task_id]="+id;
	var opt_title = "申请改期";
	art.dialog.open(opt_url,{id: 'changeTime',background: 'white',opacity: 0.6,lock:true,fixed: true, title: opt_title,height:"450px", width:"800px"});
}

var elemt_obj;
/**移除审核改期申请按钮*/
function remove_approval_a(){
	if(elemt_obj){
		$(elemt_obj).remove();
	}
}
/**审核改期申请*/
function approval(obj,id){
	elemt_obj = obj;
	var opt_url = "/pc/changetime/entryAduit?formMap[ct_change_time_id]="+id;
	var opt_title = "审核";
	art.dialog.open(opt_url,{id: 'changeTime',background: 'white',opacity: 0.6,lock:true,fixed: true, title: opt_title,height:"300px", width:"600px"});
}

/**锁定部门任务进度信息*/
function lockDeptTask(dt_dept_task_id,dt_is_lock){
	art.dialog.confirm("是否确定操作？", function () {
		$.post('/pc/depttask/modifyDeptTask',{"formMap[dt_dept_task_id]":dt_dept_task_id,"formMap[dt_is_lock]":dt_is_lock},function(data){
			window.location.reload();
		},"json");
	}, function () {
	});
}
/**退回部门任务进度信息*/
function backToDeptTask(dt_dept_task_id){
	art.dialog({
	    content: '<textarea style="height: 130px;width: 300px;" id="opt_reason"></textarea>',
	    title:'退回原因',fixed: true,id: 'Fm7',okVal: '确认',
	    padding: '20px 15px',
	    ok: function () {
	    	var optReason = $("#opt_reason").val();
	    	if(optReason && $.trim(optReason) != ""){
				$.post('/pc/depttask/modifyDeptTask',{"formMap[dt_dept_task_id]":dt_dept_task_id,"formMap[dt_opt_status]":"N","formMap[dt_opt_reason]":optReason,"formMap[dt_is_lock]":"N","formMap[dt_approval]":"N","formMap[wnr_type]":"2"},function(data){
					window.location.reload();
				},"json");
	    	}else{
	    		art.dialog.tips("请填写退回原因");
	    		return false;
	    	}
	    },
	    cancel: true
	});
}

/**更新状态*/
function updateStatus(taskExecutionId,dt_dept_task_id,type){
	if(type == "tg"){//通过
		var opt_url="/pc/depttask/entryUpdatePage?formMap[task_execution_id]="+taskExecutionId+"&formMap[dt_dept_task_id]="+dt_dept_task_id;
		var opt_title="更新部门进度";
		art.dialog.open(opt_url,{id: 'opt_to_execution',background: 'white',opacity: 0.6,lock:true,fixed: true, title: opt_title,height:"450px", width:"800px"});
	}else if(type == "btg"){//不通过
		art.dialog({
		    content: '<textarea style="height: 130px;width: 300px;" id="opt_reason"></textarea>',
		    title:'不通过原因',fixed: true,id: 'Fm7',okVal: '确认',
		    ok: function () {
		    	var optReason = $("#opt_reason").val();
		    	if(optReason && $.trim(optReason) != ""){
					$.post('/pc/taskexecution/updateStatus',{"formMap[task_execution_id]":taskExecutionId,"formMap[approval_status]":"N","formMap[opt_reason]":optReason,"formMap[wnr_type]":"3"},function(data){
						removeButton(taskExecutionId,type);
					},"json");
		    	}else{
		    		art.dialog.tips("请填写不通过原因");
		    		return false;
		    	}
		    },
		    cancel: true
		});
	}else if(type == "sd"){//锁定
		art.dialog.confirm("确定锁定？", function () {
			$.post('/pc/taskexecution/updateStatus',{"formMap[task_execution_id]":taskExecutionId,"formMap[is_lock]":"Y"},function(data){
				window.location.reload();
			},"json");
		}, function () {
		});
	}else if(type == "qxsd"){//取消锁定
		art.dialog.confirm("确定取消锁定？", function () {
			$.post('/pc/taskexecution/updateStatus',{"formMap[task_execution_id]":taskExecutionId,"formMap[is_lock]":"N"},function(data){
				window.location.reload();
			},"json");
		}, function () {
		});
	}else if(type == "th"){//退回
		art.dialog({
		    content: '<textarea style="height: 130px;width: 300px;" id="opt_reason"></textarea>',
		    title:'退回原因',fixed: true,id: 'Fm7',okVal: '确认',
		    padding: '20px 15px',
		    ok: function () {
		    	var optReason = $("#opt_reason").val();
		    	if(optReason && $.trim(optReason) != ""){
					$.post('/pc/taskexecution/updateStatus',{"formMap[task_execution_id]":taskExecutionId,"formMap[is_back_finish]":"N","formMap[opt_reason]":optReason,"formMap[is_lock]":"N","formMap[approval_status]":"N","formMap[wnr_type]":"2"},function(data){
						removeButton(taskExecutionId,type);
					},"json");
		    	}else{
		    		art.dialog.tips("请填写退回原因");
		    		return false;
		    	}
		    },
		    cancel: true
		});
	}
}

/**判断并更新进度*/
function judgeAndUpdateDeptSchedule(dt_dept_task_id,type){
	$.post('/pc/depttask/getUnfinishedTime',{"formMap[worktask_id]":$("#worktask_id").val(),"formMap[dept_id]":$("input[name='formMap[dept_id]']").val()},function(data){
		if(data.result == "N"){
			art.dialog.tips("本期进度已报送");
		}else if(data.result == "O"){
			art.dialog.tips("未到报送时间");
		}else{
			if(data.wt_opt_type == "A" || data.wt_opt_type == "B" || data.wt_opt_type == "C" || data.wt_opt_type == "D"){
				var flag = true;
				var not_user = "本期未填报用户：<br>";//未填报用户
				var cancal_user = "本期未选择用户：<br>";//未选择用户
				$("span#te_user").each(function(){
					var flag = true;
					var c_val = $("input[te_user_name='"+($(this).html())+"']").val();
					if(c_val != undefined && c_val != null){
					}else{
						not_user+="["+$(this).html()+"]&nbsp;";
						flag = false;
					}
					if(!$("input[te_user_name='"+($(this).html())+"']").attr("checked") && flag){
						cancal_user+="["+$(this).html()+"]&nbsp;";
					}
				});
				art.dialog.confirm(not_user+"<br>"+cancal_user+"<br><font style='color:#00A1E9;'>是否确定报送本期进度？&emsp;&emsp;&emsp;&emsp;&emsp;</font>", function () {
					updateSchedule(dt_dept_task_id,type);
				}, function () {});
			}else{
				updateSchedule(dt_dept_task_id,type);
			}
		}
	},"json");
}

/**更新或者修改部门任务进度*/
function updateSchedule(dt_dept_task_id,type){
	var te_ids = "";
	if(type == "create"){
		$(":checked[name='temp']").each(function(i){
			te_ids += "'"+$(this).val()+"',";
		});
	}
	var o_year = $("#curr_submit_year").val();
	var o_date = $("#curr_submit_time").val();
	if(type == "update"){
		o_year = $("#update_year_"+dt_dept_task_id).val();
		o_date = $("#update_time_"+dt_dept_task_id).val();
	}
	var opt_url="/pc/depttask/entryUpdatePage?formMap[dt_dept_task_id]="+dt_dept_task_id+"&formMap[teIds]="+te_ids+"&formMap[opt_mark]="+type+"&formMap[dt_submit_year_temp]="+o_year+"&formMap[dt_submit_time_temp]="+o_date;
	var opt_title="更新部门进度";
	art.dialog.open(opt_url,{id: 'updateSchedule',background: 'white',opacity: 0.6,lock:true,fixed: true, title: opt_title,height:"95%", width:"95%"});
}

/**审核任务执行信息*/
function execution_approval(taskExecutionId,type){
	var optReason = $("#textarea-"+taskExecutionId).val();
	if(optReason == "" && type == "N"){
		art.dialog.tips("请填写退回原因");
	}else{
		art.dialog.confirm("是否确定操作？", function () {
			$.post('/pc/taskexecution/updateStatus',{"formMap[task_execution_id]":taskExecutionId,"formMap[approval_status]":type,"formMap[opt_reason]":optReason,"formMap[wnr_type]":"3"},function(data){
				art.dialog.tips("操作成功");
				$("#tr-"+taskExecutionId).remove();
			},"json");
		}, function () {
		});
	}
}

/**删除职员任务执行记录*/
function remove_execution(task_execution_id){
	art.dialog.confirm("是否确定删除？", function () {
		$.post('/pc/taskexecution/asynchronousDelete',{"formMap[ids]":task_execution_id},function(data){
			window.location.reload();
		},"json");
	}, function () {
	});
}

function removeButton(taskExecutionId,type){
	if(type == "tg" || type == "btg"){
		$("#"+taskExecutionId+"_tg").remove();
		$("#"+taskExecutionId+"_btg").remove();
	}else if(type == "sd" || type == "qxsd"){
		$("#"+taskExecutionId+"_sd").remove();
		$("#"+taskExecutionId+"_qxsd").remove();
	}else if(type == "th"){
		$("#"+taskExecutionId+"_th").remove();
	}
	art.dialog.tips("操作成功");
//	window.location.reload();
}

/**查看部门任务详情
function showDetail(div_obj,deptId){
	$("#detail_"+deptId).toggle();
	if($("#detail_"+deptId).is(":hidden")){
		$(div_obj).html("展开任务详情▼");
	}else{
		$(div_obj).html("收起任务详情▲");
	}
}*/

//if(opt_mark == "approval"){
//	var upper_obj;
//	var user_mark = "";
//	$("tr[mark='dltr']").each(function(i){
//		if($(this).attr("user") != user_mark){
//		}else if($(this).attr("user") == user_mark){
//			var dl = $(upper_obj).attr("dl");
//			var status = $(upper_obj).attr("status");
//			if(status == "Y"){
//				$("tr[dl="+dl+"]").each(function(){
//					$(this).remove();
//				});
//			}
//		}
//		upper_obj = $(this);
//		user_mark = $(this).attr("user");
//	});
//}

/**设置年份以及月份*/
function choose_cycle(worktask_id,obj){
	var o_year = $("option[value='"+($(obj).val())+"']").attr("o_year");
	var o_date = $("option[value='"+($(obj).val())+"']").attr("o_date");
	window.location.href="/pc/worktask/entryView?formMap[worktask_id]="+worktask_id+"&formMap[opt_mark]=approval&formMap[submit_year]="+o_year+"&formMap[submit_time]="+o_date;
}


/**显示审批操作标签*/
function show_approval_opt(task_execution_id){
	$("#tr-"+task_execution_id).show();
}
