/**
 * @author twg
 */
$(document).ready(function(){
	/**注册全选、反选事件*/
	Utils.selectCheckbox();
	
	/**为页面指定按钮注册是否已经选择数据事件*/
	Utils.verifySelection();
	
	/**为页面按钮添加单数据操作提示*/
	Utils.singleDataOperate();
	
});

/**标记操作*/
function to_sign(obj,id){
	var src = $(obj).attr("src");
	if(src == "/style/image/star_n.png"){
		if(window.confirm("是否标记")){
			$.post("/pc/worktask/toSign",{"formMap[worktask_id]":id,"formMap[is_sign]":"1"},function(data){},"json");
			$(obj).attr("src","/style/image/star_y.png");
		}
	}else{
		if(window.confirm("是否取消标记")){
			$.post("/pc/worktask/toSign",{"formMap[worktask_id]":id,"formMap[is_sign]":"0"},function(data){},"json");
			$(obj).attr("src","/style/image/star_n.png");
		}
	}
}

$.post("/pc/worktask/listByPageCount",{},function(data){
	$("[VM_VALUE='A']").html("执行中（"+data.A+"）");
	$("[VM_VALUE='B']").html("已暂停（"+data.B+"）");
	$("[VM_VALUE='C']").html("已结束（"+data.C+"）");
	$("[VM_VALUE='D']").html("已废弃（"+data.D+"）");
},"json");

$.post("/pc/worktask/findAllWorkTaskCount",{},function(data){
	$("[VM_VALUE='N']").html("待审核（"+data.N+"）");
	$("[VM_VALUE='Y']").html("已审核（"+data.Y+"）");
},"json");

/**批量提醒或批量督办*/
function batch_opt(val,type){
	var vals = "";
	$(":checkbox[id='LIST_CHECKBOX_DETAIL']:checked").each(function(){
		vals+=$(this).val()+"-";
	});
	if(vals != ""){
		$("#batch_opt_type").html(type);
		art.dialog({
			id: 'batch_opt_artdialog',
		    title: '填写'+type+'内容',
		    content: $("#batch_opt_div").html(),
		    ok: function () {
		    	var opt_content = $("#opt_content").val();
		    	if(opt_content != ""){
		    		$.post('/pc/newsremind/createBatchOpt',{"formMap[worktask_ids]":vals,"formMap[wnr_explain]":opt_content,"formMap[wnr_type]":val},function(data){
			    		art.dialog.tips(type+"成功",8);
			    		$(":checkbox:checked").each(function(){
			    			//$(this).attr("checked",false);
			    			$(this).remove();
			    		});
			    	},"json");
		    	}else{
		    		art.dialog.tips("内容不能为空");
		    		return false;
		    	}
		    },
		    cancel: true
		});
	}else{
		art.dialog.tips("请选择需要"+type+"的事项",3);
		return false;
	}
	
}

/**一键催报*/
function sendTipToAll(){
	art.dialog.confirm("是否确定执行一键催报功能？", function () {
		$.post("/pc/newsremind/sendTipToAll",{},function(data){
			art.dialog.tips("一键催报成功");
		},"json");
	}, function () {
	});
}