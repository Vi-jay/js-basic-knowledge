/**
 * @author twg
 */
$(document).ready(function(){
	/**注册全选、反选事件*/
	Utils.selectCheckbox();
	
	/**为页面指定按钮注册是否已经选择数据事件*/
	Utils.verifySelection();
	
	/**为页面按钮添加单数据操作提示*/
	Utils.singleDataOperate();
	
});

/**标记操作*/
function to_sign(obj,id){
	var src = $(obj).attr("src");
	if(src == "/style/image/star_n.png"){
		if(window.confirm("是否标记")){
			$.post("/pc/taskarrange/toSign",{"formMap[task_arrange_id]":id,"formMap[is_sign]":"1"},function(data){},"json");
			$(obj).attr("src","/style/image/star_y.png");
		}
	}else{
		if(window.confirm("是否取消标记")){
			$.post("/pc/taskarrange/toSign",{"formMap[task_arrange_id]":id,"formMap[is_sign]":"0"},function(data){},"json");
			$(obj).attr("src","/style/image/star_n.png");
		}
	}
}

function change_tab(){
	$(".tab_first_div").toggle();
}

$.post("/pc/taskarrange/mytaskCount",{},function(data){
	$("[VM_VALUE='']").html("未完成（"+data.Y+"）");
	$("[VM_VALUE='A']").html("未阅（"+data.A+"）");
	$("[VM_VALUE='B']").html("已阅（"+data.B+"）");
	$("[VM_VALUE='C']").html("执行中（"+data.C+"）");
	$("[VM_VALUE='D']").html("已暂停（"+data.D+"）");
	$("[VM_VALUE='E']").html("已完成（"+data.E+"）");
	
	$("#Y_span").html(data.Y);
	$("#A_span").html(data.A);
	$("#B_span").html(data.B);
	$("#C_span").html(data.C);
	$("#D_span").html(data.D);
	$("#E_span").html(data.E);
	
	if(data.Y != "0"){
		$("#Y_span").css("background-color","#60A2D0");
	}
	if(data.A != "0"){
		$("#A_span").css("background-color","#60A2D0");
	}
	if(data.B != "0"){
		$("#B_span").css("background-color","#60A2D0");
	}
	if(data.C != "0"){
		$("#C_span").css("background-color","#60A2D0");
	}
	if(data.D != "0"){
		$("#D_span").css("background-color","#60A2D0");
	}
	if(data.E != "0"){
		$("#E_span").css("background-color","#60A2D0");
	}
},"json");

/**判断并更新进度*/
function judgeAndUpdateSchedule(worktask_id,task_arrange_id,user_id,dept_id){
	$.post('/pc/taskarrange/getUnfinishedTime',{"formMap[worktask_id]":worktask_id,"formMap[task_arrange_id]":task_arrange_id,"formMap[user_id]":user_id},function(data){
		if(data.result == "N"){
			art.dialog.tips("本期进度已报送");
		}else if(data.result == "O"){
			art.dialog.tips("未到报送时间");
		}else{
			window.location.href="/pc/taskarrange/entryEdit?formMap[task_arrange_id]="+task_arrange_id+"&formMap[worktask_id]="+worktask_id+"&formMap[dept_id]="+dept_id+"&formMap[opt_mark]=mytask";
		}
	},"json");
}

function modify_new_schedule(worktask_id,task_arrange_id){
	var opt_h = "95%";
	var opt_w = "800px";
	var opt_url = "/pc/taskexecution/entryEdit?formMap[worktask_id_temp]="+worktask_id+"&formMap[task_arrange_id_temp]="+task_arrange_id+"&formMap[operation_source]=modify_new_schedule";
	var opt_title = "修改最新进度信息";
	art.dialog.open(opt_url,{id: 'opt_to_execution',background: 'white',opacity: 0.6,lock:true,fixed: true, title: opt_title,height:opt_h, width:opt_w});
}

function reload_and_search(){
	$("#LIST_SEARCH_FORM").submit();
}