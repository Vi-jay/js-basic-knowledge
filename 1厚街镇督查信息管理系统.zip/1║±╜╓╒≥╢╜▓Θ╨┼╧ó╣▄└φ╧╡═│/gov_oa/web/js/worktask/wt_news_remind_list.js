/**
 * @author twg
 */
$(document).ready(function(){
	/**注册全选、反选事件*/
	Utils.selectCheckbox();
	
	/**为页面指定按钮注册是否已经选择数据事件*/
	Utils.verifySelection();
	
	/**为页面按钮添加单数据操作提示*/
	Utils.singleDataOperate();
	
});

var ids = new Array();//已设置已读消息
function modifyReadToY(id){
	var flag = true;
	for(var i=0;i<ids.length;i++){
		if(id==ids[i]){
			flag = false;
		}
	}
	if(flag){
		$.post("/pc/newsremind/modifyReadToY",{"formMap[wnr_news_remind_id]":id},function(data){
			ids.push(id);
		},"json");
	}
}

function toView(id){
	modifyReadToY(id);
	$("#"+id).toggle();
}

function close_detail(id){
	var detail_table_id = "detail_"+id;
	$("table.detail_table").each(function(){
		if(detail_table_id != $(this).attr("id")){
			$(this).hide();
		}
	});
}
function show_detail(id){
	modifyReadToY(id);
	close_detail(id);
	$("table#detail_"+id).toggle();
}