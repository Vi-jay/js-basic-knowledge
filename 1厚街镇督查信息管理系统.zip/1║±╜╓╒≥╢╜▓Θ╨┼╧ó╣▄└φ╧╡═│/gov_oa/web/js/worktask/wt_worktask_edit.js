/**
 * @author twg
 */
$(document).ready(function(){
	/**为页面指定提交按钮注册是否倒计时事件*/
	Utils.submitCountDown();
	
	$("form#edit_form").validate({
		rules : {
			"formMap[wpt_type_id]" : {required : true},
			"formMap[title]" : {required : true},
			"formMap[task_content]" : {required : true},
			"formMap[estimate_start_time]" : {required : true},
			"formMap[sort]" : {required : true,digits : true},
			"formMap[estimate_end_time]" : {required : true}
		},
		messages : {
			"formMap[wpt_type_id]" : {required : ""},
			"formMap[title]" : {required : ""},
			"formMap[task_content]" : {required : ""},
			"formMap[estimate_start_time]" : {required : ""},
			"formMap[sort]" : {required : "",digits : "格式有误"},
			"formMap[estimate_end_time]" : {required : ""}
		}
	});
	
});

/**选择发布用户*/
function choose_user_result(attr,ids,names){
	$("#"+attr).val(names);
	if(attr.indexOf("drp_") >= 0){
		var dept_id_p = $("#"+attr).attr("dept_id");
		var dt_dept_task_id_p = $("#"+attr).attr("dt_dept_task_id");
		modify_depttask($("#"+attr),dept_id_p,dt_dept_task_id_p,'dt_respon_people');
	}
	close_dialog();
}

/**选择部门统一回调处理结果*/
function choose_dept_result(attr,ids,names){
	var estimate_start_time = $("input[name='formMap[estimate_start_time]']").val();
	var estimate_end_time = $("input[name='formMap[estimate_end_time]']").val();
	var idVals = ids.toString().split(",");
	var nameVals = names.toString().split(",");
	var html_content = "";
//	if($("input[name='formMap[sg_id]']").val() != ""){
//		$("#"+attr).html("");
//	}
	for(var i=0;i<idVals.length;i++){
		if($("#choose_main_dept").find("#"+(idVals[i])).val()){//过滤重复值
		}else if($("#choose_assist_dept").find("#"+(idVals[i])).val()){//过滤重复值
		}else{
			if(attr == "choose_main_dept"){//主办单位
				html_content += '<tr id="'+(idVals[i])+'_tr"><td style="width: 70px;text-align: center;"><input type="hidden" id="'+(idVals[i])+'" value="'+(idVals[i])+'" name="formMap[dept_ids]"/>'+nameVals[i]+'</td>';
				html_content += '<td><textarea style="width: 513px;height: 75px;" name="formMap[arrange_explains]" placeholder="工作安排"></textarea>';
				html_content += "<br/><input MARK='VERIFICATION' class='input_text_date input_style1' style='width: 105px;' type='text' id='d54"+i+"s' name='formMap[start_time]' value='"+estimate_start_time+"' onclick=\"javascript:WdatePicker({dateFmt:'yyyy-MM-dd HH:mm',maxDate:'#F{$dp.$D(\\'d54"+i+"e\\',{d:-1})}'});\" readonly='readonly' placeholder='计划开始时间'> ";
				html_content += "- <input MARK='VERIFICATION' class='input_style1' style='width: 105px;margin: 5px 12px 2px 0px;' type='text' id='d54"+i+"e' name='formMap[end_time]' value='"+estimate_end_time+"' onclick=\"javascript:WdatePicker({dateFmt:'yyyy-MM-dd HH:mm',minDate:'#F{$dp.$D(\\'d54"+i+"s\\',{d:1})}'});\" readonly='readonly' placeholder='计划结束时间'>";
				html_content += "<input style='padding: 2px 7px;' type='button' value='上传附件' id='"+idVals[i]+"_button' onclick=javascript:upload_attr('"+idVals[i]+"','no'); />";
				html_content += '<input type="hidden" name="formMap[dt_attach_name]" value="" id="'+idVals[i]+'_name"/>';
				html_content += '<input type="hidden" name="formMap[dt_attach_url]" value="" id="'+idVals[i]+'_url"/>';
				html_content += '<br><input id="drp_'+i+'" onclick=javascript:choose_user("drp_'+i+'","R","","90%","90%"); class="input_style1" type="text" name="formMap[dt_respon_peoples]" style="width: 150px;margin: 5px 12px 2px 0px;" maxlength="10" readonly="readonly" placeholder="责任人">';
				html_content += '<span style="color: red;cursor: pointer;" onclick=javascript:remove_user("'+(idVals[i])+'","");>&emsp;删除</span><br/>';
				html_content += '</td></tr>';
			}else{//协办单位
				html_content += '<tr id="'+(idVals[i])+'_tr"><td style="width: 70px;text-align: center;"><input type="hidden" id="'+(idVals[i])+'" value="'+(idVals[i])+'" name="formMap[at_dept_ids]"/>'+nameVals[i]+'</td>';
				html_content += '<td><textarea style="width: 513px;height: 75px;" name="formMap[at_tasks]" placeholder="协办说明"></textarea>';
//				html_content += "<br/><input MARK='VERIFICATION' class='input_text_date input_style1' style='width: 105px;' type='text' id='d54"+i+"s' name='formMap[start_time]' value='"+estimate_start_time+"' onclick=\"javascript:WdatePicker({dateFmt:'yyyy-MM-dd HH:mm',maxDate:'#F{$dp.$D(\\'d54"+i+"e\\',{d:-1})}'});\" readonly='readonly' placeholder='计划开始时间'> ";
//				html_content += "- <input MARK='VERIFICATION' class='input_style1' style='width: 105px;margin: 5px 12px 2px 0px;' type='text' id='d54"+i+"e' name='formMap[end_time]' value='"+estimate_end_time+"' onclick=\"javascript:WdatePicker({dateFmt:'yyyy-MM-dd HH:mm',minDate:'#F{$dp.$D(\\'d54"+i+"s\\',{d:1})}'});\" readonly='readonly' placeholder='计划结束时间'>";
//				html_content += "<input style='padding: 2px 7px;' type='button' value='上传附件' id='"+idVals[i]+"_button' onclick=javascript:upload_attr('"+idVals[i]+"','no'); />";
//				html_content += '<input type="hidden" name="formMap[dt_attach_name]" value="" id="'+idVals[i]+'_name"/>';
//				html_content += '<input type="hidden" name="formMap[dt_attach_url]" value="" id="'+idVals[i]+'_url"/>';
//				html_content += '<br><input id="dt_respon_peoples_'+i+'" onclick=javascript:choose_user("dt_respon_peoples_'+i+'","R","","90%","90%"); class="input_style1" type="text" name="formMap[dt_respon_peoples]" style="width: 150px;margin: 5px 12px 2px 0px;" maxlength="10" readonly="readonly" placeholder="责任人">';
				html_content += '<span style="color: red;cursor: pointer;" onclick=javascript:remove_user("'+(idVals[i])+'","");>&emsp;删除</span><br/>';
				html_content += '</td></tr>';
			}
		}
	}
	$("#"+attr).append(html_content);
	close_dialog();
}

/**选择部门统一回调处理结果*/
function choose_deptgroup_result(attr,ids,names){
	var estimate_start_time = $("input[name='formMap[estimate_start_time]']").val();
	var estimate_end_time = $("input[name='formMap[estimate_end_time]']").val();
	var idVals = ids.toString().split(",");
	var nameVals = names.toString().split(",");
	var html_content = "";
	for(var i=0;i<idVals.length;i++){
		if($("#choose_main_dept").find("#"+(idVals[i])).val()){//过滤重复值
		}else if($("#choose_assist_dept").find("#"+(idVals[i])).val()){//过滤重复值
		}else{
			html_content += '<tr id="'+(idVals[i])+'_tr"><td style="width: 70px;text-align: center;"><input type="hidden" id="'+(idVals[i])+'" value="'+(idVals[i])+'" name="formMap[sg_id]"/>'+nameVals[i]+'</td>';
			html_content += '<td><textarea style="width: 513px;height: 75px;" name="formMap[arrange_explains]" placeholder="工作安排"></textarea>';
			html_content += "<br/><input MARK='VERIFICATION' class='input_text_date input_style1' style='width: 105px;' type='text' id='d54"+i+"s' name='formMap[start_time]' value='"+estimate_start_time+"' onclick=\"javascript:WdatePicker({dateFmt:'yyyy-MM-dd HH:mm',maxDate:'#F{$dp.$D(\\'d54"+i+"e\\',{d:-1})}'});\" readonly='readonly' placeholder='计划开始时间'> ";
			html_content += "- <input MARK='VERIFICATION' class='input_style1' style='width: 105px;margin: 5px 12px 2px 0px;' type='text' id='d54"+i+"e' name='formMap[end_time]' value='"+estimate_end_time+"' onclick=\"javascript:WdatePicker({dateFmt:'yyyy-MM-dd HH:mm',minDate:'#F{$dp.$D(\\'d54"+i+"s\\',{d:1})}'});\" readonly='readonly' placeholder='计划结束时间'>";
			html_content += "<input style='padding: 2px 7px;' type='button' value='上传附件' id='"+idVals[i]+"_button' onclick=javascript:upload_attr('"+idVals[i]+"','no'); />";
			html_content += '<input type="hidden" name="formMap[dt_attach_name]" value="" id="'+idVals[i]+'_name"/>';
			html_content += '<input type="hidden" name="formMap[dt_attach_url]" value="" id="'+idVals[i]+'_url"/>';
			html_content += '<br><input id="drp_'+i+'" onclick=javascript:choose_user("drp_'+i+'","R","","90%","90%"); class="input_style1" type="text" name="formMap[dt_respon_peoples]" style="width: 150px;margin: 5px 12px 2px 0px;" maxlength="10" readonly="readonly" placeholder="责任人">';
			html_content += '<span style="color: red;cursor: pointer;" onclick=javascript:remove_user("'+(idVals[i])+'","");>&emsp;删除</span><br/>';
			html_content += '</td></tr>';
		}
	}
	$("#"+attr).html(html_content);
	close_dialog();
}

/**修改主办单位信息*/
function modify_depttask(obj,dept_id,dept_task_id,type){
	var worktask_id = $("#worktask_id").val();
	if(worktask_id != "" && dept_task_id != 'no'){//修改
		if(type == "dt_task_explain"){
			var arrange_explain = $(obj).val();
			$.post("/pc/depttask/modifyDeptTask",{"formMap[worktask_id]":worktask_id,"formMap[dept_id]":dept_id,"formMap[dt_dept_task_id]":dept_task_id,"formMap[dt_task_explain]":arrange_explain},function(data){
			},"json");
		}else if(type == "dt_start_time"){
			var dt_start_time = $(obj).val();
			$.post("/pc/depttask/modifyDeptTask",{"formMap[worktask_id]":worktask_id,"formMap[dept_id]":dept_id,"formMap[dt_dept_task_id]":dept_task_id,"formMap[dt_start_time]":dt_start_time},function(data){
			},"json");
		}else if(type == "dt_end_time"){
			var dt_end_time = $(obj).val();
			$.post("/pc/depttask/modifyDeptTask",{"formMap[worktask_id]":worktask_id,"formMap[dept_id]":dept_id,"formMap[dt_dept_task_id]":dept_task_id,"formMap[dt_end_time]":dt_end_time},function(data){
			},"json");
		}else if(type == "dt_respon_people"){
			var dt_respon_people = $(obj).val();
			$.post("/pc/depttask/modifyDeptTask",{"formMap[worktask_id]":worktask_id,"formMap[dept_id]":dept_id,"formMap[dt_dept_task_id]":dept_task_id,"formMap[dt_respon_people]":dt_respon_people},function(data){
			},"json");
		}else if(type == "attr"){
			var attr_name = $("#"+dept_id+"_name").val();
			var attr_url = $("#"+dept_id+"_url").val();
			$.post("/pc/depttask/modifyDeptTask",{"formMap[worktask_id]":worktask_id,"formMap[dept_id]":dept_id,"formMap[dt_dept_task_id]":dept_task_id,"formMap[dt_attach_name]":attr_name,"formMap[dt_attach_url]":attr_url},function(data){
			},"json");
		}
	}
}

/**修改协办单位信息*/
function modify_assistunit(obj,at_assistunit_id,type){
	var worktask_id = $("#worktask_id").val();
	if(worktask_id != "" && dept_task_id != 'no'){//修改
		if(type == "at_task"){
			var at_task = $(obj).val();
			$.post("/pc/assistunit/modifyInfo",{"formMap[at_assistunit_id]":at_assistunit_id,"formMap[at_task]":at_task},function(data){
			},"json");
		}
	}
}

/**删除执行者*/
function remove_user(user_id,task_arrange_id){
	$("#"+user_id+"_tr").remove();
}

var upload_attr_id;//部门ID
var dept_task_id;//部门任务主键ID
/**异步上传附件*/
function upload_attr(deptId,deptTaskId){
	upload_attr_id = deptId;
	dept_task_id = deptTaskId;
	$("#dept_attr_file").click();
}
$("input#dept_attr_file").live("change",function(){
	$.ajaxFileUpload({
        url             : "/pc/common/uploadAttr", //需要链接到服务器地址
        secureuri       : false,
        fileElementId   : "dept_attr_file", //文件选择框的id属性
        dataType        : "JSON", //服务器返回的格式
        success     	: function(data,status){
//        	$("[name='formMap[task_content]']").val(data);
        	var dataStr = (data+"").replace('<pre style="word-wrap: break-word; white-space: pre-wrap;">',"").replace("</pre>","");
        	var dataJSON = jQuery.parseJSON(dataStr);
        	$("#"+upload_attr_id+"_button").val("附件："+dataJSON.attachment_name);
        	$("#"+upload_attr_id+"_name").val(dataJSON.attachment_name);
        	$("#"+upload_attr_id+"_url").val(dataJSON.attachment);
        	modify_depttask(this,upload_attr_id,dept_task_id,'attr');
        },
        error : function(data, status, e){alert("上传附件失败，请联系系统管理员");}
    });
});

/**提交*/
function to_submit(){
	if(isNull()){art.dialog.tips("计划时间不能为空",4);return false;}
	var user_count = 0;
	$("input[name='formMap[dept_ids]']").each(function(count){
		user_count = count+1;
	});
	$("input[name='formMap[sg_id]']").each(function(count){
		user_count = count+1;
	});
	if(user_count > 0){
		if(window.confirm("是否确认发布？")){
			$("form#edit_form").submit();
		}
	}else{
		alert("请选择主办单位");
	}
}

///**开始执行事项（查看页面）*/
//function startPerformTasks(){
//	if(window.confirm("开始执行当前任务")){
//		$("#startPerformTasks").submit();
//	}
//}
//
///**结束事项（查看页面）*/
//function over_tasks(){
//	if(window.confirm("是否结束当前事项")){
//		$("#over_tasks").submit();
//	}
//}

function changeDate(obj){
	var val = $(obj).val();
	if(val == "A" || val == "B"){
		$("#wt_opt_date_day").attr("name","formMap[wt_opt_date]");
		$("#wt_opt_date_week").attr("name","temp");
		$("#wt_opt_date_daytext").attr("name","temp");
		$("#wt_opt_date_day").show();
		$("#wt_opt_date_week").hide();
		$("#wt_opt_date_daytext").hide();
	}else if(val == "C" || val == "D"){
		$("#wt_opt_date_day").attr("name","temp");
		$("#wt_opt_date_daytext").attr("name","temp");
		$("#wt_opt_date_week").attr("name","formMap[wt_opt_date]");
		$("#wt_opt_date_day").hide();
		$("#wt_opt_date_daytext").hide();
		$("#wt_opt_date_week").show();
	}else{
		$("#wt_opt_date_day").attr("name","temp");
		$("#wt_opt_date_week").attr("name","temp");
		$("#wt_opt_date_daytext").attr("name","formMap[wt_opt_date]");
		$("#wt_opt_date_day").hide();
		$("#wt_opt_date_week").hide();
		$("#wt_opt_date_daytext").show();
	}
}
if($("#wt_opt_type_val").val() != ""){
	changeDate($("#wt_opt_type"));
}
function change_project_week(obj){
	var o_val = $(obj).val();
	var wot = $("option[value='"+o_val+"']").attr("o_type");
	$("#wt_opt_type").val(wot);
	changeDate($("#wt_opt_type"));
	$("#wt_opt_date_day").val($("option[value='"+o_val+"']").attr("o_date"));
	$("#wt_opt_date_week").val($("option[value='"+o_val+"']").attr("o_date"));
}