/**改变选择框颜色*/
function changeVal(attr){
	if($("#"+attr).val() != ""){
		$("#"+attr).css("border","");
	}
}
/**事项内容报表*/
function reportOutput(){
	if($("#wpt_type_id").val() != ""){
		$("#LIST_SEARCH_FORM").attr("action","/pc/worktask/reportResult");
		$("#LIST_SEARCH_FORM").attr("target","_blank");
		$("#LIST_SEARCH_FORM").submit();
	}else{
		$("#wpt_type_id").css("border","1px solid red");
		art.dialog.tips("请选择事项类型",4);
	}
}
/**图形报表*/
function statisticalAnalysis(){
	if($("#wpt_type_id").val() != ""){
		$("#LIST_SEARCH_FORM").attr("action","/pc/worktask/projectReport");
		$("#LIST_SEARCH_FORM").attr("target","");
		$("#LIST_SEARCH_FORM").submit();
	}else{
		$("#wpt_type_id").css("border","1px solid red");
		art.dialog.tips("请选择事项类型",4);
	}
}
/**其他报表*/
function otherReport(){
	$("#LIST_SEARCH_FORM").attr("action","/pc/worktask/otherReport");
	$("#LIST_SEARCH_FORM").attr("target","_blank");
	$("#LIST_SEARCH_FORM").submit();
}


var xData = new Array();
var yData = new Array();
var echarts_title = "事项进度";
var wptTypeId = $("#wpt_type_id").val();
if(wptTypeId != ""){
	echarts_title=$("option[value='"+$("#wpt_type_id").val()+"']").html();
}
if(wtList.length > 0 && wptTypeId != ""){
	for(var i=0;i<wtList.length;i++){
		xData.push($.trim(wtList[i].title));//标题
		yData.push(wtList[i].total_schedule);//进度
	}
	
	var myChart = echarts.init(document.getElementById('main'));//基于准备好的dom，初始化echarts实例
	var option = {
//	  title: {text: echarts_title,x: 'center',y: 'top',subtext: '进度详情'},
	  title: {text: echarts_title,x: 'center',y: 'top'},
	  toolbox: {//右上角工具栏
	      show : true,
	      feature : {
	          mark : {show: true},
	          dataView : {show: true, readOnly: false},
	          restore : {show: true},
	          saveAsImage : {show: true}
	      }
	  },
	  grid: { // 控制图的大小，调整下面这些值就可以，
	      x: 50,
	      x2: 50,
	      y2: 100// y2可以控制 X轴跟Zoom控件之间的间隔，避免以为倾斜后造成 label重叠到zoom上
	  },
	  //legend: {data:['事项进度'],x: 'right',y: 'center'},//底部筛选栏
	  xAxis: {data: xData,//x轴显示名称
		  axisLabel: {
		     interval: 'auto',//横轴信息全部显示
		     rotate: 0,//60度角倾斜显示
		     margin:5,
		     formatter:function(val){
		    	 return val.split("").join("\n"); //横轴信息文字竖直显示
		     }
		  }
	  },
	  tooltip : {
	      trigger: 'axis',
	      axisPointer : {            // 坐标轴指示器，坐标轴触发有效
	          type : 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
	      },
	      formatter: function (data){
	          return '&emsp;标题：'+data[0].name + '<br/>已完成：' + data[0].value +'%';
	      }
	  },
	  yAxis: {
		  type : 'value',
	      name : '完成率%',
	      axisLabel : {
	          formatter: '{value}'
	      }
	  },//Y轴显示数据
	  series: [//x轴数据
		   {name:'事项进度',type:'bar',stack: '总量',
			itemStyle : {normal:{label : {show: true, position: 'top',formatter: function (data){return data.value +'%';}},color:'#60A2D0'}},
			data:yData
		   }
	  ]
	};
	myChart.setOption(option);// 使用刚指定的配置项和数据显示图表。
}
