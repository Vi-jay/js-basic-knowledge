var xData = new Array();
var yData = new Array();
var y1Data = new Array();
for(var i=0;i<dt_list.length;i++){
	xData.push($.trim(dt_list[i].dept_name));//标题
	yData.push(dt_list[i].plan);//原计划
	y1Data.push(dt_list[i].dt_schedule);//已完成
}
var myChart = echarts.init(document.getElementById('main'));//基于准备好的dom，初始化echarts实例

	var option = {
	    tooltip : {
	        trigger: 'axis'
	    },
	    legend: {
	        data:['原计划','已完成']
	    },
	    toolbox: {
	        show : true,
	        feature : {
	            mark : {show: true},
	            dataView : {show: true, readOnly: false},
	            restore : {show: true},
	            saveAsImage : {show: true}
	        }
	    },
	    calculable : true,
	    xAxis : [
	        {
	            type : 'category',
//	            data : ['一月','二月','三月','四月','五月','六月','七月','八月','九月','十月','十一月','十二月'],
	            data : xData,
		        axisLabel:{
		        	interval: 'auto',//横轴信息全部显示
			   	    rotate: 0,//60度角倾斜显示
			   	    margin:5,
			   	    formatter:function(val){
			   	    	return val.split("").join("\n"); //横轴信息文字竖直显示
			   	    }
		   	  	}
	        }
	    ],
	    yAxis : [
	        {
	            type : 'value',
	            name : '完成率%',
	      	    axisLabel : {
	      	    	formatter: '{value}'
	      	    }
	        }
	    ],
	    series : [
	        {
	            name:'原计划',
	            type:'bar',
	            itemStyle : {normal:{label : {show: true, position: 'top',formatter: function (data){return data.value +'%';}}}},
//	            data:[2.0, 4.9, 7.0, 23.2, 25.6, 76.7, 100, 80, 32.6, 20.0, 6.4, 3.3]
	            data:yData
	        },
	        {
	            name:'已完成',
	            type:'bar',
	            itemStyle : {normal:{label : {show: true, position: 'top',formatter: function (data){return data.value +'%';}}}},
//	            data:[2.6, 5.9, 9.0, 26.4, 28.7, 70.7, 99, 70, 48.7, 18.8, 6.0, 2.3]
	        	data:y1Data
	        }
	    ]
	};
	myChart.setOption(option);// 使用刚指定的配置项和数据显示图表。