$(document).ready(function(){
	$("form#edit_form").validate({
		rules : {
			"formMap[dt_schedule_describe]" : {required : true},
			"formMap[dt_next_plan]" : {required : true},
			"formMap[submit_cycle_select]" : {required : true},
			"formMap[dt_schedule_evaluate]" : {required : true}
		},
		messages : {
			"formMap[dt_schedule_describe]" : {required : ""},
			"formMap[dt_next_plan]" : {required : ""},
			"formMap[submit_cycle_select]" : {required : "选择周期"},
			"formMap[dt_schedule_evaluate]" : {required : true}
		},
		errorPlacement:function(error,element){}
	});
});

/**设置年份以及月份*/
function choose_cycle(obj){
	var o_year = $("option[value='"+($(obj).val())+"']").attr("o_year");
	var o_date = $("option[value='"+($(obj).val())+"']").attr("o_date");
	$("#dt_submit_year").val(o_year);
	$("#dt_submit_time").val(o_date);
}

/**取消*/
function close_art(){
	parent.close_dialog();
}
if(dt_session_mark == "CLOSE"){
	parent.window.location.reload();
}