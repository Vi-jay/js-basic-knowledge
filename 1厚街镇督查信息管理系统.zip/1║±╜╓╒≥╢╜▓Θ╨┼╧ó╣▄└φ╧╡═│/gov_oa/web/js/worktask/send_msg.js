/**发送提醒或者督办消息*/
function send_msg(width,c_title,id){
	if($("#login_user_id").val() == ""){
		var send_msg_html = '<font style="font-size:12px;">事项：'+c_title;
		send_msg_html += '<br><br><input type="radio" name="send_opt_type" value="0" checked="checked">提醒';
		send_msg_html += '&emsp;&emsp;<input type="radio" name="send_opt_type" value="1">督办';
		send_msg_html += '<br><br><textarea style="width: '+width+';height: 128px;" id="send_msg_content" placeholder="填写发送内容"></textarea>';
		send_msg_html += '<br><br><input type="checkbox" mark="send_msg_checkbox" value="A">主办单位';
		send_msg_html += '&emsp;&emsp;<input type="checkbox" mark="send_msg_checkbox" value="B">协办单位';
		send_msg_html += '&emsp;&emsp;<input type="checkbox" mark="send_msg_checkbox" value="C">责任领导</font>';
		art.dialog({
			id: 'send_msg_artdialog',
			title: '发送提醒或督办消息',
			content: send_msg_html,
			top: '16%',
			fixed: true,
			ok: function () {
				var send_msg_content = $("#send_msg_content").val();
				var send_obj = "";
				$(":checked[mark='send_msg_checkbox']").each(function(){
					send_obj += $(this).val()+"-";
				});
				var wnr_type = $("input[name='send_opt_type']:checked").val();
				if(send_msg_content != "" && send_obj != ''){
					$.post('/pc/newsremind/sendMsgToObj',{"formMap[wnr_type]":wnr_type,"formMap[worktask_id]":id,"formMap[wnr_explain]":send_msg_content,"formMap[send_obj]":send_obj},function(data){
						art.dialog({id:"art_tip",top: '20%',time: 3,content: "<span style='font-size:12px;padding:20px;'>发送成功</span>"});
					},"json");
				}else{
					art.dialog({id:"art_tip",top: '20%',time: 3,content: "<span style='font-size:12px;padding:20px;'>请填写内容并选择发送对象</span>"});
					return false;
				}
			},
			cancel: true
		});
	}
}