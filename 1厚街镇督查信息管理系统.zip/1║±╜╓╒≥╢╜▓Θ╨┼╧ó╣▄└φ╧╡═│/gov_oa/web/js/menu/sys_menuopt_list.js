/**
 * @author 谭文广
 */
$(document).ready(function(){
	/**注册全选、反选事件*/
	Utils.selectCheckbox();
	
	/**为页面指定按钮注册是否已经选择数据事件*/
	Utils.verifySelection();
	
	/**为页面按钮添加单数据操作提示*/
	Utils.singleDataOperate();
	
});