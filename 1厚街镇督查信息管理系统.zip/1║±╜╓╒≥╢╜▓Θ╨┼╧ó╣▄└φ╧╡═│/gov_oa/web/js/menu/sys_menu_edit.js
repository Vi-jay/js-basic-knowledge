/**
 * @author 谭文广
 */
$(document).ready(function(){
	/**为页面指定提交按钮注册是否倒计时事件*/
	Utils.submitCountDown();
	
	$("form#edit_form").validate({
		rules : {
			"formMap[menu_name]" : {required : true},
			"formMap[menu_code]" : {required : true},
			"formMap[menu_sequence]" : {required : true,digits : true},
			"formMap[menu_link]" : {required : true}
		},
		messages : {
			"formMap[menu_name]" : {required : ""},
			"formMap[menu_code]" : {required : ""},
			"formMap[menu_sequence]" : {required : "",digits : "必须填写数字"},
			"formMap[menu_link]" : {required : ""}
		}
	});
	
});

/**验证编码是否存在*/
function verificationMenuCode(val){
	$("#font_tip").hide();
	if(val && val != ""){
		var menu_id = $("#menu_id_hidden").val();
		$.post("/pc/menu/verificationMenuCode",{"formMap[menu_code]":val,"formMap[menu_id]":menu_id},function(data){
			if(data.result == "Y"){
				$("input[name='formMap[menu_code]']").val("");
				$("#font_tip").show();
			}else{
				$("#font_tip").hide();
			}
		},"json");
	}
}