/**
 * @author 谭文广
 */
$(document).ready(function(){
	/**为页面指定提交按钮注册是否倒计时事件*/
	Utils.submitCountDown();
	
	$("form#edit_form").validate({
		rules : {
			"formMap[menu_id]" : {required : true},
			"formMap[opt_name]" : {required : true},
			"formMap[opt_code]" : {required : true}
		},
		messages : {
			"formMap[menu_id]" : {required : ""},
			"formMap[opt_name]" : {required : ""},
			"formMap[opt_code]" : {required : ""}
		}
	});
	
});

/**验证编码是否存在*/
function verificationOptCode(val){
	$("#font_tip").hide();
	if(val && val != ""){
		var menuopt_id = $("#menuopt_id_hidden").val();
		$.post("/pc/menuopt/verificationOptCode",{"formMap[opt_code]":val,"formMap[menuopt_id]":menuopt_id},function(data){
			if(data.result == "Y"){
				$("input[name='formMap[opt_code]']").val("");
				$("#font_tip").show();
			}else{
				$("#font_tip").hide();
			}
		},"json");
	}
}