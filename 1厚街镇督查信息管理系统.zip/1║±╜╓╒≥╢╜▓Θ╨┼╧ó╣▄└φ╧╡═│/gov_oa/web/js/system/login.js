/**登录*/
function login(){
	$("#login_form").submit();
}

/**回车事件登录*/
$(function(){
	document.onkeydown = function(e){
		var ev = document.all ? window.event : e;
	    if(ev.keyCode==13) {
	    	login();
	    }
	};
});
