/**
 * @author 谭文广
 */
$(document).ready(function(){
	/**为页面指定提交按钮注册是否倒计时事件*/
	Utils.submitCountDown();
	
	$("form#edit_form").validate({
		rules : {
			"formMap[mobile_phone]" : {required : true,digits : true},
			"formMap[qq]" : {digits : true},
			"formMap[real_name]" : {required : true}
		},
		messages : {
			"formMap[mobile_phone]" : {required : "",digits : "手机号码格式出错"},
			"formMap[qq]" : {digits : "QQ号码格式出错"},
			"formMap[real_name]" : {required : "不能为空"}
		}
	});
	
	$("form#edit_form_password").validate({
		rules : {
			"formMap[password]" : {required : true,minlength : 6},
			"formMap[confirm_password]" : {required : true,minlength : 6,equalTo : "#password"}
		},
		messages : {
			"formMap[password]" : {required : "",minlength : "密码长度必须大于5位"},
			"formMap[confirm_password]" : {required : "",minlength : "两次密码不一致",equalTo : "两次密码不一致"}
		}
	});
	
	if($("#tip_type").val() != ""){
		art.dialog.tips("修改成功",4);
	}
	
});


/**验证真实姓名唯一性*/
function verificationRealName(val){
	$("#font_tip_real_name").hide();
	if(val && val != ""){
		var user_id = $("#user_id_hidden").val();//当前修改用户ID
		$.post('/pc/judge/fieldRepeat',{"formMap[id]":"user_id","formMap[table]":"mb_sys_user","formMap[con]":"real_name="+val},function(data){
			if(data.result != "N" && user_id != data.id){
				$("input#real_name").val("");
				$("#font_tip_real_name").show();
			}else{
				$("#font_tip_real_name").hide();
			}
		},"json");
	}
}

/**验证私人手机号码唯一性*/
function verificationMobilePhone(val){
	$("#font_tip_mobile_phone").hide();
	if(val && val != ""){
		var user_id = $("#user_id_hidden").val();//当前修改用户ID
		$.post('/pc/judge/fieldRepeat',{"formMap[id]":"user_id","formMap[table]":"mb_sys_user","formMap[con]":"mobile_phone="+val},function(data){
			if(data.result != "N" && user_id != data.id){
				$("input#mobile_phone").val("");
				$("#font_tip_mobile_phone").show();
			}else{
				$("#font_tip_mobile_phone").hide();
			}
		},"json");
	}
}