/**选择组*/
function choose_deptgroup_result(){
	var ids = new Array();
	var names = new Array();
	$(":checked[name='temp']").each(function(i){
		ids[i] = $(this).val();
		names[i] = $(this).attr("id");
	});
	if(ids.length > 0 && names.length > 0){
		parent.choose_deptgroup_result($("#attr").val(),ids,names);
	}else{
		alert("请选择单位群组");
	}
}

/**根据组选择部门*/
function findDeptByGroup(){
	var ids = new Array();
	var names = new Array();
	var groupIds = "";
	$(":checked[name='temp']").each(function(i){
		groupIds += "'"+$(this).val()+"',";
	});
	if(groupIds != ""){
		$.post("/pc/deptgroup/findDeptByGroup",{"formMap[groupIds]":groupIds},function(data){
			if(data.list.length && data.list.length > 0){
				for(index in data.list){
					ids[index] = data.list[index].dept_id;
					names[index] = data.list[index].dept_name;
				}
				parent.choose_dept_result($("#attr").val(),ids,names);
			}
		},"json");
	}else{
		alert("请选择单位群组");
	}
}

/**取消*/
function close_art(){
	parent.close_dialog();
}