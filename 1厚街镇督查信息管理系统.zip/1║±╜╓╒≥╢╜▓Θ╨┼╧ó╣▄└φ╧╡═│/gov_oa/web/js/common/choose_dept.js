/**确定*/
function choose_dept_result(){
	var ids = new Array();
	var names = new Array();
	$(":checked[name='temp']").each(function(i){
		ids[i] = $(this).val();
		names[i] = $(this).attr("id");
	});
	if(ids.length > 0 && names.length > 0){
		parent.choose_dept_result($("#attr").val(),ids,names);
	}else{
		alert("请选择部门");
	}
}

/**选择所有部门*/
function choose_all(){
	$(":checkbox").each(function(i){
		$(this).attr("checked",true);
	});
	choose_dept_result();
}

/**取消*/
function close_art(){
	parent.close_dialog();
}