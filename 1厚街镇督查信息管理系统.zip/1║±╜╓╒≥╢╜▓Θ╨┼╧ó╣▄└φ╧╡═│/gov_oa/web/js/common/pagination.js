var page_count = $("#HIDDEN_PAGE_COUNT").val();//数据总数
var page_current = $("#HIDDEN_PAGE_CURRENT").val();//当前页
var page_pageCount = $("#HIDDEN_PAGE_PAGECOUNT").val();//每页总条数
var total_pages = 0;
if(page_count != "" && page_current != "" && page_pageCount != null){
	page_count = parseInt(page_count);
	page_current = parseInt(page_current);
	page_pageCount = parseInt(page_pageCount);
	total_pages = Math.ceil(page_count/page_pageCount);
	$("#total_pages").html(total_pages);/**显示总页数*/
}

/**单页操作*/
function toJumpPage(type){
	if(total_pages == 0){
		return false;
	}
	if(type=="first_page" && page_current != 1){
		$("#current_page_hidden").val("1");
		$("#LIST_SEARCH_FORM").submit();
	}else if(type=="back_page" && page_current > 1){
		$("#current_page_hidden").val(page_current-1);
		$("#LIST_SEARCH_FORM").submit();
	}else if(type=="next_page" && page_current != total_pages){
		$("#current_page_hidden").val(page_current+1);
		$("#LIST_SEARCH_FORM").submit();
	}else if(type=="last_page" && page_current != total_pages){
		$("#current_page_hidden").val(total_pages);
		$("#LIST_SEARCH_FORM").submit();
	}
}

/**跳转到指定页*/
function toJumpWhichPage(page_num){
	if(page_num && page_num != ""){
		page_num = $.trim(page_num);
		var regx=/^\+?[1-9][0-9]*$/;
		if(regx.test(page_num) && total_pages >= page_num && page_num != page_current){
			$("#current_page_hidden").val(page_num);
			$("#LIST_SEARCH_FORM").submit();
		}else{
			$("#which_page_value").val("");
		}
	}
}

/**改变一页显示数量*/
function searchByChangePagecount(){
	$("#LIST_SEARCH_FORM").submit();
}