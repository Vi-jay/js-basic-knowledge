/**
 * 工具类
 * @returns
 */
var Utils = (function() {
	var Utils = function() {};
	
	/**提交倒计时*/
	Utils.submitCountDown = function(){
		 var submitBtns = $(document).find("input:submit,input.submitButton,input.input_btn_style3");
		 var time = 6;
		 //提交时倒数(提交延时的时候可以看到倒数效果）
		 var _submitTimeout =  function(time,_submitBtn,_viewSubmitBtn){
			 _viewSubmitBtn.val("请稍候...("+time+")");
			 time--;
			if(time>=0){ 
				window.setTimeout(function(){
					_submitTimeout(time,_submitBtn,_viewSubmitBtn);
				}, 1000);
			}else{
				_submitBtn.show();
				_viewSubmitBtn.remove();
			}
		 };
		 // 提交事件点击事件
		 $(submitBtns).click(function(){
			 var submitBtn = $(this);
			 submitBtn.hide();
			 var viewSubmitBtn = $("<input type='button' class='"+this.className+"' value='请稍候...'/>");
			 submitBtn.after(viewSubmitBtn);
			 //form.submit(function(){return false;});
			 _submitTimeout(time,submitBtn,viewSubmitBtn);
		 });
	};
	
	/**表单提交方式返回上一页*/
	Utils.backToPage = function(url){
		var html_form = "<form id='back_page_form' method='post' action='"+url+"'></form>";
		$("body").append(html_form);
		$("form#back_page_form").submit();
	};
	
	/**全选、反选*/
	Utils.selectCheckbox = function(){
		$(":checkbox#LIST_CHECKBOX_HEADER").click(function(){
			if($(this).attr("checked")){
				$(":checkbox[id='LIST_CHECKBOX_DETAIL']").attr("checked",true);
			}else{
				$(":checkbox[id='LIST_CHECKBOX_DETAIL']").attr("checked",false);
			}
		});
	};
	
	/**为页面按钮添加是否选中数据*/
	Utils.verifySelection = function(){
		$("a[MARK='LIST_SELECT_DATA'],:button[MARK='LIST_SELECT_DATA'],:submit[MARK='LIST_SELECT_DATA']").live("click",function(){
			var flag = false;
			if($(":checkbox[id='LIST_CHECKBOX_DETAIL']:checked").attr("checked")){
				flag = true;
			}
			if(flag){
				var tipInfo = "";//获取标签内容
				if("A" == $(this)[0].tagName){
					tipInfo = $.trim($(this).html());//获取A标签内容
				}else{
					tipInfo = $(this).val();//获取按钮内容
				}
				if(window.confirm("是否确定"+tipInfo+"？")){//判断操作
					$("#LIST_SEARCH_FORM").attr("action",$(this).attr("URL"));
					$("#LIST_SEARCH_FORM").submit();
					return true;
				}else{
					return false;
				}
			}else{
				alert("请选择您将要处理的数据");
				return false;
			}
		});
	};
	
	/**为页面按钮添加单数据操作提示*/
	Utils.singleDataOperate = function(){
		$("a[MARK='SINGLE_DATA_OPERATE'],:button[MARK='SINGLE_DATA_OPERATE'],:submit[MARK='SINGLE_DATA_OPERATE']").live("click",function(){
			var tipInfo = "";//获取标签内容
			if("A" == $(this)[0].tagName){
				tipInfo = $.trim($(this).html());//获取A标签内容
			}else{
				tipInfo = $(this).val();//获取按钮内容
			}
			if(window.confirm("是否确定"+tipInfo+"？")){//判断操作
				window.location.href = $(this).attr("URL");
				return true;
			}else{
				return false;
			}
		});
	};
	
	return Utils;
})();
