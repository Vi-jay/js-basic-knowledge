$("input:text").css("border","1px solid #CECECE");

/**返回上一页*/
$("#return_page").click(function(){
	window.history.back();
});
/**返回上一页（URL请求模式）*/
$("#back_page").click(function(){
	var h_tag = '<form id="BACK_PAGE_FORM" action="'+($(this).attr("URL"))+'" method="post"></form>';
	$("body").append(h_tag);
	$("#BACK_PAGE_FORM").submit();
});

/**放大缩小事件*/
$("#full_span").click(function(){
	window.parent.change_screen();
});

/**全局提示*/
$("#full_span").attr("title","全屏切换显示");

/**选择用户弹出框
 * attr 标签属性：用于结果回调时唯一标识
 * type 选择类型：R为单选，C为多选
 * deptId 部门ID：用户条件过滤
 * */
function choose_user(attr,type,deptId,h,w){
	art.dialog.open("/pc/user/toChooseUserPage?formMap[attr]="+attr+"&formMap[choose_type]="+type+"&formMap[dept_id]="+deptId,
			{id: 'choose_user',background: 'white',opacity: 0.6,lock:true,fixed: true, title: "选择用户",height:h, width:w});
}
/**关闭所有弹出框*/
function close_dialog(){
	var list = art.dialog.list;
	for (var i in list) {
	    list[i].close();
	}
}

/**选择部门弹出框
 * attr 标签属性：用于结果回调时唯一标识
 * type 选择类型：R为单选，C为多选
 * */
function choose_dept(attr,type){
	art.dialog.open("/pc/dept/toChoosedeptPage?formMap[attr]="+attr+"&formMap[choose_type]="+type,
			{id: 'choose_dept',background: 'white',opacity: 0.6,lock:true,fixed: true, title: "选择部门",height:'350px', width:'700px'});
}

/**选择部门群组弹出框
 * attr 标签属性：用于结果回调时唯一标识
 * type 选择类型：R为单选，C为多选
 * */
function choose_groupdept(attr,type){
	art.dialog.open("/pc/deptgroup/chooseDeptGroup?formMap[attr]="+attr+"&formMap[choose_type]="+type,
			{id: 'choose_groupdept',background: 'white',opacity: 0.6,lock:true,fixed: true, title: "选择部门群组",height:'90%', width:'90%'});
}

$("textarea").live("keypress blur",function(){
	var entry_length_sign = $(this).attr("entrylength");
	if(entry_length_sign && entry_length_sign != ""){
		$(this).val($.trim(($(this).val()).substring(0,parseInt(entry_length_sign)-1)));
	}
});
/**非空验证*/
function isNull(){
	var flag = false;//默认非空
	$("input[MARK='VERIFICATION']").each(function(){
		if($(this).val() == ""){
			flag = true;//为空，需提醒
		}
	});
	$("textarea[MARK='VERIFICATION']").each(function(){
		if($(this).val() == ""){
			flag = true;//为空，需提醒
		}
	});
	return flag;
}

/**删除附件（通用）*/
function removeAttr(type,id){
	art.dialog.confirm("删除后无法恢复，是否确认删除？", function () {
		$.post("/pc/common/removeAttr",{"formMap[type]":type,"formMap[id]":id},function(data){
			$("#attr_"+id).remove();
			art.dialog.tips("成功删除附件",3);
		},"json");
	}, function () {
	});
}

/**绑定列表页中的下拉框自动搜索功能*/
$("select.mrb").live("change",function(){
	$("form#LIST_SEARCH_FORM").submit();
});
