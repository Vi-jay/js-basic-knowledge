$("input[MARK='TAB']").each(function(){
	var attribute = $(this).attr("class");
	var value = $(this).val();
	$("div[VM_CLASS='"+attribute+"'][VM_VALUE='"+value+"']").attr("class","tab_button_curr");
	$("td[VM_CLASS='"+attribute+"'][VM_VALUE='"+value+"']").attr("class","tab_button_curr");
});

$("div.tab_button_curr").live("click",function(){search_for_tab($(this));});
$("div.tab_button_other").live("click",function(){search_for_tab($(this));});
$("td.tab_button_curr").live("click",function(){search_for_tab($(this));});
$("td.tab_button_other").live("click",function(){search_for_tab($(this));});

function search_for_tab(obj){
	var VM_CLASS = $(obj).attr("VM_CLASS");
	var VM_VALUE = $(obj).attr("VM_VALUE");
	$("input."+VM_CLASS).val(VM_VALUE);
	$("#LIST_SEARCH_FORM").submit();
}