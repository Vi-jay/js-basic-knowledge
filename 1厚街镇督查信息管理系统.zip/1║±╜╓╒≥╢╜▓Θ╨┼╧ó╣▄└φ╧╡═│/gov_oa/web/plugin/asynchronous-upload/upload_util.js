var result_url_hidden_id;
var result_filename_id;
var result_url_img_id;
/**
 * 异步上传文件方法
 * param type 请求来源/标识
 * return JSON格式结果
 */
function upload_file_init(type){
	$("input#asynchronous_upload_input").attr("name","file");
	$.ajaxFileUpload({
		url             : "/pc/common/uploadAttr", //需要链接到服务器地址
		secureuri       : false,
		fileElementId   : "asynchronous_upload_input", //文件选择框的id属性
		dataType        : "JSON", //服务器返回的格式
		success     	: function(data,status){
			$("input#asynchronous_upload_input").attr("name","");
			$("input#asynchronous_upload_input").val("");
			var dataStr = (data+"").replace('<pre style="word-wrap: break-word; white-space: pre-wrap;">',"").replace("</pre>","");
			var dataJSON = jQuery.parseJSON(dataStr);
			$("input#"+result_url_hidden_id).val(dataJSON.attachment);//默认设置URL路径
			$("input#"+result_filename_id).val(dataJSON.attachment_name);//设置文件名
			$("img#"+result_url_img_id).attr("src",img_url+(dataJSON.attachment));//默认直接显示图片
			upload_file_result(dataJSON,type);//结果回调函数
		},
		error : function(data, status, e){alert("上传附件失败，请联系系统管理员");}
	});
}
var upload_text;
$(":text[MARK='UPLOAD_TEXT']").live("click",function(){//上传文本框点击事件触发文件上传控件
	upload_text = $(this);
	$("#asynchronous_upload_input").click();//文件上传控件
});
$("input#asynchronous_upload_input").live("change",function(){//监听文件上传控件
	$(upload_text).val($(this).val());
});
$(":button[MARK='UPLOAD_BUTTON']").live("click",function(){//上传按钮
	result_url_hidden_id = $(this).attr("result_mark");//回调标识（隐藏域值/数据库字段）
	result_filename_id = $(this).attr("result_file_name");//回调标识（图片文件名）
	result_url_img_id = $(this).attr("result_img");//回调标识（图片显示标签）
	var upload_temp_val = $("input#asynchronous_upload_input").val();
	if(upload_temp_val != undefined && upload_temp_val != null && upload_temp_val != ""){
		upload_file_init(result_url_hidden_id);
		alert("上传成功");
	}else{
		alert("请选择上传文件");
	}
});