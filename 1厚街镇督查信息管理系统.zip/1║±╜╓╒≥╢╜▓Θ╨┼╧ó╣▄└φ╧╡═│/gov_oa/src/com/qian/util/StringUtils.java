package com.qian.util;

/**
 * 时间工具类
 * @author Chonghui
 */
public class StringUtils {
	
	/**
	 * 判断非空对象或非空值
	 * @param obj
	 * @return
	 */
	public static boolean isNotNull(Object obj) {
		if(obj != null && obj.toString().trim().length() > 0){
			return true;
		}else{
			return false;
		}
	}
	
	/**
	 * 判断空对象或空值
	 * @param obj
	 * @return
	 */
	public static boolean isNull(Object obj) {
		if(obj == null || (obj != null && obj.toString().trim().length() < 1)){
			return true;
		}else{
			return false;
		}
	}
	
}
