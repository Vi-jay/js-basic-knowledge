package com.qian.util;

import java.util.List;
import java.util.Map;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;

/**
 * @author zhanglb
 */
public class RightsRowTag extends TagSupport {
	/**
	 */
	private static final long serialVersionUID = 7112587565936794785L;

	/**
	 * 列类型
	 */
	private String rowType;
	
	/**
	 * td内容
	 */
	private String text;
			
	/**
	 * alt 标题文字
	 */
	private String title;

	/**
	 * <a>链接样式
	 */
	private String cssClass;

	/**
	 * 权限代码
	 */
	private String rightCode;

	/**
	 * 单击事件
	 */
	private String onclick;

	/**
	 * 元素Id
	 */
	private String elementId;

	/**
	 * 链接内嵌元素
	 */
	private String html;

	public String getRowType() {
		return rowType;
	}

	public void setRowType(String rowType) {
		this.rowType = rowType;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public String getRightCode() {
		return rightCode;
	}

	public void setRightCode(String rightCode) {
		this.rightCode = rightCode;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getCssClass() {
		return cssClass;
	}

	public void setCssClass(String cssClass) {
		this.cssClass = cssClass;
	}

	public String getOnclick() {
		return onclick;
	}

	public void setOnclick(String onclick) {
		this.onclick = onclick;
	}

	public String getElementId() {
		return elementId;
	}

	public void setElementId(String elementId) {
		this.elementId = elementId;
	}

	public String getHtml() {
		return html;
	}

	public void setHtml(String html) {
		this.html = html;
	}

	public int doAfterBody() throws JspException {
		try {
			return (SKIP_BODY);
		} catch (Exception ex) {

			throw new JspException(ex);
		}
	}

	@SuppressWarnings("unused")
	public int doEndTag() throws JspException {
		try {
			StringBuffer sbContent = new StringBuffer("");
			// 从session里面获取登录用户的分配操作功能权限列表
//			List<Map<String, Object>> menuOptList = SessionUtil.getLoginUserOpt(pageContext.getSession(),true);
			List<Map<String, Object>> menuOptList = null;
			if (menuOptList != null) {

				Map<String, Object> right = null; // 权限对象
				for (Map<String, Object> rightMap : menuOptList) {
					// 根据自定义标签配置的rightCode 与分配的操作权限是否一致
					if (rightMap.get("opt_code") != null && rightMap.get("opt_code").equals(rightCode.trim())) {
						right = rightMap;
						break;
					}
				}
				if (cssClass == null) {
					cssClass = "";
				}
				// 找到权限或者是超级管理员
				if (right != null) {
					
					if("th".equals(rowType)){
						sbContent.append("<th class=\"" + cssClass + "\"");
					}else{
						sbContent.append("<td class=\"" + cssClass + "\"");
					}

					if (elementId != null && !"".equals(elementId)) {
						sbContent.append(" id= \"" + elementId + "\" ");
					}
					if (title != null && !"".equals(title)) {
						sbContent.append(" title=\"" + title + "\" ");
					}
					if (onclick != null && !"".equals(onclick)) {
						sbContent.append(" onclick=\"" + onclick + "\"");
					}
					sbContent.append(">");
					
					if(null != text && !"".equals(text.trim())) {
						sbContent.append(text.trim()); 
					}
					
					if("th".equals(rowType)){
						sbContent.append("</th>");
					}else{
						sbContent.append("</td>");
					}
					
				}
			}
			JspWriter out = this.pageContext.getOut();
			out.print(sbContent.toString());
		}
		catch (Exception ex) {
			ex.printStackTrace();
			throw new JspException(ex);
		}
		return super.doEndTag();
	}
}
