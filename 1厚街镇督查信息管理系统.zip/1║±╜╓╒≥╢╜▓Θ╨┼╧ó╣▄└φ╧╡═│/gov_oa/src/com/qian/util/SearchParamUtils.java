package com.qian.util;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

/**
 * 搜索参数处理
 * @author Chonghui
 */
public class SearchParamUtils {
	
	/**
	 * 保留搜索条件
	 * @param request
	 * @param formMap
	 * @param searchKey
	 */
	@SuppressWarnings("unchecked")
	public static void saveOrGetSearchParam(HttpServletRequest request,FormMap formMap,String searchKey){
		if(StringUtils.isNull(formMap.getFormMap().get("search_param_mark"))){
			Object obj = request.getSession().getAttribute(searchKey);
			if(obj != null){
				Map<String,Object> sessionMap = (Map<String, Object>) obj;
				if(sessionMap.size() > 0){
					for(Map.Entry<String, Object> entry : sessionMap.entrySet()){
						formMap.getFormMap().put(entry.getKey(),entry.getValue());
					}
				}
			}
		}else{
			request.getSession().setAttribute(searchKey, formMap.getFormMap());
		}
	}
	
}
