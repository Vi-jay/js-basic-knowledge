package com.qian.util;
import java.util.List;
import java.util.Map;
import com.alibaba.fastjson.JSONObject;
import com.baidu.yun.core.log.YunLogEvent;
import com.baidu.yun.core.log.YunLogHandler;
import com.baidu.yun.push.auth.PushKeyPair;
import com.baidu.yun.push.client.BaiduPushClient;
import com.baidu.yun.push.constants.BaiduPushConstants;
import com.baidu.yun.push.model.PushBatchUniMsgRequest;

public class BaiduPushTool {
	
	private static String channelIdStr = "";
	private static String pushStr = "";
	
	public static void push(String[] channelIds,String msg){
		//批量发送
        String apiKey = "uk4OsNyQceQlO3zsTw1dPXDU";
        String secretKey = "LckiRcI6Pr2HacAXMNTsp6ScOKy3OWoR";
        PushKeyPair pair = new PushKeyPair(apiKey, secretKey);
        
        BaiduPushClient pushClient = new BaiduPushClient(pair,BaiduPushConstants.CHANNEL_REST_URL);
        pushClient.setChannelLogHandler(new YunLogHandler() {
            @Override
            public void onHandle(YunLogEvent event) {
//                System.out.println(event.getMessage());
            }
        });

        try {
//            String[] channelIds = { "xxxxxxxxxxxxxxxx", "xxxxxxxxxxxxxxxxx" };
            PushBatchUniMsgRequest request = new PushBatchUniMsgRequest()
                    .addChannelIds(channelIds)
                    .addMsgExpires(new Integer(3600))
                    .addMessageType(1)
//                    .addMessage("{\"title\":\"TEST\",\"description\":\"Hello Baidu push!\"}")
                    .addMessage(msg)
                    .addDeviceType(3).addTopicId("BaiduPush");// 设置类别主题
            pushClient.pushBatchUniMsg(request);//开始推送
//            PushBatchUniMsgResponse response = pushClient.pushBatchUniMsg(request);//开始推送
            // Http请求返回值解析
//            System.out.println(String.format("msgId: %s, sendTime: %d",response.getMsgId(), response.getSendTime()));
        } catch (Exception e) {
        	e.printStackTrace();
        }
		
	}

	public static boolean push(List<Map<String,Object>> userList,String title,String description,JSONObject paramJson){
		if(userList != null && userList.size() > 0 && StringUtils.isNotNull(title) && StringUtils.isNotNull(description)){
			StringBuffer buffer = new StringBuffer(); 
			for(int i = 0;i<userList.size();i++){
				if(!"no".equals(userList.get(i).get("channel_id").toString())){
					buffer.append(userList.get(i).get("channel_id").toString()+",");
				}
			}
			JSONObject push = new JSONObject();
			push.put("title",title);
			push.put("description",description);
			push.put("custom_content",paramJson);
			if(buffer.toString().length() > 0){
				channelIdStr = buffer.toString().substring(0, buffer.toString().length()-1);
				pushStr = push.toJSONString();
				Thread t = new Thread(new Runnable(){
					public void run(){
						BaiduPushTool.push(channelIdStr.split(","),pushStr);
			        }
				});  
			    t.start();
				return true;
			}
		}
		return false;
	}
	
	public static void main(String[] args) {
		String[] channelIds = {"3538601755566342040"};
		JSONObject push = new JSONObject();
		JSONObject obj = new JSONObject();
		push.put("title","苗诚OA发布了新版本");
		push.put("description","点击更新最新版本V1.1");
		obj.put("activity","DownloadAPPActivity");
		push.put("custom_content",obj);
		BaiduPushTool.push(channelIds, push.toJSONString());
	}
}
