package com.qian.util;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

/**
 * @author flyman 2015-8-7
 */

public class Test {
	
	public static void main(String[] args) {
		try {
			System.out.println(URLEncoder.encode(URLEncoder.encode("完成", "UTF-8"), "UTF-8"));
		} catch (UnsupportedEncodingException e) {
		}
	}
}