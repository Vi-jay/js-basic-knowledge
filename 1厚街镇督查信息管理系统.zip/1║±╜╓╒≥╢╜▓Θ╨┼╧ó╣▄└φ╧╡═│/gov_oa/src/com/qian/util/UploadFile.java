package com.qian.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import javax.servlet.http.HttpServletRequest;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.gzdec.framework.util.UniqueIDGenerator;

/**
 * 时间工具类
 * 
 * @author Chonghui
 * 
 */
public class UploadFile {

	public static Properties config;
	static {
		Properties pro = new Properties();
		try {
			String path = UploadFile.class.getResource("/properties").getPath();
			File dic = new File(path + "/global.properties");
			pro.load(new FileInputStream(dic));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		config = pro;
	}
	
	/**
	 * 上传附件
	 */
	public static Map<String,Object> uploadAttachment(HttpServletRequest request,FormMap formMap){
		Map<String,Object> resultMap = new HashMap<String,Object>();
		try{
			//开始上传
			MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
			String logoRealPathDir = config.getProperty("attachment.path").trim();
			String datetime = DateTimeUtils.getCurFormatDate();
			logoRealPathDir = logoRealPathDir+"/"+datetime;
			File logoSaveFile = new File(logoRealPathDir);
	        if(!logoSaveFile.exists()){
	        	logoSaveFile.mkdirs();
	        }
	        /**页面控件的文件流**/
	        MultipartFile multipartFile = multipartRequest.getFile("file");
	        String old_file_name = multipartFile.getOriginalFilename();//原始文件全名
	        if(StringUtils.isNotNull(old_file_name)){
	        	long fileSize = multipartFile.getSize();
	        	if(fileSize > 5242880){//文件大小不能超过5M
	        		return resultMap;
	        	}
	        	String suffix_name = multipartFile.getOriginalFilename().substring(multipartFile.getOriginalFilename().lastIndexOf("."));
	        	String new_file_name = "";
	        	if(StringUtils.isNotNull(formMap.getFormMap().get("id"))){
	        		new_file_name = formMap.getFormMap().get("id")+suffix_name;
	        	}else{
	        		new_file_name = UniqueIDGenerator.getUUID()+suffix_name;
	        	}
	        	formMap.getFormMap().put("attachment_name",old_file_name);
	        	formMap.getFormMap().put("new_file_name",new_file_name);
	        	/**拼成完整的文件保存路径加文件**/
	        	String fileName = logoRealPathDir +"/"+ new_file_name;
	        	formMap.getFormMap().put("attachment","/"+datetime+"/"+ new_file_name);
	        	File file = new File(fileName);
	        	try {
	        		multipartFile.transferTo(file);
	        	} catch (IllegalStateException e) {
	        		e.printStackTrace();
	        	} catch (IOException e) {
	        		e.printStackTrace();
	        	}
	        }
		}catch(Exception e){
		}
        return resultMap;
	}
	
	
}
