package com.qian.util;

import java.util.List;
import java.util.Map;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;

/**
 * 自定义权限控制标签
 */
public class RightsButtonTag extends TagSupport {
	/**
	 * 
	 */
	private static final long serialVersionUID = 4570121217451308390L;

	// 按钮id
	private String elementId;

	// 按钮名称
	private String elementName;

	// 按钮显示名称
	private String value;

	// 权限代码
	private String rightCode;

	// 按钮点击事件
	private String onclick;

	// 按钮样式问题
	private String cssClass;

	// 按钮类型
	private String type;

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getRightCode() {
		return rightCode;
	}

	public void setRightCode(String rightCode) {
		this.rightCode = rightCode;
	}

	public String getOnclick() {
		return onclick;
	}

	public void setOnclick(String onclick) {
		this.onclick = onclick;
	}

	public String getCssClass() {
		return cssClass;
	}

	public void setCssClass(String cssClass) {
		this.cssClass = cssClass;
	}

	public String getElementId() {
		return elementId;
	}

	public void setElementId(String elementId) {
		this.elementId = elementId;
	}

	public String getElementName() {
		return elementName;
	}

	public void setElementName(String elementName) {
		this.elementName = elementName;
	}

	public int doAfterBody() throws JspException {
		try {
			return (SKIP_BODY);
		} catch (Exception ex) {
			throw new JspException(ex);
		}
	}

	@SuppressWarnings("unused")
	public int doEndTag() throws JspException {
		try {
			StringBuffer sbContent = new StringBuffer("");
			// 从session里面获取登录用户的分配操作功能权限列表
//			List<Map<String, Object>> menuOptList = SessionUtil.getLoginUserOpt(pageContext.getSession(),true);
			List<Map<String, Object>> menuOptList = null;
			if (menuOptList != null) {
				Map<String, Object> right = null; // 权限对象
				for (Map<String, Object> rightMap : menuOptList) {
					// 根据自定义标签配置的rightCode 与分配的操作权限是否一致
					if (rightMap.get("opt_code") != null && rightMap.get("opt_code").equals(rightCode)) {
						right = rightMap;
						break;
					}
				}
				if (value == null) {
					value = "";
				}
				if (cssClass == null) {
					cssClass = "";
				}
				if (type == null || type.equals("")) {
					type = "button";
				}
				// 找到权限或者是超级管理员
				if (right != null) {
					sbContent.append("<input type=\"" + type + "\"  value=\"" + value + "\" class=\"" + cssClass + "\"");

					if (elementId != null && !"".equals(elementId)) {
						sbContent.append(" id= \"" + elementId + "\" ");
					}
					if (elementName != null && !"".equals(elementName)) {
						sbContent.append(" name= \"" + elementName + "\" ");
					}
					if (right != null) {
						if (onclick != null && !"".equals(onclick)) {
							sbContent.append(" onclick=\"" + onclick + "\"");
						}
					}else{
						sbContent.append(" onclick='alert('你无此操作权限，请联系管理员授权!');' ");
					}
					sbContent.append("/>");
				}
			}
			JspWriter out = this.pageContext.getOut();
			out.print(sbContent.toString());
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new JspException(ex);
		}
		return super.doEndTag();
	}

}
