package com.qian.util;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;


public class SessionUtil {

	//得到session中的属性
	public static Object getInfoBySession(HttpSession session,String property){
		Object obj = null;
		if(session!=null){
			obj= session.getAttribute(property);
		}
		return obj;
	}
	
	/**
	 * 得到登陆用户id
	 * @param request
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static String getLoginUserId(HttpServletRequest request){
		Map<String,Object> map = (Map<String, Object>) SessionUtil.getInfoBySession(request.getSession(),"user");
		if(map != null && !"".equals(map.toString())){
			return (String)map.get("user_id");
		}
		return null;
	}
	
	
	/**
	 * 得到登陆用户类型
	 * @param request
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static String getLoginUserType(HttpServletRequest request){
		Map<String,Object> map = (Map<String, Object>) SessionUtil.getInfoBySession(request.getSession(),"user");
		if(map != null && !"".equals(map.toString())){
			return (String)map.get("user_type");
		}
		return null;
	}
	
	/**
	 * 得到验证码
	 * @param request
	 * @return
	 */
	public static String getInvalidationCode(HttpServletRequest request){
		Object obj = SessionUtil.getInfoBySession(request.getSession(),"code");
		if(obj != null && !"".equals(obj.toString())){
			return obj.toString();
		}
		return null;
	}
	
	/**
	 * 得到用户名
	 * @param request
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static String getUserName(HttpServletRequest request){
		Map<String,Object> map = (Map<String, Object>) SessionUtil.getInfoBySession(request.getSession(),"user");
		if(map != null && !"".equals(map.toString())){
			return (String)map.get("real_name");
		}
		return null;
	}
	
	/**
	 * 得到用户所在部门下的身份类型
	 * @param request
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static String getUserDeptType(HttpServletRequest request){
		Map<String,Object> map = (Map<String, Object>) SessionUtil.getInfoBySession(request.getSession(),"user");
		if(map != null && !"".equals(map.toString())){
			return (String)map.get("weixin_num");
		}
		return null;
	}
	
}
