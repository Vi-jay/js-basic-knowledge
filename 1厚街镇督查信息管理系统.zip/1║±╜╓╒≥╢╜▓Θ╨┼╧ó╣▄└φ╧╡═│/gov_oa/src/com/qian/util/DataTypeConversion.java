package com.qian.util;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.Map;

public class DataTypeConversion {
	
	/**
	 * 针对map进行UrlDecoder解码
	 * @param map
	 * @param coding
	 * @return
	 */
	public static Map<String,Object> urlDecoderForMap(Map<String,Object> map,String coding){
		try {
			if(map != null && map.size() > 0){
				for(Map.Entry<String, Object> entry : map.entrySet()){
					if(StringUtils.isNotNull(entry.getValue())){
						map.put(entry.getKey(), URLDecoder.decode(entry.getValue().toString(),coding));
					}else{
						map.put(entry.getKey(),entry.getValue());
					}
				}
			}
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return map;
	}
	
	
	/**
	 * 将以英文逗号分割的字符串转换为字符串数组
	 * @param ids
	 * @return
	 */
	public static String[] getIdsToArray(Object ids){
		String[] idArr = new String[1];
		if(StringUtils.isNotNull(ids)){
			if(ids.toString().trim().length() == 32){
				idArr[0] = ids.toString();
			}else{
				String[] tempArr = ids.toString().split(",");
				int i = 0;
				idArr = new String[tempArr.length];
				for(String temp : tempArr){
					if(StringUtils.isNotNull(temp)){
						idArr[i] = temp.trim();
						i++;
					}
				}
			}
		}
		return idArr;
	}
	
}
