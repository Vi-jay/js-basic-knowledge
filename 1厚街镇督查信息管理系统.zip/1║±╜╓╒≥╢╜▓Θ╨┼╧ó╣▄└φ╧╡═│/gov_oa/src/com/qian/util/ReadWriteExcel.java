package com.qian.util;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Cell;

public class ReadWriteExcel {

	/**
	 * 读取Excel的内容，第一维数组存储的是一行中格列的值，二维数组存储的是多少个行
	 * @param file 读取数据的源Excel
	 * @param ignoreRows 读取数据忽略的行数，比喻行头不需要读入 忽略的行数为1
	 * @return 读出的Excel中数据的内容
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	@SuppressWarnings("deprecation")
	public static List<Map<String,String>> getData(File file, int ignoreRows)
			throws FileNotFoundException, IOException {
		List<Map<String,String>> result = new ArrayList<Map<String,String>>();
		int rowSize = 0;
		BufferedInputStream in = new BufferedInputStream(new FileInputStream(file));
		// 打开HSSFWorkbook
		POIFSFileSystem fs = new POIFSFileSystem(in);
		HSSFWorkbook wb = new HSSFWorkbook(fs);
		Cell cell = null;
		Map<String,String> dataMap = null;
		for (int sheetIndex = 0; sheetIndex < wb.getNumberOfSheets(); sheetIndex++) {//遍历工作簿
			HSSFSheet st = wb.getSheetAt(sheetIndex);
			// 第一行为标题，不取
			for (int rowIndex = ignoreRows; rowIndex <= st.getLastRowNum(); rowIndex++) {//遍历行
				dataMap = new HashMap<String,String>();
				HSSFRow row = st.getRow(rowIndex);
				if (row == null) {
					continue;
				}
				int tempRowSize = row.getLastCellNum() + 1;
				if (tempRowSize > rowSize) {
					rowSize = tempRowSize;
				}
				for (short columnIndex = 0; columnIndex <= row.getLastCellNum(); columnIndex++) {//遍历列
					cell = row.getCell(columnIndex);//列值
					String val = "";
					if(cell != null){
						val = rightTrim(cell.toString());
//						dataMap.put(ReadExcel.fieldConversion(st.getRow(0).getCell(columnIndex)+""), val);
						ReadWriteExcel.fieldConversion(dataMap,st.getRow(0).getCell(columnIndex)+"",val);
					}
				}
				result.add(dataMap);
			}
		}
		in.close();
		return result;
	}

	
	/**
	 * 读取Excel的内容，第一维数组存储的是一行中格列的值，二维数组存储的是多少个行
	 * @param file 读取数据的源Excel
	 * @param ignoreRows 读取数据忽略的行数，比喻行头不需要读入 忽略的行数为1
	 * @return 读出的Excel中数据的内容
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	@SuppressWarnings("deprecation")
	public static List<Map<String,Object>> getOutStockData(File file, int ignoreRows)throws FileNotFoundException, IOException {
		List<Map<String,Object>> result = new ArrayList<Map<String,Object>>();
		int rowSize = 0;
		BufferedInputStream in = new BufferedInputStream(new FileInputStream(file));
		// 打开HSSFWorkbook
		POIFSFileSystem fs = new POIFSFileSystem(in);
		HSSFWorkbook wb = new HSSFWorkbook(fs);
		Cell cell = null;
		Map<String,Object> dataMap = null;
		for (int sheetIndex = 0; sheetIndex < wb.getNumberOfSheets(); sheetIndex++) {//遍历工作簿
			HSSFSheet st = wb.getSheetAt(sheetIndex);
			// 第一行为标题，不取
			for (int rowIndex = ignoreRows; rowIndex <= st.getLastRowNum(); rowIndex++) {//遍历行
				dataMap = new HashMap<String,Object>();
				HSSFRow row = st.getRow(rowIndex);
				if (row == null) {
					continue;
				}
				int tempRowSize = row.getLastCellNum() + 1;
				if (tempRowSize > rowSize) {
					rowSize = tempRowSize;
				}
				for (short columnIndex = 0; columnIndex <= row.getLastCellNum(); columnIndex++) {//遍历列
					cell = row.getCell(columnIndex);//列值
					String val = "";
					if(cell != null){
						val = rightTrim(cell.toString());
						//dataMap.put(ReadExcel.fieldConversion(st.getRow(0).getCell(columnIndex)+""), val);
						ReadWriteExcel.fieldConversionForOutStock(dataMap,st.getRow(0).getCell(columnIndex)+"",val);
					}
				}
				result.add(dataMap);
			}
		}
		in.close();
		return result;
	}
	
	
	/**
	 * 字段属性转换
	 * @param columnText
	 * @return
	 */
	private static void fieldConversion(Map<String,String> dataMap,String columnText,String val){
		String co = columnText;
		String v = val;
//		if("品种名称".equals(columnText)){
//			co = "name";
//		}else if("种植状态".equals(columnText)){
//			co = "plant_status_id";
//			if("假植苗".equals(val)){
//				v = "1";
//			}else if("袋苗".equals(val)){
//				v = "2";
//			}else if("地苗".equals(val)){
//				v = "3";
//			}
//		}else if("径类型".equals(columnText)){
//			co = "chest_type";
//			if("胸径".equals(val)){
//				v = "A";
//			}else if("头径".equals(val)){
//				v = "B";
//			}else if("米径".equals(val)){
//				v = "C";
//			}else if("地径".equals(val)){
//				v = "D";
//			}
//		}else if("胸/头/米/地径（CM）".equals(columnText)){
//			co = "chest";
//		}else if("高度（CM）".equals(columnText)){
//			co = "height";
//		}else if("冠幅（CM）".equals(columnText)){
//			co = "crown";
//		}else if("价格".equals(columnText)){
//			co = "unit_price";
//		}else if("质量等级".equals(columnText)){
//			co = "s_level";
//		}else if("数量".equals(columnText)){
//			co = "count";
//		}else if("二维码/编号".equals(columnText)){
//			co = "qr_code";
//		}
		dataMap.put(co,v);
	}
	
	/**
	 * 字段属性转换
	 * @param columnText
	 * @return
	 */
	private static void fieldConversionForOutStock(Map<String,Object> dataMap,String columnText,String val){
		String co = columnText;
//		int v = Integer.parseInt(val.toString().trim());
		String v = val;
		if("编号/二维码".equals(columnText)){
			co = "qr_code";
		}else if("出库数量".equals(columnText)){
			co = "count";
		}
		dataMap.put(co,v);
	}
	
	/**
	 * 去掉字符串右边的空格 
	 * @param str 要处理的字符串
	 * @return 处理后的字符串
	 */
	public static String rightTrim(String str) {
		if (str == null) {
			return "";
		}
		int length = str.length();
		for (int i = length - 1; i >= 0; i--) {
			if (str.charAt(i) != 0x20) {
				break;
			}
			length--;
		}
		return str.substring(0, length);
	}
	
    /**
     * 删除单个文件
     * @param   sPath    被删除文件的文件名
     * @return 单个文件删除成功返回true，否则返回false
     */
    public static boolean deleteFile(String sPath) {
        boolean flag = false;
        File file = new File(sPath+".xls");
        // 路径为文件且不为空则进行删除
        if (file.isFile() && file.exists()) {
            file.delete();
            flag = true;
        }
        return flag;
    }
    
    /**主办单位与用户（获取责任人）
     * @throws IOException 
     * @throws FileNotFoundException */
    public static void test1() throws FileNotFoundException, IOException{
    	File file = new File("E:/gov_oa项目相关文件/资料录入/最终导入数据20161227/20161226提供原数据/主要目标任务/2.2事项对应主办单位数据.xls");//提供数据
		List<Map<String,String>> data1 = ReadWriteExcel.getData(file, 1);
		file = new File("E:/gov_oa项目相关文件/资料录入/最终导入数据20161130/20161130提供数据/1.3用户数据（20161129）.xls");//用户数据
		List<Map<String,String>> data2 = ReadWriteExcel.getData(file, 1);
		for(Map<String,String> map1 : data1){
//			System.out.println(map1.get("责任人（对应用户序列）"));
			boolean flag = true;
			for(Map<String,String> map2 : data2){
				if(map2.get("用户序列（不能重复）").trim().equals(map1.get("责任人（对应用户序列）").trim())){
					System.out.println(map2.get("用户姓名").trim());
					flag = false;
				}
			}
			if(flag){
				System.out.println("11111111"+map1);
			}
		}
    }
    
    /**主办单位与事项（获取事项ID）*/
    private static void test2(){
    	
    }
    
    /**主办单位与部门（获取部门ID）
     * @throws IOException 
     * @throws FileNotFoundException */
    private static void test3() throws FileNotFoundException, IOException{
    	File file = new File("D:/项目/gov_oa/资料录入/最终导入数据20161228/部门工作要点（无协办单位）/2.2事项对应主办单位数据.xls");//提供数据
		List<Map<String,String>> data1 = ReadWriteExcel.getData(file, 1);
		int count = 0;
		for(Map<String,String> map1 : data1){
//			System.out.println(map1.get("所属部门（对应部门序列）"));
			String sxId =  map1.get("所属事项（对应事项序列）");
			System.out.println(sxId);
//			String sxId =  map1.get("所属部门（对应部门序列）");
			count++;
//			if(sxId.length() == 1){
//				System.out.println("1a2bcca8a8314f6cafa7031185ca000"+sxId);
//			}else if(sxId.length() == 2){
//				System.out.println("1a2bcca8a8314f6cafa7031185ca00"+sxId);
//			}else{
//				System.out.println("1a2bcca8a8314f6cafa7031185ca0"+sxId);
//			}
		}
		System.out.println("--->"+count);
    }
    
    /**事项与协办单位（获取事项ID）
     * @throws IOException 
     * @throws FileNotFoundException */
    private static void test4() throws FileNotFoundException, IOException{
    	File file = new File("D:/项目/gov_oa/资料录入/最终导入数据20161227/20161226提供原数据/主要目标任务/2.3事项对应协办单位数据.xls");//提供数据
		List<Map<String,String>> data1 = ReadWriteExcel.getData(file, 1);
//		file = new File("E:/gov_oa项目相关文件/资料录入/最终导入数据20161130/20161130提供数据/1.3用户数据（20161129）.xls");//用户数据
//		List<Map<String,String>> data2 = ReadWriteExcel.getData(file, 1);
		int count = 0;
		for(Map<String,String> map1 : data1){
//			System.out.println(map1.get("所属部门（对应部门序列）"));
			String[] ids =  map1.get("所属部门（对应部门序列）").split(",");
			String sxId =  map1.get("所属事项（对应事项序列）");
			for(String id : ids){
				System.out.println(sxId);
				count++;
				if(id.length() == 1){
//					System.out.println("1a2bcca8a8314f6cafa7031185ca000"+id);
				}else{
//					System.out.println("1a2bcca8a8314f6cafa7031185ca00"+id);
				}
			}
		}
		System.out.println("--->"+count);
    }
    
    /**协办单位与部门（获取部门ID）*/
    private static void test5(){
    	
    }
	
	public static void main(String[] args) throws FileNotFoundException, IOException {
		//主办单位与用户（获取责任人）
//		ReadWriteExcel.test1();
		
		//主办单位与事项（获取事项ID）
//		ReadWriteExcel.test2();
		
		//主办单位与部门（获取部门ID）
		ReadWriteExcel.test3();
		
		//协办单位与事项（获取事项ID）
//		ReadWriteExcel.test4();
		
		//协办单位与部门（获取部门ID）
//		ReadWriteExcel.test5();
		
	}
	
}