package com.qian.util;

import java.util.List;

/**
 * 集合工具类
 * @author Chonghui
 */
public class ListUtils {
	
	/**
	 * 判断非空集合或非空值集合
	 * @param obj
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	public static boolean isNotNull(List list) {
		if(list != null && list.size() > 0){
			return true;
		}else{
			return false;
		}
	}
	
	/**
	 * 判断空集合或空值集合
	 * @param obj
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	public static boolean isNull(List list) {
		if(list == null || (list != null && list.size() < 1)){
			return true;
		}else{
			return false;
		}
	}
	
	
}
