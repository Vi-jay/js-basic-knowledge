package com.qian.util;

import java.util.HashMap;

public class FormMap {
	
	private HashMap<String, Object> formMap = new HashMap<String, Object>();

	public HashMap<String, Object> getFormMap() {
		return formMap;
	}

	public void setFormMap(HashMap<String, Object> formMap) {
		this.formMap = formMap;
	}
	
}
