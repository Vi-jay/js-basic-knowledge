package com.qian.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;

/**
 * 时间工具类
 * 
 * @author Chonghui
 * 
 */
public class DateTimeUtils {

	/**
	 * 获取yyyyMMdd格式的当天日期
	 * 
	 * @return
	 */
	public static String getCurFormatDate() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd", Locale.CHINA);
		String curDate = sdf.format(new Date());
		return curDate;
	}

	/**
	 * 获取yyyy-MM-dd HH:mm:ss格式的当前时间
	 * 
	 * @return
	 */
	public static String getCurDate() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.CHINA);
		String curTime = sdf.format(new Date());
		return curTime;
	}

	/**
	 * 获取yyyy-MM-dd HH:mm:ss格式的当前时间
	 * 
	 * @return
	 */
	public static String getCurFormatDateTime() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",
				Locale.CHINA);
		String curTime = sdf.format(new Date());
		return curTime;
	}
	
	/**
	 * 获取指定格式时间
	 * @param date
	 * @param format
	 * @return
	 */
	public static String getDateForFormat(Date date,String format) {
		SimpleDateFormat sdf = new SimpleDateFormat(format,
				Locale.CHINA);
		String curTime = sdf.format(date);
		return curTime;
	}

	/**
	 * 获取yyyyMMddHHmmss格式的当前时间
	 * 
	 * @return
	 */
	public static String getCurDatetime() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss",
				Locale.CHINA);
		String curDate = sdf.format(new Date());
		return curDate;
	}

	/**
	 * 获取指定时间的次日时间
	 * 
	 * @param now
	 * @return
	 */
	public static Date getTomorrowDay(Date now) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(now);
		cal.add(Calendar.DATE, 1);
		return cal.getTime();
	}

	/**
	 * 将字符串转为yyyy-MM-dd HH:mm:ss格式时间
	 * 
	 * @param dateTime
	 * @return
	 */
	public static Date getDateByString(String dateTime) {
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		try {
			return df.parse(dateTime);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * 将时间字符串转成指定时间格式的时间
	 * 
	 * @param dateTime
	 * @param format
	 * @return
	 */
	public static Date getDateByString(String dateTime, String format) {
		SimpleDateFormat df = new SimpleDateFormat(format);
		try {
			return df.parse(dateTime);
		} catch (ParseException e) {
			return null;
		}
	}

	/**
	 * 将时间字符串转成指定时间格式的时间
	 * 
	 * @param dateTime
	 * @param format
	 * @return
	 * @throws ParseException 
	 */
	public static String getDateFormat(String dateTime, String format){
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = null;
		try {
			date = df.parse(dateTime);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		SimpleDateFormat sdf = new SimpleDateFormat(format,Locale.CHINA);
		String curDate = sdf.format(date);
		return curDate;
	}
	
	/**
	 * 获取指定时间当月的第一天
	 * 
	 * @param date
	 * @return
	 */
	public static Date getFirstDayOfMonth(Date date) {
		Calendar cDay1 = Calendar.getInstance();
		cDay1.setTime(date);
		cDay1.set(GregorianCalendar.DAY_OF_MONTH, 1);
		Date beginTime = cDay1.getTime();
		return beginTime;
	}

	/**
	 * 获取指定时间当月的最后一天
	 * 
	 * @param date
	 * @return
	 */
	public static Date getLastDayOfMonth(Date date) {
		Calendar cDay1 = Calendar.getInstance();
		cDay1.setTime(date);
		cDay1.set(Calendar.DAY_OF_MONTH, 1);
		cDay1.roll(Calendar.DAY_OF_MONTH, -1);
		Date endTime = cDay1.getTime();
		String eTime = new SimpleDateFormat("yyyy-MM-dd").format(endTime)
				+ " 23:59:59";
		try {
			return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(eTime);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * 获取指定时间前的日期
	 * 
	 * @param date
	 *            指定日期
	 * @param beforeDays
	 *            多少天 返回指定日期多少天前的日期
	 */
	public static Date getBeforDate(Date date, Integer beforeDays)
			throws Exception {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		int inputDayOfYear = cal.get(Calendar.DAY_OF_YEAR);
		cal.set(Calendar.DAY_OF_YEAR, inputDayOfYear - beforeDays);
		return cal.getTime();

	}

	/**
	 * 根据格式返回时间字符串
	 * 
	 * @param format
	 * @return
	 */
	public static String getNowDate(String format) {
		SimpleDateFormat formatter = new SimpleDateFormat(format);
		return formatter.format(new Date());
	}

	/**
	 * 获取某一月的最后一天
	 * @param year
	 * @param month
	 * @return
	 */
	public static String getLastDayOfMonth(int year, int month) {
		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.YEAR, year);
		cal.set(Calendar.MONTH, month);
		cal.set(Calendar.DAY_OF_MONTH, 1);
		cal.add(Calendar.DAY_OF_MONTH, -1);
		return new SimpleDateFormat("yyyy-MM-dd").format(cal.getTime());
	}

	
	/**
	 * 取得指定日期所在周的第一天
	 */
	public static Date getFirstDayOfWeek(Date date) {
		Calendar c = new GregorianCalendar();
		c.setFirstDayOfWeek(Calendar.MONDAY);
		c.setTime(date);
		c.set(Calendar.DAY_OF_WEEK, c.getFirstDayOfWeek()); // Monday
		return c.getTime();
	}

	/**
	 * 取得指定日期所在周的最后一天
	 */
	public static Date getLastDayOfWeek(Date date) {
		Calendar c = new GregorianCalendar();
		c.setFirstDayOfWeek(Calendar.MONDAY);
		c.setTime(date);
		c.set(Calendar.DAY_OF_WEEK, c.getFirstDayOfWeek() + 6); // Sunday
		return c.getTime();
	}
	
	public static void main(String[] args) {
//		String monday = DateTimeUtils.getDateForFormat(DateTimeUtils.getFirstDayOfWeek(new Date()),"yyyy-MM-dd");
//		String sunday = DateTimeUtils.getDateForFormat(DateTimeUtils.getLastDayOfWeek(new Date()),"yyyy-MM-dd");
//		
		Date currDate=DateTimeUtils.getFirstDayOfWeek(new Date());//本周一
		Date lastDate=DateTimeUtils.getLastDayOfWeek(new Date());//本周日
	    SimpleDateFormat df=new SimpleDateFormat("yyyy-MM-dd");
	    System.out.println("本周一："+df.format(currDate));
	    System.out.println("上周一：" + df.format(new Date(currDate.getTime() - 7 * 24 * 60 * 60 * 1000)));
	    System.out.println("上周日：" + df.format(new Date(lastDate.getTime() - 7 * 24 * 60 * 60 * 1000)));
	}
}
