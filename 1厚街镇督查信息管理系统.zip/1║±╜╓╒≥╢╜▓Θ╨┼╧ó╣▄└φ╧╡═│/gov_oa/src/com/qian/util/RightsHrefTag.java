package com.qian.util;

import java.util.List;
import java.util.Map;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.BodyTagSupport;

/**
 * @author zhanglb
 */
public class RightsHrefTag extends BodyTagSupport {
	/**
	 */
	private static final long serialVersionUID = 7112587565936794785L;

	/**
	 * 链接显示文字
	 */
	private String text;

	/**
	 * 链接路径
	 */
	private String href;

	/**
	 * alt 标题文字
	 */
	private String title;

	/**
	 * <a>链接样式
	 */
	private String cssClass;

	/**
	 * 权限代码
	 */
	private String rightCode;

	/**
	 * 单击事件
	 */
	private String onclick;

	/**
	 * 元素名称
	 */
	private String elementName;

	/**
	 * 目标
	 */
	private String target;

	/**
	 * 元素Id
	 */
	private String elementId;

	/**
	 * 链接内嵌元素
	 */
	private String html;
	
	/**
	 * 是否显示
	 */
	private String display;

	public String getRightCode() {
		return rightCode;
	}

	public void setRightCode(String rightCode) {
		this.rightCode = rightCode;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public String getHref() {
		return href;
	}

	public void setHref(String href) {
		this.href = href;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getCssClass() {
		return cssClass;
	}

	public void setCssClass(String cssClass) {
		this.cssClass = cssClass;
	}

	public String getOnclick() {
		return onclick;
	}

	public void setOnclick(String onclick) {
		this.onclick = onclick;
	}

	public String getElementName() {
		return elementName;
	}

	public void setElementName(String elementName) {
		this.elementName = elementName;
	}

	public String getElementId() {
		return elementId;
	}

	public void setElementId(String elementId) {
		this.elementId = elementId;
	}

	public String getTarget() {
		return target;
	}

	public void setTarget(String target) {
		this.target = target;
	}

	public String getHtml() {
		return html;
	}

	public void setHtml(String html) {
		this.html = html;
	}
	public String getDisplay() {
		return display;
	}
	public void setDisplay(String display) {
		this.display = display;
	}

	public int doAfterBody() throws JspException {
		try {
			return (SKIP_BODY);
		} catch (Exception ex) {

			throw new JspException(ex);
		}
	}

	@SuppressWarnings("unused")
	public int doEndTag() throws JspException {
		try {
			StringBuffer sbContent = new StringBuffer("");
			// 从session里面获取登录用户的分配操作功能权限列表
//			List<Map<String, Object>> menuOptList = SessionUtil.getLoginUserOpt(pageContext.getSession(),true);
			List<Map<String, Object>> menuOptList = null;
			if (menuOptList != null) {

				Map<String, Object> right = null; // 权限对象
				for (Map<String, Object> rightMap : menuOptList) {
					// 根据自定义标签配置的rightCode 与分配的操作权限是否一致
					if (rightMap.get("opt_code") != null && rightMap.get("opt_code").equals(rightCode.trim())) {
						right = rightMap;
						break;
					}
				}
				if (cssClass == null) {
					cssClass = "";
				}
				if (href == null || "".equals(href)) {
					href = "#";
				}
//				String loginUserName = SessionUtil.getLoginUserName((HttpServletRequest)pageContext.getRequest(),true);
				String loginUserName = null;
				// 找到权限或者是超级管理员
				if (right != null || "系统管理员".equals(loginUserName) || "管理员".equals(loginUserName)){
					sbContent.append("<a href=\"" + href + "\"   class=\"" + cssClass + "\"");

					if (elementId != null && !"".equals(elementId)) {
						sbContent.append(" id= \"" + elementId + "\" ");
					}
					if (elementName != null && !"".equals(elementName)) {
						sbContent.append(" name= \"" + elementName + "\" ");
					}
					if (title != null && !"".equals(title)) {
						sbContent.append(" title=\"" + title + "\" ");
					}
					if (target != null && !"".equals(target)) {
						sbContent.append(" target=\"" + target + "\" ");
					}
					if (display != null && !"".equals(display)) {
						sbContent.append(" style='display:none;' ");
					}
					if (right != null || "系统管理员".equals(loginUserName) || "管理员".equals(loginUserName)){
						if (onclick != null && !"".equals(onclick)) {
							sbContent.append(" onclick=\"" + onclick + "\"");
						}
					} else {
						sbContent.append(" onclick=\"alert('你无此操作权限，请联系管理员授权!');return;\" ");
					}
					sbContent.append(">");

//					/**
//					 * 优先使用内嵌内容
//					 */
					if(this.getBodyContent() != null){
						String content = this.getBodyContent().getString();
						if(null != content && !"".equals(content)){
							text = content;
						}
					}
					if(null != text && !"".equals(text.trim())) {
						sbContent.append(text.trim());
					}
						
					sbContent.append("</a>");
				}
			}
			JspWriter out = this.pageContext.getOut();
			out.print(sbContent.toString());
		}
		catch (Exception ex) {
			ex.printStackTrace();
			throw new JspException(ex);
		}
		return super.doEndTag();
	}
}
