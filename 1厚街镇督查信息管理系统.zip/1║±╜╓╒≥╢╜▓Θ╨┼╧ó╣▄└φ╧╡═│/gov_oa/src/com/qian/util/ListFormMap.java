package com.qian.util;

import java.util.ArrayList;
import java.util.List;

public class ListFormMap {

	private List<FormMap> listFormMap = new ArrayList<FormMap>();

	public List<FormMap> getListFormMap() {
		return listFormMap;
	}

	public void setListFormMap(List<FormMap> listFormMap) {
		this.listFormMap = listFormMap;
	}



}
