package com.qian.util;

import java.util.UUID;

public class UniqueIDGenerator {

	public UniqueIDGenerator() {
	}

	public static String getUUID() {
		return UUID.randomUUID().toString().replaceAll("-", "");
	}
	
	
}
