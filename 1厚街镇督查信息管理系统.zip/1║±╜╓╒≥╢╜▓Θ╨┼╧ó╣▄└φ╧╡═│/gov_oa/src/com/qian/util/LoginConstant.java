package com.qian.util;

/**
 * 登录信息常量类
 * @author Administrator
 */
public class LoginConstant {
	
	/**
	 * 用户
	 */
	public static final String USER="user";
	
	/**
	 * 用户菜单
	 */
	public static final String USER_MENU="user_menu";
}
