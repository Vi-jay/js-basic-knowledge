package com.qian.appinterface.common.action;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;
import com.qian.module.user.service.inter.MbSysDeptService;
import com.qian.module.worktask.service.inter.WtProjectTypeService;
import com.qian.util.FormMap;

/**
 * 描述：基础数据接口
 * @author twg
 */
@Controller
@Scope("prototype")
@RequestMapping(value = "/app/basedata")
public class BaseDataAction extends BaseAction{
	
	@Autowired
	private MbSysDeptService mbSysDeptService;
	@Autowired
	private WtProjectTypeService wtProjectTypeService;
	
	/**
	 * 部门数据接口
	 * @param formMap
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = "/dept", produces = { "application/json;charset=UTF-8" })
	public @ResponseBody JSONObject deptlist(FormMap formMap) {
		formMap.getFormMap().put("is_delete","N");
		List<Map<String,Object>> list = this.mbSysDeptService.findAll(formMap.getFormMap());
		return this.setResult("0","",list);
	}
	
	/**
	 * 事项分类数据接口
	 * @param formMap
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = "/projecttype", produces = { "application/json;charset=UTF-8" })
	public @ResponseBody JSONObject projecttype(FormMap formMap) {
		formMap.getFormMap().put("wpt_is_use","Y");
		List<Map<String,Object>> list = this.wtProjectTypeService.findAll(formMap.getFormMap());
		return this.setResult("0","",list);
	}
	
}	