package com.qian.appinterface.common.action;

import java.util.HashMap;
import java.util.Map;

import com.alibaba.fastjson.JSONObject;
import com.gzdec.framework.page.Pagination;
import com.qian.util.FormMap;
import com.qian.util.StringUtils;

public class BaseAction {
	
	public JSONObject jsonObj = new JSONObject();
	public Map<String,Object> paramMap = new HashMap<String,Object>();

	public JSONObject getJsonObj() {
		return jsonObj;
	}
	public void setJsonObj(JSONObject jsonObj) {
		this.jsonObj = jsonObj;
	}
	public Map<String, Object> getParamMap() {
		return paramMap;
	}
	public void setParamMap(Map<String, Object> paramMap) {
		this.paramMap = paramMap;
	}
	
	/**
	 * 设置返回值
	 * @param code
	 * @param msg
	 * @param data
	 * @return
	 */
	public JSONObject setResult(String code,String msg,Object data){
		jsonObj.put("code",code);
		jsonObj.put("msg",msg);
		jsonObj.put("data",data);
		return jsonObj;
	}

	/**
	 * 设置分页参数
	 * @param code
	 * @param msg
	 * @param data
	 * @return
	 */
	public Pagination setPageParam(FormMap formMap,Pagination p){
		Map<String,Object> pageMap = formMap.getFormMap();
		if(StringUtils.isNotNull(pageMap.get("curr_page"))){
			p.setCurrent(Long.parseLong(pageMap.get("curr_page").toString()));//当前页
		}
		if(StringUtils.isNotNull(pageMap.get("page_count"))){
			p.setPageCount(Long.parseLong(pageMap.get("page_count").toString()));
		}
		return p;
	}
	
}
