package com.qian.appinterface.appversion.action;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;
import com.qian.appinterface.common.action.BaseAction;
import com.qian.module.appversion.service.inter.AppVersionUpService;

/**
 * @author twg
 */
@Controller
@Scope("prototype")
@RequestMapping(value = "/app/software")
public class AppVersion extends BaseAction {
	@Resource
	private AppVersionUpService appVersionUpService;

	public static String appDownloadPath = null;

	static {
		Properties pro = new Properties();
		try {
			String path = AppVersion.class.getResource("/properties").getPath();
			File dic = new File(path + "/global.properties");
			pro.load(new FileInputStream(dic));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		appDownloadPath = pro.getProperty("attachment.path").trim();
	}

	/**
	 * 手机端下载操作提示页
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/down")
	public String  downloadAppPage(HttpServletResponse request,HttpServletResponse response) throws Exception  {
		return "forward:/appDownload.jsp";
	}
	
	/**
	 * 获取最新版本信息
	 * @return
	 */
	@RequestMapping(value = "/version", method = { RequestMethod.POST,RequestMethod.GET }, produces = { "application/json;charset=UTF-8" })
	public @ResponseBody JSONObject showVersion() {
		List<Map<String, Object>> findAll = appVersionUpService.findAll(new HashMap<String,Object>());
		if (findAll != null && findAll.size() > 0) {
			this.jsonObj.put("result", 1);
			this.jsonObj.put("data", findAll.get(0));
		} else {
			this.jsonObj.put("result", 0);
		}
		return this.jsonObj;
	}

	/**
	 * 开始下载app
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/download")
	public @ResponseBody
	JSONObject downloadApp(HttpServletResponse request, HttpServletResponse response) {
		Map<String, Object> map = new HashMap<String, Object>();
		List<Map<String, Object>> findAll = appVersionUpService.findAll(map);
		Map<String, Object> version = new HashMap<String, Object>();
		if (findAll != null && findAll.size() > 0) {
			version = findAll.get(0);
		} else {
			this.jsonObj.put("result", 0);
			return this.jsonObj;
		}
		request.setCharacterEncoding("UTF-8");
		BufferedInputStream bis = null;
		BufferedOutputStream bos = null;
		FileInputStream fis = null;
		String filePath = appDownloadPath + "/apk/" + version.get("location");
//		String filePath = "";
		// 获取文件的长度
		long fileLength = new File(filePath).length();
		response.reset();
		// 设置文件输出类型
		response.setContentType("application/octet-stream");
		response.setHeader("Content-disposition", "attachment; filename="
				+ version.get("location"));
		// 设置输出长度
		response.setHeader("Content-Length", String.valueOf(fileLength));
		try {
			// 获取输入流
			fis = new FileInputStream(filePath);
			bis = new BufferedInputStream(fis);
			// 输出流
			bos = new BufferedOutputStream(response.getOutputStream());
			byte[] buff = new byte[2048];
			int bytesRead;
			while (-1 != (bytesRead = bis.read(buff, 0, buff.length))) {
				bos.write(buff, 0, bytesRead);
				bos.flush();
			}
			// 关闭流
			bos.close();
			bis.close();
			fis.close();
			this.jsonObj.put("result", 1);
			return this.jsonObj;
		} catch (Exception ex) {
			this.jsonObj.put("result", 0);
			return this.jsonObj;
		}

	}
}
