package com.qian.appinterface.worktask.action;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;
import com.gzdec.framework.page.Pagination;
import com.qian.appinterface.common.action.BaseAction;
import com.qian.module.worktask.service.inter.WtDeptTaskService;
import com.qian.module.worktask.service.inter.WtWorktaskService;
import com.qian.util.FormMap;
import com.qian.util.StringUtils;

/**
 * 描述：统计报表接口
 * @author twg
 */
@Controller
@Scope("prototype")
@RequestMapping(value = "/app/sreport")
public class StatisticalReportAction extends BaseAction{
	
	@Autowired
	private WtWorktaskService wtWorktaskService;
	@Autowired
	private WtDeptTaskService wtDeptTaskService;
	
	/**
	 * 查询事项进度信息
	 * @param formMap
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = "/findall", produces = { "application/json;charset=UTF-8" })
	public @ResponseBody JSONObject findall(FormMap formMap,Pagination p) {
		if(StringUtils.isNull(formMap.getFormMap().get("user_id")) 
				|| StringUtils.isNull(formMap.getFormMap().get("curr_page"))
				|| StringUtils.isNull(formMap.getFormMap().get("page_count"))){
			return this.setResult("001", "参数不全", null);
		}
		formMap.getFormMap().put("is_delete","N");
		List<Map<String, Object>> list =  this.wtWorktaskService.findAllWorkTask(formMap.getFormMap(),this.setPageParam(formMap, p));
		return this.setResult("0", "", list);
	}
	
	/**
	 * 事项详情
	 * @param formMap
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = "/detail", produces = { "application/json;charset=UTF-8" })
	public @ResponseBody JSONObject detail(FormMap formMap) {
		if(StringUtils.isNull(formMap.getFormMap().get("user_id")) 
				|| StringUtils.isNull(formMap.getFormMap().get("worktask_id"))){
			return this.setResult("001", "参数不全", null);
		}
		Map<String,Object> worktask = this.wtWorktaskService.findById(formMap.getFormMap());
		List<Map<String,Object>> deptTaskList = this.wtDeptTaskService.findAll(formMap.getFormMap());
		worktask.put("depttask_list", deptTaskList);
		return this.setResult("0", "", worktask);
	}
	
	/**
	 * 事项进度报表
	 * @param formMap
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = "/pschedule", produces = { "application/json;charset=UTF-8" })
	public @ResponseBody JSONObject pschedule(FormMap formMap) {
		formMap.getFormMap().put("order_by","wdt.dept_id");
		return this.setResult("0", "", this.wtDeptTaskService.findAll(formMap.getFormMap()));
	}
	
	
	/**
	 * 部门任务报表
	 * @param formMap
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = "/dtreport", produces = { "application/json;charset=UTF-8" })
	public @ResponseBody JSONObject dtreport(FormMap formMap) {
		return this.setResult("0", "", this.wtDeptTaskService.findDeptTaskStatistics(formMap.getFormMap()));
	}
	
	/**
	 * 类型统计报表
	 * @param formMap
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = "/ptreport", produces = { "application/json;charset=UTF-8" })
	public @ResponseBody JSONObject ptreport(FormMap formMap) {
		return this.setResult("0", "", this.wtWorktaskService.findProjectStatistics(formMap.getFormMap()));
	}
	
}	