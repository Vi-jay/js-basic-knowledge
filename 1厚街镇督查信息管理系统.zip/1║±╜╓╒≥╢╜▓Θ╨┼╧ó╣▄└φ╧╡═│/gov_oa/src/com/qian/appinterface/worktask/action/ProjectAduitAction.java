package com.qian.appinterface.worktask.action;

import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;
import com.gzdec.framework.page.Pagination;
import com.qian.appinterface.common.action.BaseAction;
import com.qian.appinterface.worktask.util.ProjectAduitUtil;
import com.qian.module.worktask.service.inter.WtDeptTaskService;
import com.qian.module.worktask.service.inter.WtTaskArrangeService;
import com.qian.module.worktask.service.inter.WtTaskExecutionService;
import com.qian.module.worktask.service.inter.WtWorktaskService;
import com.qian.util.FormMap;
import com.qian.util.StringUtils;

/**
 * 描述：事项审核接口
 * @author twg
 */
@Controller
@Scope("prototype")
@RequestMapping(value = "/app/projectaduit")
public class ProjectAduitAction extends BaseAction{
	
	@Autowired
	private WtWorktaskService wtWorktaskService;
	@Autowired
	private WtDeptTaskService wtDeptTaskService;
	@Autowired
	private WtTaskArrangeService wtTaskArrangeService;
	@Autowired
	private WtTaskExecutionService wtTaskExecutionService;
	
	
	
	/**
	 * 待审核事项列表
	 * @param formMap
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = "/list", produces = { "application/json;charset=UTF-8" })
	public @ResponseBody JSONObject list(FormMap formMap,Pagination p) {
		if(StringUtils.isNull(formMap.getFormMap().get("user_id")) 
				|| StringUtils.isNull(formMap.getFormMap().get("curr_page"))
				|| StringUtils.isNull(formMap.getFormMap().get("page_count"))){
			return this.setResult("001", "参数不全", null);
		}
		if(StringUtils.isNull(formMap.getFormMap().get("approval_status"))){
			formMap.getFormMap().put("approval_status","O");
		}
		formMap.getFormMap().put("is_delete","N");
		formMap.getFormMap().put("dt_is_cancel","N");
		formMap.getFormMap().put("login_user_id",formMap.getFormMap().get("user_id"));
		List<Map<String, Object>> list =  this.wtWorktaskService.findDeptTask(formMap.getFormMap(),this.setPageParam(formMap, p));
		return this.setResult("0", "", ProjectAduitUtil.list(list));
	}
	
	
	/**
	 * 待审核事项详情
	 * @param formMap
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = "/view", produces = { "application/json;charset=UTF-8" })
	public @ResponseBody JSONObject view(FormMap formMap) {
		if(StringUtils.isNull(formMap.getFormMap().get("user_id")) 
				|| StringUtils.isNull(formMap.getFormMap().get("worktask_id"))
				|| StringUtils.isNull(formMap.getFormMap().get("dept_id"))){
			return this.setResult("001", "参数不全", null);
		}
		//部门任务
		List<Map<String, Object>> deptTaskList = this.wtDeptTaskService.findAll(formMap.getFormMap());
		//任务分配
		List<Map<String, Object>> arrangeList = this.wtTaskArrangeService.findAll(formMap.getFormMap());
		//任务执行明细
		formMap.getFormMap().put("approval_status","O");
		List<Map<String, Object>> executionList = this.wtTaskArrangeService.findAll(formMap.getFormMap());
		return this.setResult("0", "", ProjectAduitUtil.view(deptTaskList, arrangeList, executionList));
	}
	
	
	/**
	 * 查询部门任务进度
	 * @param formMap
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = "/deptschedule", produces = { "application/json;charset=UTF-8" })
	public @ResponseBody JSONObject deptschedule(FormMap formMap) {
		if(StringUtils.isNull(formMap.getFormMap().get("user_id")) 
				|| StringUtils.isNull(formMap.getFormMap().get("dt_dept_task_id"))){
			return this.setResult("001", "参数不全", null);
		}
		Map<String,Object> deptTask = this.wtDeptTaskService.findById(formMap.getFormMap());
		return this.setResult("0", "", ProjectAduitUtil.deptschedule(deptTask));
	}
	
	/**
	 * 提交审核结果
	 * @param formMap
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = "/create", produces = { "application/json;charset=UTF-8" })
	public @ResponseBody JSONObject create(FormMap formMap) {
		if(StringUtils.isNull(formMap.getFormMap().get("user_id")) 
				|| StringUtils.isNull(formMap.getFormMap().get("update_user"))
				|| StringUtils.isNull(formMap.getFormMap().get("task_execution_id"))
				|| StringUtils.isNull(formMap.getFormMap().get("approval_status"))){
			return this.setResult("001", "参数不全", null);
		}
		if("N".equals(formMap.getFormMap().get("approval_status").toString())
				&& StringUtils.isNull(formMap.getFormMap().get("opt_reason"))){
			return this.setResult("001", "参数不全", null);//不通过
		}
		try {
			formMap.getFormMap().put("update_time", new Date());
			this.wtTaskExecutionService.modify(formMap.getFormMap());
		} catch (Exception e) {
			return this.setResult("1", "系统异常", null);	
		}
		return this.setResult("0", "操作成功", null);
	}
	
	
	
}	