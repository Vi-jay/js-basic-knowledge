package com.qian.appinterface.worktask.action;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;
import com.gzdec.framework.page.Pagination;

import com.qian.appinterface.common.action.BaseAction;
import com.qian.module.user.service.inter.SysUserService;
import com.qian.module.worktask.service.inter.WtNewsRemindService;
import com.qian.module.worktask.util.NewsRemindUtil;
import com.qian.util.DataTypeConversion;
import com.qian.util.FormMap;
import com.qian.util.ListUtils;
import com.qian.util.SessionUtil;
import com.qian.util.StringUtils;

/**
 * 描述：我的事项消息接口
 * @author twg
 */
@Controller
@Scope("prototype")
@RequestMapping(value = "/app/projectmsg")
public class MyNewsRemindAction extends BaseAction{
	
	@Autowired
	private WtNewsRemindService wtNewsRemindService;
	@Autowired
	private SysUserService sysUserService;
	
	/**
	 * 我的任务列表
	 * @param formMap
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = "/list", produces = { "application/json;charset=UTF-8" })
	public @ResponseBody JSONObject login(FormMap formMap,Pagination p) {
		if(StringUtils.isNull(formMap.getFormMap().get("user_id")) 
				|| StringUtils.isNull(formMap.getFormMap().get("curr_page"))
				|| StringUtils.isNull(formMap.getFormMap().get("page_count"))){
			return this.setResult("001", "参数不全", null);
		}
		if(StringUtils.isNull(formMap.getFormMap().get("wnr_is_read"))){
			formMap.getFormMap().put("wnr_is_read","N");
		}
		//加载用户APP权限
		this.paramMap.put("user_id", formMap.getFormMap().get("user_id"));
		this.paramMap.put("user_type", "A");
		this.paramMap.put("menu_type","B");
		List<Map<String, Object>> userMenuList = sysUserService.findUserMenu(this.paramMap);
		List<Map<String, Object>> list =  this.wtNewsRemindService.findByPage(formMap.getFormMap(),this.setPageParam(formMap, p));
		if(ListUtils.isNull(list)){
			NewsRemindUtil.getDeptNewsRemind(wtNewsRemindService, list, userMenuList, formMap.getFormMap());
		}
		return this.setResult("0", "", list);
	}
	
	/**
	 * 判断是否存在未阅读信息
	 * @param formMap
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = "/isHasMsg", method = RequestMethod.POST, produces = { "application/json;charset=UTF-8" })
	public  @ResponseBody Map<String,Object> isHasMsg(HttpServletRequest request,FormMap formMap,Pagination p) throws IOException {
		Map<String,Object> paramMap = new HashMap<String,Object>();
		formMap.getFormMap().put("wnr_is_read","N");
		formMap.getFormMap().put("user_id",SessionUtil.getLoginUserId(request));
		List<Map<String, Object>> list =  this.wtNewsRemindService.findByPage(formMap.getFormMap(), p);
		if(list != null && list.size() > 0){
			paramMap.put("result","Y");//未重复
		}else{
			paramMap.put("result","N");//未重复
		}
		return paramMap;
	}
	
	/**
	 * To enter edit
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/entryEdit")
	public String entryEdit(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map){
//		map.put("data",this.wtNewsRemindService.findById(formMap.getFormMap()));
		this.paramMap.put("task_execution_id", formMap.getFormMap().get("task_execution_id"));
		this.paramMap.put("wnr_type_level","Y");
		List<Map<String,Object>> list = this.wtNewsRemindService.findAll(this.paramMap);
		map.put("list", list);
		map.put("formMap", formMap.getFormMap());
		return "worktask/wt_news_remind_edit";
	}
	
	/**
	 * To enter view
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/entryView")
	public String entryView(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map){
		map.put("data",this.wtNewsRemindService.findById(formMap.getFormMap()));
		return "worktask/wt_news_remind_view";
	}

	/**
	 * 设置消息已阅（单条数据）
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/modifyReadStatus")
	public String modifyReadStatus(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map) throws Exception{
		formMap.getFormMap().put("wnr_is_read","Y");
		this.wtNewsRemindService.modify(formMap.getFormMap());
		return "redirect:/pc/worktask/entryView?formMap[opt_mark]=mytask&formMap[worktask_id]="+formMap.getFormMap().get("worktask_id")+"&formMap[dept_id]="+formMap.getFormMap().get("dept_id")+"&formMap[task_arrange_id]="+formMap.getFormMap().get("task_arrange_id");
	}
	
	/**
	 * 批量设置已阅
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/setread", produces = { "application/json;charset=UTF-8" })
	public @ResponseBody JSONObject setread(FormMap formMap) {
		if(StringUtils.isNull(formMap.getFormMap().get("user_id")) 
				|| StringUtils.isNull(formMap.getFormMap().get("ids"))){
			return this.setResult("001", "参数不全", null);
		}
		try {
			formMap.getFormMap().put("ids",DataTypeConversion.getIdsToArray(formMap.getFormMap().get("ids")));
			this.wtNewsRemindService.updateReadStatusToBatch(formMap.getFormMap());
		} catch (Exception e) {
			return this.setResult("1", "系统异常", null);	
		}
		return this.setResult("0", "设置成功", null);
	}
	
	/**
	 * 批量删除已阅消息
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/remove", produces = { "application/json;charset=UTF-8" })
	public @ResponseBody JSONObject remove(FormMap formMap) {
		if(StringUtils.isNull(formMap.getFormMap().get("user_id")) 
				|| StringUtils.isNull(formMap.getFormMap().get("ids"))){
			return this.setResult("001", "参数不全", null);
		}
		try {
			formMap.getFormMap().put("ids",DataTypeConversion.getIdsToArray(formMap.getFormMap().get("ids")));
			this.wtNewsRemindService.remove(formMap.getFormMap());
		} catch (Exception e) {
			return this.setResult("1", "系统异常", null);	
		}
		return this.setResult("0", "设置成功", null);
	}
	
}	