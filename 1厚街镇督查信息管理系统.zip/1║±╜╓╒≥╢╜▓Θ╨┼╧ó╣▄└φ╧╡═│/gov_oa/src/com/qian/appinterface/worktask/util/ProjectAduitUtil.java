package com.qian.appinterface.worktask.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.qian.util.ListUtils;

public class ProjectAduitUtil{
	
	public static List<Map<String, Object>> list(List<Map<String,Object>> list){
		List<Map<String, Object>> resultList = new ArrayList<Map<String, Object>>();
		if(ListUtils.isNotNull(list)){
			Map<String, Object> tempMap = null;
			for(Map<String, Object> map : list){
				tempMap = new HashMap<String,Object>();
				tempMap.put("worktask_id",map.get("worktask_id"));
				tempMap.put("task_arrange_id",map.get("task_arrange_id"));
				tempMap.put("dept_id",map.get("dept_id"));
				tempMap.put("task_num",map.get("task_num"));
				tempMap.put("importance",map.get("importance"));
				tempMap.put("arr_task_status",map.get("arr_task_status"));
				tempMap.put("wpt_type_name",map.get("wpt_alias"));
				tempMap.put("title",map.get("title"));
				tempMap.put("schedule",map.get("schedule"));
				tempMap.put("create_time",map.get("create_time"));
				resultList.add(tempMap);
			}
		}
		return resultList;
	}
	
	public static Map<String,Object> view(List<Map<String, Object>> deptTaskList,List<Map<String, Object>> arrangeList,List<Map<String, Object>> executionList){
		Map<String,Object> resultMap = new HashMap<String,Object>();
		if(ListUtils.isNotNull(deptTaskList) && ListUtils.isNotNull(arrangeList) && ListUtils.isNotNull(executionList)){
			//部门信息
			resultMap.put("dt_dept_task_id",deptTaskList.get(0).get("dt_dept_task_id"));
			resultMap.put("dt_task_explain",deptTaskList.get(0).get("dt_task_explain"));
			resultMap.put("dt_change_stime",deptTaskList.get(0).get("dt_change_stime"));
			resultMap.put("dt_change_etime",deptTaskList.get(0).get("dt_change_etime"));
			resultMap.put("dt_schedule",deptTaskList.get(0).get("dt_schedule"));
			//任务分配信息
			List<Map<String, Object>> arrangeTempList = new ArrayList<Map<String, Object>>();
			Map<String, Object> arrangeTempMap = null;
			//任务执行信息
			List<Map<String, Object>> executionTempList = new ArrayList<Map<String, Object>>();
			Map<String, Object> executionTempMap = null;
			boolean flag = false;
			for(Map<String,Object> arrangeMap : arrangeList){//循环任务分配，即每个执行者
				arrangeTempMap = new HashMap<String,Object>();
				arrangeTempMap.put("task_arrange_id", arrangeMap.get("task_arrange_id"));
				arrangeTempMap.put("real_name", arrangeMap.get("real_name"));
				arrangeTempMap.put("arrange_explain", arrangeMap.get("arrange_explain"));
				arrangeTempMap.put("arr_start_time", arrangeMap.get("arr_start_time"));
				arrangeTempMap.put("arr_end_time", arrangeMap.get("arr_end_time"));
				arrangeTempMap.put("schedule", arrangeMap.get("schedule"));
				flag = false;
				executionTempList = new ArrayList<Map<String, Object>>();
				for(Map<String,Object> executionMap : executionList){//循环任务执行明细，即每个执行者所对应的多个执行步骤
					if(arrangeMap.get("task_arrange_id").toString().equals(executionMap.get("task_arrange_id").toString())){
						executionTempMap = new HashMap<String,Object>();
						executionTempMap.put("task_execution_id", executionMap.get("task_execution_id"));
						executionTempMap.put("execution_time", executionMap.get("execution_time"));
						executionTempMap.put("execution_content", executionMap.get("execution_content"));
						executionTempMap.put("assist_explain", executionMap.get("assist_explain"));
						executionTempMap.put("next_plan", executionMap.get("next_plan"));
						executionTempMap.put("schedule", executionMap.get("schedule"));
						executionTempMap.put("schedule_description", executionMap.get("schedule_description"));
						executionTempMap.put("approval_status", executionMap.get("approval_status"));
						executionTempMap.put("attachment_name", executionMap.get("attachment_name"));
						executionTempMap.put("attachment", executionMap.get("attachment"));
						executionTempList.add(executionTempMap);
						flag = true;
					}
				}
				arrangeTempMap.put("execution_list", executionTempList);
				if(flag){arrangeTempList.add(arrangeTempMap);}
			}
			resultMap.put("arrange_list", arrangeTempList);//将任务分配集合添加到部门任务信息中
		}
		return resultMap;
	}
	
	public static Map<String,Object> deptschedule(Map<String, Object> deptTask){
		Map<String,Object> resultMap = new HashMap<String,Object>();
		if(deptTask != null && deptTask.size() > 0){
			resultMap.put("dt_dept_task_id", deptTask.get("dt_dept_task_id"));
			resultMap.put("dt_schedule_describe", deptTask.get("dt_schedule_describe"));
			resultMap.put("dt_next_plan", deptTask.get("dt_next_plan"));
			resultMap.put("dt_problem_explain", deptTask.get("dt_problem_explain"));
			resultMap.put("dt_schedule_evaluate", deptTask.get("dt_schedule_evaluate"));
			resultMap.put("dt_schedule_attname", deptTask.get("dt_schedule_attname"));
			resultMap.put("dt_schedule_atturl", deptTask.get("dt_schedule_atturl"));
		}
		return resultMap;
	}
	
}	
