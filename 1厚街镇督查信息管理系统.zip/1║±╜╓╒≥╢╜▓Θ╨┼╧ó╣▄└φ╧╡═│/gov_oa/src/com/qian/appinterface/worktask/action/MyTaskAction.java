package com.qian.appinterface.worktask.action;

import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;
import com.gzdec.framework.page.Pagination;
import com.qian.appinterface.common.action.BaseAction;
import com.qian.appinterface.worktask.util.MyTaskUtil;
import com.qian.module.worktask.dao.WtTaskExecutionDao;
import com.qian.module.worktask.service.inter.WtDeptTaskService;
import com.qian.module.worktask.service.inter.WtTaskArrangeService;
import com.qian.module.worktask.service.inter.WtTaskExecutionService;
import com.qian.util.FormMap;
import com.qian.util.StringUtils;

/**
 * 描述：我的任务管理接口
 * @author twg
 */
@Controller
@Scope("prototype")
@RequestMapping(value = "/app/mytask")
public class MyTaskAction extends BaseAction{
	
	@Autowired
	private WtDeptTaskService wtDeptTaskService;
	@Autowired
	private WtTaskArrangeService wtTaskArrangeService;
	@Autowired
	private WtTaskExecutionService wtTaskExecutionService;
	@Autowired
	private WtTaskExecutionDao wtTaskExecutionDao;
	
	/**
	 * 我的任务列表
	 * @param formMap
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = "/list", produces = { "application/json;charset=UTF-8" })
	public @ResponseBody JSONObject list(FormMap formMap,Pagination p) {
		if(StringUtils.isNull(formMap.getFormMap().get("user_id")) 
				|| StringUtils.isNull(formMap.getFormMap().get("curr_page"))
				|| StringUtils.isNull(formMap.getFormMap().get("page_count"))){
			return this.setResult("001", "参数不全", null);
		}
		if(StringUtils.isNull(formMap.getFormMap().get("task_status"))){
			formMap.getFormMap().put("my_task_status","Y");
		}
		List<Map<String, Object>> list =  this.wtTaskArrangeService.findMyWorkTask(formMap.getFormMap(),this.setPageParam(formMap, p));
		return this.setResult("0", "", MyTaskUtil.list(list));
	}
	
	
	/**
	 * 查看事项以及任务详情
	 * @param formMap
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = "/view", produces = { "application/json;charset=UTF-8" })
	public @ResponseBody JSONObject view(FormMap formMap) {
		if(StringUtils.isNull(formMap.getFormMap().get("user_id")) 
				|| StringUtils.isNull(formMap.getFormMap().get("worktask_id"))
				|| StringUtils.isNull(formMap.getFormMap().get("task_arrange_id"))
				|| StringUtils.isNull(formMap.getFormMap().get("dept_id"))
				|| StringUtils.isNull(formMap.getFormMap().get("is_view_history"))){
			return this.setResult("001", "参数不全", null);
		}
		String isViewHistory = formMap.getFormMap().get("is_view_history").toString();
		Map<String,Object> taskDetail = null;
		if(!"B".equals(isViewHistory)){//加载任务信息
			this.paramMap.put("worktask_id",formMap.getFormMap().get("worktask_id"));
			this.paramMap.put("dept_id",formMap.getFormMap().get("dept_id"));
			List<Map<String,Object>> deptTask = this.wtDeptTaskService.findAll(this.paramMap);
			this.paramMap.clear();
			this.paramMap.put("task_arrange_id",formMap.getFormMap().get("task_arrange_id"));
			Map<String,Object> arrTask = this.wtTaskArrangeService.findById(this.paramMap);
			taskDetail = MyTaskUtil.view(deptTask, arrTask);
		}
		if(!"A".equals(isViewHistory)){//加载执行过程信息
			List<Map<String,Object>> executionList = this.wtTaskExecutionService.findAll(formMap.getFormMap());
			if("B".equals(isViewHistory)){
				taskDetail = new HashMap<String,Object>();
			}
			taskDetail.put("execution_list", executionList);
		}
		return this.setResult("0", "", taskDetail);
	}
	
	
	/**
	 * 更新任务进度
	 * @param formMap
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = "/create", produces = { "application/json;charset=UTF-8" })
	public @ResponseBody JSONObject create(FormMap formMap) {
		if(StringUtils.isNull(formMap.getFormMap().get("user_id")) 
				|| StringUtils.isNull(formMap.getFormMap().get("worktask_id"))
				|| StringUtils.isNull(formMap.getFormMap().get("task_arrange_id"))
				|| StringUtils.isNull(formMap.getFormMap().get("dept_id"))
				|| StringUtils.isNull(formMap.getFormMap().get("login_user_name"))
				|| StringUtils.isNull(formMap.getFormMap().get("execution_content"))
				|| StringUtils.isNull(formMap.getFormMap().get("schedule_description"))
				|| StringUtils.isNull(formMap.getFormMap().get("schedule"))
				|| StringUtils.isNull(formMap.getFormMap().get("next_plan"))){
			return this.setResult("001", "参数不全", null);
		}
		try {
			formMap.getFormMap().put("execution_time",new Date());
			this.wtTaskExecutionService.create(formMap.getFormMap());
			
			this.wtTaskExecutionDao.updateAllSchedule(formMap.getFormMap());
		} catch (Exception e) {
			return this.setResult("1", "系统异常", null);	
		}
		return this.setResult("0", "更新成功", null);
	}
	
	

	/**
	 * 修改任务进度
	 * @param formMap
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = "/update", produces = { "application/json;charset=UTF-8" })
	public @ResponseBody JSONObject update(FormMap formMap) {
		if(StringUtils.isNull(formMap.getFormMap().get("user_id")) 
				|| StringUtils.isNull(formMap.getFormMap().get("task_execution_id"))
				|| StringUtils.isNull(formMap.getFormMap().get("execution_content"))
				|| StringUtils.isNull(formMap.getFormMap().get("schedule_description"))
				|| StringUtils.isNull(formMap.getFormMap().get("next_plan"))){
			return this.setResult("001", "参数不全", null);
		}
		try {
			this.wtTaskExecutionService.modify(formMap.getFormMap());
		} catch (Exception e) {
			return this.setResult("1", "系统异常", null);	
		}
		return this.setResult("0", "修改成功", null);
	}
	
	/**
	 * 变更任务状态（标记或暂停）
	 * @param formMap
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = "/setmytask", produces = { "application/json;charset=UTF-8" })
	public @ResponseBody JSONObject setmytask(FormMap formMap) {
		if(StringUtils.isNull(formMap.getFormMap().get("user_id")) || 
				StringUtils.isNull(formMap.getFormMap().get("task_arrange_id")) ||
				(StringUtils.isNull(formMap.getFormMap().get("task_status")) && StringUtils.isNull(formMap.getFormMap().get("is_sign")))
			){
			return this.setResult("001", "参数不全", null);
		}
		try {
			this.wtTaskArrangeService.modify(formMap.getFormMap());
		} catch (Exception e) {
			return this.setResult("1", "系统异常", null);	
		}
		return this.setResult("0", "操作成功", null);
	}
	
}	