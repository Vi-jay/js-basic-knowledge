package com.qian.appinterface.worktask.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.qian.util.ListUtils;

public class MyTaskUtil {
	
	public static List<Map<String, Object>> list(List<Map<String,Object>> list){
		List<Map<String, Object>> resultList = new ArrayList<Map<String, Object>>();
		if(ListUtils.isNotNull(list)){
			Map<String, Object> tempMap = null;
			for(Map<String, Object> map : list){
				tempMap = new HashMap<String,Object>();
				tempMap.put("worktask_id",map.get("worktask_id"));
				tempMap.put("task_arrange_id",map.get("task_arrange_id"));
				tempMap.put("dept_id",map.get("dept_id"));
				tempMap.put("task_num",map.get("task_num"));
				tempMap.put("importance",map.get("importance"));
				tempMap.put("arr_task_status",map.get("arr_task_status"));
				tempMap.put("wpt_type_name",map.get("wpt_alias"));
				tempMap.put("title",map.get("title"));
				tempMap.put("schedule",map.get("schedule"));
				tempMap.put("create_time",map.get("create_time"));
				tempMap.put("arr_is_sign",map.get("arr_is_sign"));
				resultList.add(tempMap);
			}
		}
		return resultList;
	}
	
	public static Map<String,Object> view(List<Map<String,Object>> deptTask,Map<String,Object> arrTask){
		Map<String,Object> map = new HashMap<String,Object>();
		if(ListUtils.isNotNull(deptTask)){
			Map<String,Object> tMap = deptTask.get(0);
			map.put("dt_task_explain", tMap.get("dt_task_explain"));
			map.put("dt_change_stime", tMap.get("dt_change_stime"));
			map.put("dt_change_etime", tMap.get("dt_change_etime"));
			map.put("dt_schedule", tMap.get("dt_schedule"));
			map.put("dt_schedule_attname", tMap.get("dt_schedule_attname"));
			map.put("dt_schedule_atturl", tMap.get("dt_schedule_atturl"));
		}
		if(arrTask != null){
			map.put("real_name", arrTask.get("real_name"));
			map.put("arrange_explain", arrTask.get("arrange_explain"));
			map.put("task_status", arrTask.get("task_status"));
			map.put("create_time", arrTask.get("create_time"));
			map.put("arr_start_time", arrTask.get("arr_start_time"));
			map.put("arr_end_time", arrTask.get("arr_end_time"));
			map.put("schedule", arrTask.get("schedule"));
			map.put("attr_name", arrTask.get("attr_name"));
			map.put("attr_url", arrTask.get("attr_url"));
		}
		return map;
	}

}
