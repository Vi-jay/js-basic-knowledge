package com.qian.appinterface.uploadfile.action;

import javax.servlet.http.HttpServletRequest;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.alibaba.fastjson.JSONObject;
import com.qian.appinterface.common.action.BaseAction;
import com.qian.util.FormMap;
import com.qian.util.UploadFile;
import com.gzdec.framework.util.UniqueIDGenerator;

/**
 * 描述：APP上传文件工具类
 * @author twg
 */
@Controller
@Scope("prototype")
@RequestMapping(value = "/app/uploadfile")
public class UploadFileAction extends BaseAction{

	@RequestMapping(value = "/start")
	public  @ResponseBody JSONObject start(HttpServletRequest request,FormMap formMap){
		String uuid = UniqueIDGenerator.getUUID();//主键ID值
		formMap.getFormMap().put("id",uuid);
		UploadFile.uploadAttachment(request, formMap);
		//返回值
		this.jsonObj.put("result","1");
		this.jsonObj.put("key_id",uuid);//返回主键
		this.jsonObj.put("attachment_name",formMap.getFormMap().get("attachment_name"));
		this.jsonObj.put("new_file_name",formMap.getFormMap().get("new_file_name"));
		this.jsonObj.put("attachment",formMap.getFormMap().get("attachment"));
//		if(StringUtils.isNotNull(formMap.getFormMap().get("user_id"))){
//		}else{
//			this.jsonObj.put("result","1000");
//		}
		return this.jsonObj;
	}
	
	
	
}	