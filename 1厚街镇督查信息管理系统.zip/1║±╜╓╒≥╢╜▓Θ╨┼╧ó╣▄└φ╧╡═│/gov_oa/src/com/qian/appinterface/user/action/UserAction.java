package com.qian.appinterface.user.action;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;
import com.qian.appinterface.common.action.BaseAction;
import com.qian.module.user.service.inter.MbSysDeptService;
import com.qian.module.user.service.inter.MbSysUserDeptService;
import com.qian.module.user.service.inter.SysUserService;
import com.qian.util.DataTypeConversion;
import com.qian.util.FormMap;
import com.qian.util.ListUtils;
import com.qian.util.MD5Utils;
import com.qian.util.StringUtils;
import com.gzdec.framework.page.Pagination;

/**
 * 描述：用户管理接口
 * @author 谭文广
 */
@Controller
@Scope("prototype")
@RequestMapping(value = "/app/user")
public class UserAction extends BaseAction{
	
	@Autowired
	private SysUserService sysUserService;
	@Autowired
	private MbSysDeptService mbSysDeptService;
	@Autowired
	private MbSysUserDeptService mbSysUserDeptService;
	
	/**
	 * 用户登录
	 * @param formMap
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = "/login", produces = { "application/json;charset=UTF-8" })
	public @ResponseBody JSONObject login(FormMap formMap) {
		if(StringUtils.isNull(formMap.getFormMap().get("account")) || StringUtils.isNull(formMap.getFormMap().get("password"))){
			return this.setResult("001", "参数不全", null);
		}
		//帐号为：真实姓名或者私人手机号码双验证登录
		formMap.getFormMap().put("is_frozen","N");
		formMap.getFormMap().put("is_delete","N");
		formMap.getFormMap().put("password", MD5Utils.getMD5Code(formMap.getFormMap().get("password").toString()));//二次加密
		List<Map<String, Object>> user = sysUserService.findAll(formMap.getFormMap());//判断帐号密码是否正确
		if(ListUtils.isNotNull(user)){
			//加载用户APP权限
			this.paramMap.put("user_id", user.get(0).get("user_id"));
			this.paramMap.put("user_type", user.get(0).get("user_type"));
			this.paramMap.put("menu_type","B");
			List<Map<String, Object>> userMenuList = sysUserService.findUserMenu(this.paramMap);
			if(ListUtils.isNotNull(userMenuList)){
				StringBuffer b = new StringBuffer();
				for(Map<String, Object> userMenuMap : userMenuList){
					b.append(userMenuMap.get("menu_code")+",");
				}
				user.get(0).put("function",b.toString());
			}
			return this.setResult("0","登录成功",user.get(0));
		}else{
			return this.setResult("002", "帐号或者密码有误", null);
		}
	}
	
	/**
	 * 统计次数
	 * @param formMap
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = "/statisticalnumber", produces = { "application/json;charset=UTF-8" })
	public  @ResponseBody JSONObject statisticalnumber(FormMap formMap) {
		if(StringUtils.isNotNull(formMap.getFormMap().get("user_id"))){
			formMap.getFormMap().put("current_opt_user",formMap.getFormMap().get("user_id"));
			formMap.getFormMap().put("apply_status","A");
			formMap.getFormMap().remove("user_id");
			
			this.jsonObj.put("result","1");
		}else{
			this.jsonObj.put("result","1000");
		}
		return this.jsonObj;
	}
	
	
	/**
	 * 修改用户个人信息
	 * @param formMap
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value = "/modify", produces = { "application/json;charset=UTF-8" })
	public  @ResponseBody JSONObject modify(FormMap formMap) {
		if(StringUtils.isNotNull(formMap.getFormMap().get("user_id")) && StringUtils.isNotNull(formMap.getFormMap().get("real_name"))
				&& StringUtils.isNotNull(formMap.getFormMap().get("sex"))){
			DataTypeConversion.urlDecoderForMap(formMap.getFormMap(),"UTF-8");
			int count =0;
			try {
				formMap.getFormMap().put("mobile_phone","");
				count = this.sysUserService.modify(formMap.getFormMap());
			} catch (Exception e) {
				e.printStackTrace();
			}
			if(count > 0){
				this.jsonObj.put("result","1");
			}else{
				this.jsonObj.put("result","0");
			}
		}else{
			this.jsonObj.put("result","1000");
		}
		return this.jsonObj;
	}
	
	/**
	 * 绑定推送用户
	 * @param formMap
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value = "/bindpushuser", produces = { "application/json;charset=UTF-8" })
	public  @ResponseBody JSONObject bindpushuser(FormMap formMap) {
		if(StringUtils.isNotNull(formMap.getFormMap().get("user_id")) 
				&& StringUtils.isNotNull(formMap.getFormMap().get("channel_id"))){
			int count =0;
			try {
				formMap.getFormMap().put("is_frozen","N");
				formMap.getFormMap().put("is_delete","N");
				this.sysUserService.removeUserByChannelId(formMap.getFormMap());
				count = this.sysUserService.modify(formMap.getFormMap());
			} catch (Exception e) {
				e.printStackTrace();
			}
			if(count > 0){
				this.jsonObj.put("result","1");
			}else{
				this.jsonObj.put("result","0");
			}
		}else{
			this.jsonObj.put("result","1000");
		}
		return this.jsonObj;
	}
	
	/**
	 * 
	 * @param request
	 * @param response
	 * @param map
	 * @param formMap
	 * @param p
	 * @return
	 */
	@RequestMapping(value = "/userforchoose")
	public @ResponseBody JSONObject userforchoose(HttpServletRequest request,HttpServletResponse response,ModelMap map,FormMap formMap,Pagination p){
//		List<String> ids = new ArrayList<String>();
//		List<String> names = new ArrayList<String>();
		StringBuffer ids = new StringBuffer();
		StringBuffer names = new StringBuffer();
		formMap.getFormMap().put("user_type","A");
		formMap.getFormMap().put("is_frozen","N");
		formMap.getFormMap().put("is_delete","N");
		//查找所有部门
		List<Map<String, Object>> deptList = this.mbSysDeptService.findAll(formMap.getFormMap());
		//查找所有部门下的用户
		if(deptList != null && deptList.size() > 0){
			List<Map<String, Object>> userDeptList =  this.mbSysUserDeptService.findAll(formMap.getFormMap());
			List<Map<String, Object>> userList = null;
			Map<String, Object> userMap = null;
			for(Map<String, Object> deptMap : deptList){
				userList = new ArrayList<Map<String, Object>>();
				for(Map<String, Object> userDeptMap : userDeptList){
					if(deptMap.get("dept_id").toString().equals(userDeptMap.get("dept_id").toString())){
						userMap = new HashMap<String,Object>();
						userMap.put("user_id",userDeptMap.get("user_id"));
						userMap.put("real_name",userDeptMap.get("real_name"));
						userList.add(userMap);
						ids.append(userDeptMap.get("user_id").toString()+",");
						names.append(deptMap.get("dept_name")+"-"+userDeptMap.get("real_name")+",");
					}
				}
				deptMap.put("user_list", userList);
			}
		}
		this.jsonObj.put("user_ids",ids.toString().substring(0, ids.toString().length()-1));
		this.jsonObj.put("user_names",names.toString().substring(0, names.toString().length()-1));
//		this.jsonObj.put("dept_user_list",deptList);
		return this.jsonObj;
	}
	
}	