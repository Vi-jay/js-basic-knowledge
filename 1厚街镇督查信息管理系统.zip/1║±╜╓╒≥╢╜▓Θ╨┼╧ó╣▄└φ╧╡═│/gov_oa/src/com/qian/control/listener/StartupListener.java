package com.qian.control.listener;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;


/**
 * 
 * @author Chonghui
 */
public class StartupListener implements ServletContextListener{
	
	
	private static Properties config;
	static{
	   Properties pro = new Properties();
	   try{
		   String path = StartupListener.class.getResource("/properties").getPath();
		   File dic = new File(path + "/global.properties");
		   pro.load(new FileInputStream(dic));
	   } catch (FileNotFoundException e) {
		   e.printStackTrace();
	   } catch (IOException e) {
		   e.printStackTrace();
	   }
	   config = pro;
   }

	public void contextDestroyed(ServletContextEvent event) {
	}

	public void contextInitialized(ServletContextEvent event) {
		ServletContext applicationContext = event.getServletContext();
//		ApplicationContext context = WebApplicationContextUtils.getWebApplicationContext(applicationContext);
		applicationContext.setAttribute("attachment_url",config.getProperty("attachment.website").trim());
	}
	
}
