package com.qian.control.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
/**
 * 自动登陆过滤器
 * @author fengyingwei
 *
 */
public class AutoLoginFilter implements Filter{
	
	@Override
	public void init(FilterConfig arg0) throws ServletException {
		
	}
	
	@Override
	public void doFilter(ServletRequest request, ServletResponse response,FilterChain chain) throws IOException, ServletException {
		HttpServletRequest req =(HttpServletRequest) request;
		HttpServletResponse resp =(HttpServletResponse) response;
		
		String requestURL = req.getRequestURL().toString();
		//如果是系统请求则放行
		if(requestURL.contains("/pc/system")||requestURL.contains("/pc/common")
				||requestURL.contains("/pc/judge")
				||requestURL.contains("/pc/proapply/entryView")
				||requestURL.contains("/pc/worktask/otherReport")){
			chain.doFilter(req, resp);
			return;
		}
		
//		Cookie[] cookies = req.getCookies();
		HttpSession session = req.getSession();
		//判断session中是否存在用户数据
		if(session!=null){
			Object user = session.getAttribute("user");
			if(user!=null){
				chain.doFilter(req, resp);
				return ;
			}else{
				session.setAttribute("session_mark","nosession");
			}
		}
		//判断cookie中是否存在用户数据
//		if(cookies!=null){
//			boolean flag=false;
//			for (Cookie cookie : cookies) {
//				if("autoLogin".equals(cookie.getName())){
//					flag=true;
//					String[] value = cookie.getValue().split("&&");
//					try {
//						if(value.length==2){
//							session.setAttribute("account", URLDecoder.decode(value[0], "utf-8"));
//							session.setAttribute("password", value[1]);
//							req.getRequestDispatcher("/pc/system/login")
//							.forward(req, resp);
//							return;
//						}else {
//							cookie.setMaxAge(0);
//						    cookie.setPath("/");// 不要漏掉
//						    resp.addCookie(cookie);
//						}
//					} catch (Exception e) {
//						e.printStackTrace();
//					}
//				}
//			}
//			//如果没有autoLogin 的cookie则跳到登陆页
//			if(!flag){
//				resp.sendRedirect(req.getContextPath()+"/pc/system/entryLogin");
//				return;
//			}
//		}else{
//			resp.sendRedirect(req.getContextPath()+"/pc/system/entryLogin");
//			return;
//		}
		resp.sendRedirect(req.getContextPath()+"/pc/system/entryLogin");
		return;
	}

	@Override
	public void destroy() {
	}
}
