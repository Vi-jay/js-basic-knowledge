package com.qian.module.system.action;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import com.qian.module.user.service.inter.SysUserService;
import com.qian.util.FormMap;
import com.qian.util.MD5Utils;

/**
 * 注册功能
 * @author twg
 */
@Controller
@Scope("prototype")
@RequestMapping(value = "/pc/system")
public class RegisterAction {
	
	@Resource
	private SysUserService sysUserServiceImpl;
	
	/**
	 * 进入注册页
	 * @return
	 */
	@RequestMapping(value = "/entryRegister")
	public String entryRegister(){
		
		return "system/register";
	}
	
	/**
	 * 用户注册
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value = "/register")
	public String register(ModelMap map, FormMap formMap) throws Exception{
		if(!formMap.getFormMap().isEmpty()){
//			String mainFieldId = UniqueIDGenerator.getUUID();
			String password = formMap.getFormMap().get("password").toString();
			formMap.getFormMap().put("user_type", "A");
			formMap.getFormMap().put("password", MD5Utils.getMD5Code(password));
			int result = sysUserServiceImpl.create(formMap.getFormMap());
			if(result == 1)
			{
				FormMap main_filed = new FormMap();
				main_filed.getFormMap().put("company", formMap.getFormMap().get("company"));
			}
		}
		return "system/register";
	}
	
	/**
	 * 验证帐号是否重复
	 * @param account
	 * @return
	 */
	@RequestMapping(value = "/v_account", method = RequestMethod.POST, produces = { "application/json;charset=UTF-8" })
	public @ResponseBody Map<String, Object> validateAccount(String account){
		Map<String, Object> valueMap = new HashMap<String, Object>();
		Map<String, Object> result = new HashMap<String, Object>();
		valueMap.put("account", account);
		Map<String,Object> a = sysUserServiceImpl.find(valueMap);
		if( a != null){
			result.put("result", "fail");
		}
		else{
			result.put("result", "success");
		}
		return result;
	}
}
