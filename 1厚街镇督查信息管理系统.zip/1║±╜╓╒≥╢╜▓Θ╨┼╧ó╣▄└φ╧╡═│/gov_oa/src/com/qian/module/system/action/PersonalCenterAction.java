package com.qian.module.system.action;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.qian.module.common.action.BaseAction;
import com.qian.module.user.service.inter.SysUserService;
import com.qian.util.FormMap;
import com.qian.util.LoginConstant;
import com.qian.util.MD5Utils;

/**
 * 描述：个人中心
 * @author 谭文广
 */
@Controller
@Scope("prototype")
@RequestMapping(value = "/pc/personalcenter")
public class PersonalCenterAction extends BaseAction{
	
	@Autowired
	private SysUserService sysUserService;
//	@Autowired
//	private SysMainFieldService sysMainFieldService;
	
	/**
	 * 进入个人中心页
	 * @author 谭文广
	 * @param formMap
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/entry")
	public String entry(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map){
		Object user = request.getSession().getAttribute(LoginConstant.USER);
		if(user != null){
			Map<String,Object> userMap = (Map<String, Object>) user;
			String user_id = userMap.get("user_id").toString();
			String user_type = userMap.get("user_type").toString();
			if(!"C".equals(user_type)){
				formMap.getFormMap().put("user_id",user_id);
				Map<String, Object> roleMap = this.sysUserService.findById(formMap.getFormMap());
				map.put("data",roleMap);
				map.put("tip_type",formMap.getFormMap().get("type"));
				return "system/personal_center";
			}
		}
		return "redirect:/pc/frame/main";
	}
	
	/**
	 * 修改个人基础信息
	 * @author 谭文广
	 * @param formMap
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value = "/modifyBaseInfo")
	public String modifyBaseInfo(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map) throws Exception{
		this.sysUserService.modify(formMap.getFormMap());
		return "redirect:/pc/personalcenter/entry?formMap[type]=modifyBaseInfo&formMap[user_id]="+formMap.getFormMap().get("user_id");
	}
	
	/**
	 * 修改个人密码
	 * @author 谭文广
	 * @param formMap
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value = "/modifyPassword")
	public String modifyPassword(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map) throws Exception{
		this.setPassword(formMap);
		this.sysUserService.modify(formMap.getFormMap());
		return "redirect:/pc/personalcenter/entry?formMap[type]=modifyPassword&formMap[user_id]="+formMap.getFormMap().get("user_id");
	}
	
	/**
	 * 设置密码
	 * @author 谭文广
	 * @param formMap
	 * @return
	 */
	public boolean setPassword(FormMap formMap){
		if(formMap.getFormMap().get("password") != null){
			formMap.getFormMap().put("password",MD5Utils.getMD5Code(formMap.getFormMap().get("password").toString()));//第一次加密
			formMap.getFormMap().put("password",MD5Utils.getMD5Code(formMap.getFormMap().get("password").toString()));//第二次加密
			return true;
		}
		return false;
	}

}	