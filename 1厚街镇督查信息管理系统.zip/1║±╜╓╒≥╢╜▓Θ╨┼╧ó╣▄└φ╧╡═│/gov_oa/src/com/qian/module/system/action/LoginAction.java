package com.qian.module.system.action;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import net.sf.json.JSONObject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.qian.module.appversion.service.inter.AppVersionUpService;
import com.qian.module.common.action.BaseAction;
import com.qian.module.user.service.inter.SysUserService;
import com.qian.util.LoginConstant;
import com.qian.util.MD5Utils;
import com.qian.util.SessionUtil;
import com.qian.util.StringUtils;

/**
 * 登录功能
 * @author twg
 */
@Controller
@Scope("prototype")
@RequestMapping(value = "/pc/system")
public class LoginAction extends BaseAction{
	
	@Autowired
	private SysUserService sysUserService;
	@Resource
	private AppVersionUpService appVersionUpService;
	
	/**
	 * 进入登录页
	 * @return
	 */
	@RequestMapping(value = "/entryLogin")
	public String entryLogin(HttpServletRequest request,ModelMap map){
		List<Map<String, Object>> findAll = this.appVersionUpService.findAll(new HashMap<String,Object>());
		map.put("appinfo", findAll.get(0));
		return "system/login";
	}
	
	/**
	 * 进入登录页（手机网页端）
	 * @return
	 */
	@RequestMapping(value = "/mlogin")
	public String mlogin(HttpServletRequest request,ModelMap map){
		request.getSession().setAttribute("platformType","mobile");
		try {
			String code = request.getParameter("code");
			String accessToken = WeiXinUtilAction.getAccessToken();
			JSONObject qyUserInfo = WeiXinUtilAction.getUserInfo(code);
			request.getSession().setAttribute("access_token",accessToken);
			request.getSession().setAttribute("code",code);
			if(StringUtils.isNotNull(accessToken) && StringUtils.isNotNull(code) && StringUtils.isNotNull(qyUserInfo.get("UserId"))){
				this.paramMap.put("user_type","A");
				this.paramMap.put("is_frozen","N");
				this.paramMap.put("is_delete","N");
				this.paramMap.put("mobile_phone", qyUserInfo.getString("UserId").trim());
				if(this.paramMap.get("mobile_phone").toString().length() == 11){
					Map<String, Object> user = sysUserService.find(this.paramMap);//判断帐号密码是否正确
					if(user != null && user.get("user_id") != null){
						return "redirect:/pc/system/login?account="+user.get("mobile_phone")+"&password="+user.get("password")+"&platformType=mobile";
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "system/mobile/login";
	}
	
	/**
	 * 登录验证
	 * @return
	 */
	@RequestMapping(value = "/login")
	public String login(String account,String password,String platformType,HttpServletRequest request,ModelMap map){
		HttpSession session = request.getSession();
		session.setAttribute("platformType",platformType);
		session.setAttribute("session_account",account);
		if(StringUtils.isNotNull(account) && StringUtils.isNotNull(password)){
			this.paramMap.put("account", account);//帐号为：真实姓名或者私人手机号码双验证登录
			if(password.trim().length() == 32){//微信端自动登录功能
				this.paramMap.put("password", password);
			}else{//普通登录
				this.paramMap.put("password", MD5Utils.getMD5Code(MD5Utils.getMD5Code(password.toString())));
			}
			Map<String, Object> user = sysUserService.find(this.paramMap);//判断帐号密码是否正确
			if(user != null && user.get("user_id") != null){
				session.setAttribute(LoginConstant.USER, user);//把用户信息放到session中
				if("B".equals(user.get("user_type"))){//系统超级管理员————直接放行
					//将用户菜单放入session中
					Map<String,Object> valueMap = new HashMap<String,Object>();
					valueMap.put("user_id", SessionUtil.getLoginUserId(request));
					valueMap.put("user_type", user.get("user_type"));
					if(StringUtils.isNotNull(platformType) && "mobile".equals(platformType)){
						valueMap.put("menu_type","B");//手机端权限
					}else{
						valueMap.put("menu_type","A");
					}
					session.setAttribute(LoginConstant.USER_MENU, sysUserService.findUserMenu(valueMap));
//					return "redirect:/pc/frame/index";//系统超级管理员登录成功
					return this.platformType(request, "redirect:/pc/frame/index", "redirect:/pc/frame/mobileIndex");
				}else{//普通用户
					//判断账户是否删除
					if("Y".equals(user.get("is_delete").toString())){
						map.put("wrong_info","登录失败，用户已删除");
//						return "system/login";
						return this.platformType(request, "system/login", "system/mobile/login");
					}
					//判断账户是否冻结
					if("Y".equals(user.get("is_frozen").toString())){
						map.put("wrong_info","登录失败，用户已冻结");
//						return "system/login";
						return this.platformType(request, "system/login", "system/mobile/login");
					}
					//将用户菜单放入session中
					Map<String,Object> valueMap = new HashMap<String,Object>();
					valueMap.put("user_id", SessionUtil.getLoginUserId(request));
					valueMap.put("user_type", user.get("user_type"));
					if(StringUtils.isNotNull(platformType) && "mobile".equals(platformType)){
						valueMap.put("menu_type","B");//手机端权限
					}else{
						valueMap.put("menu_type","A");
					}
					session.setAttribute(LoginConstant.USER_MENU, sysUserService.findUserMenu(valueMap));
//					return "redirect:/pc/frame/index";//普通用户登录成功
					return this.platformType(request, "redirect:/pc/frame/index", "redirect:/pc/frame/mobileIndex");
				}
			}else{
				map.put("wrong_info","帐号或密码有误");
//				return "system/login";
				return this.platformType(request, "system/login", "system/mobile/login");
			}
		}else{//信息填写不全
			map.put("wrong_info","帐号密码不能为空");
//			return "system/login";
			return this.platformType(request, "system/login", "system/mobile/login");
		}
	}
	
}
