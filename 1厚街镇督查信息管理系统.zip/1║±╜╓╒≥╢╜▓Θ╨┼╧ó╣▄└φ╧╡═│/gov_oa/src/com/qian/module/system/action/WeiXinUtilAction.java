package com.qian.module.system.action;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.util.List;
import java.util.Map;

import javax.net.ssl.HttpsURLConnection;

import org.springframework.stereotype.Service;

import com.qian.util.HttpRequest;
import com.qian.util.ListUtils;
import com.qian.util.StringUtils;

import net.sf.json.JSONObject;

/**
 * 微信定时器
 * @author Administrator
 */
@Service
public class WeiXinUtilAction{

//	private static String corpid = "wx1fb893be23aadfd6";
//	private static String corpsecret = "wXd8ZEP0MTWTX9qAIBV-sWRUmwY_GvdgXKCftHPUfg8VJ4plPyeDYmZuSffAhVZo";
	private static String corpid = "wx446e412e9c82d67d";
	private static String corpsecret = "Hn82T3-swYJDQd8N91W_V5S2tMawRH35jJF0JBrG8A_ZXoAMafHqOzfofJfQMBYp";
	private static String getTokenUrl = "https://qyapi.weixin.qq.com/cgi-bin/gettoken";
	private static String getuserinfo = "https://qyapi.weixin.qq.com/cgi-bin/user/getuserinfo";
	// 创建会话请求URL
	private static String createSessionUrl = "https://qyapi.weixin.qq.com/cgi-bin/message/send?access_token=";
	
	private static String access_token_val = "";
	
	/**
	 * 获取access_token
	 * @return
	 */
	public static String getAccessToken(){
		if(StringUtils.isNull(access_token_val)){
			WeiXinUtilAction.refreshAccessToken();
		}
		return access_token_val;
	}
	
	/**
	 * 定时刷新access_token
	 * @return
	 */
	public static void refreshAccessToken(){
		String param = "corpid="+corpid+"&corpsecret="+corpsecret;
		String result = HttpRequest.sendGet(getTokenUrl, param);
		JSONObject accessToken = JSONObject.fromObject(result);
		access_token_val = accessToken.getString("access_token");
	}
	
	/**
	 * 通过access_token以及code获取用户信息
	 * @param code
	 * @return
	 */
	public static JSONObject getUserInfo(String code){
		if(StringUtils.isNotNull(code)){
			String param = "access_token="+access_token_val+"&code="+code;
			String result = HttpRequest.sendGet(getuserinfo, param);
			return JSONObject.fromObject(result);
		}else{
			return new JSONObject();
		}
	}
	
	/**
	 * 
	 * @param param
	 */
	private static void sendMsg(String param) {
		URL uRl;
		// 拼接请求串
		String action = createSessionUrl + WeiXinUtilAction.getAccessToken();
		try {
			uRl = new URL(action);
			HttpsURLConnection http = (HttpsURLConnection) uRl.openConnection();
			http.setRequestMethod("POST");
			http.setRequestProperty("Content-Type","application/json;charset=UTF-8");
			http.setDoOutput(true);
			http.setDoInput(true);
			System.setProperty("sun.net.client.defaultConnectTimeout", "30000");//
			// 连接超时30秒
			System.setProperty("sun.net.client.defaultReadTimeout", "30000"); //
			// 读取超时30秒
			http.connect();
			OutputStream os = http.getOutputStream();
			os.write(param.getBytes("UTF-8"));// 传入参数
			InputStream is = http.getInputStream();
			int size = is.available();
			byte[] jsonBytes = new byte[size];
			is.read(jsonBytes);
			String result = new String(jsonBytes, "UTF-8");
			System.out.println("请求返回结果:" + result);
			os.flush();
			os.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	/**
	 * 
	 * @param userList
	 * @param sendUsers
	 * @param agentid
	 * @param content
	 */
	public static void sendMsg(List<Map<String,Object>> userList,String sendUsers,int agentid,String content) {
		String users = "";
		if(ListUtils.isNotNull(userList)){
			StringBuffer sb = new StringBuffer();
			for(Map<String,Object> user : userList){
				sb.append(user.get("mobile_phone"));
				sb.append("|");
			}
			users = sb.toString().substring(0, sb.toString().length()-1);
		}else{
			users = sendUsers;
		}
		JSONObject msg = new JSONObject();
		JSONObject text = new JSONObject();
		text.put("content", content);
		msg.put("touser",users);
		msg.put("toparty", "");
		msg.put("totag", "");
		msg.put("msgtype", "text");
		msg.put("agentid", agentid);
		msg.put("text", text);
		msg.put("safe", "0");
		if(StringUtils.isNotNull(users) && StringUtils.isNotNull(content)){
			WeiXinUtilAction.sendMsg(msg.toString());
		}
	}
	
	public static void main(String[] args) throws Exception {
		
	}

}
