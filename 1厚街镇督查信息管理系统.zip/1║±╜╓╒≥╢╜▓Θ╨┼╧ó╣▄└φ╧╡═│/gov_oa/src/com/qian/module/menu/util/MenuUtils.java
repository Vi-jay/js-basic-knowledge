package com.qian.module.menu.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class MenuUtils {
	
	
	/**
	 * 获取树形结构节点
	 * @param resultList
	 * @param treeList
	 * @param menu_id
	 */
	private static void getNode(List<Map<String,Object>> resultList,List<Map<String,Object>> treeList,String menu_id){
		for(Map<String,Object> map : resultList){
    		if(map.get("parent_id") != null && menu_id.equals(map.get("parent_id").toString())){
    			treeList.add(map);//添加子节点菜单
    			MenuUtils.getNode(resultList, treeList, map.get("menu_id").toString());
    		}
    	}
	}
	
	
	public static List<Map<String,Object>> getMenuToTree(List<Map<String,Object>> resultList){
		List<Map<String,Object>> treeList = new ArrayList<Map<String,Object>>();//对菜单进行树形排序
		for(Map<String,Object> map : resultList){
			if("1".equals(map.get("menu_level").toString())){
				treeList.add(map);//添加第一级菜单
				MenuUtils.getNode(resultList, treeList,map.get("menu_id").toString());
			}
		}
		return treeList;
	}
	
}
