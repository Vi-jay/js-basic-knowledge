package com.qian.module.menu.action;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.gzdec.framework.page.Pagination;

import com.qian.module.menu.service.inter.SysMenuService;
import com.qian.module.menu.service.inter.SysMenuoptService;
import com.qian.module.menu.util.MenuUtils;
import com.qian.util.FormMap;
import com.qian.util.StringUtils;

/**
 * 描述：菜单管理
 * @author 谭文广
 */
@Controller
@Scope("prototype")
@RequestMapping(value = "/pc/menu")
public class SysMenuAction{
	
	@Autowired
	private SysMenuService sysMenuService;
	@Autowired
	private SysMenuoptService sysMenuoptService;
	
	/**
	 * To enter list
	 * @author 谭文广
	 * @param formMap
	 * @param pagination
	 * @return
	 */
	@RequestMapping(value = "/listByPage")
	public String listByPage(HttpServletRequest request,HttpServletResponse response,ModelMap map,FormMap formMap,Pagination p){
		p.setPageCount(500);
		List<Map<String, Object>> list = this.sysMenuService.findByPage(formMap.getFormMap(), p);
		if(StringUtils.isNotNull(formMap.getFormMap().get("parent_id"))){
			map.put("list",list);
		}else{
			map.put("list",MenuUtils.getMenuToTree(list));
		}
		map.put("formMap",formMap.getFormMap());
		map.put("pagination",p);
		this.getFirstMenu(map);
		return "menu/sys_menu_list";
	}
	
	/**
	 * To enter edit
	 * @author 谭文广
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/entryEdit")
	public String entryEdit(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map){
		map.put("data",this.sysMenuService.findById(formMap.getFormMap()));
		this.getFirstMenu(map);
		return "menu/sys_menu_edit";
	}
	
	/**
	 * Creating
	 * @author 谭文广
	 * @param formMap
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value = "/create")
	public String create(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map) throws Exception{
		this.setMenuLevel(formMap);
		this.judgeMenuType(formMap);
		this.sysMenuService.create(formMap.getFormMap());
		this.defaulViewOpt(formMap,"create");
		return "redirect:/pc/menu/listByPage";
	}
	
	/**
	 * Modifing
	 * @author 谭文广
	 * @param formMap
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value = "/modify")
	public String modify(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map) throws Exception{
		this.setMenuLevel(formMap);
		this.judgeMenuType(formMap);
		this.sysMenuService.modify(formMap.getFormMap());
		this.defaulViewOpt(formMap,"modify");
		return "redirect:/pc/menu/listByPage";
	}
	
	/**
	 * 判断菜单类型
	 * @param formMap
	 */
	private void judgeMenuType(FormMap formMap){
		Map<String,Object> paramMap = new HashMap<String,Object>();
		paramMap.put("menu_id",formMap.getFormMap().get("parent_id"));
		Map<String,Object> map = this.sysMenuService.findById(paramMap);
		if("-1".equals(formMap.getFormMap().get("parent_id")) || 
				(map != null && "B".equals(map.get("menu_type").toString())) ){
			formMap.getFormMap().put("menu_type","B");
		}
	}

	/**
	 * 添加默认查看列表菜单操作
	 * @param formMap
	 * @throws Exception 
	 */
	private void defaulViewOpt(FormMap formMap,String optType) throws Exception{
		Map<String,Object> paramMap = new HashMap<String,Object>();
		if(formMap.getFormMap().get("menu_id") != null){
			paramMap.put("menu_id",formMap.getFormMap().get("menu_id"));
			if("create".equals(optType)){
				paramMap.put("opt_name","查看列表【默认】");
				paramMap.put("opt_code",formMap.getFormMap().get("menu_code")+"_LIST_VIEW");
				paramMap.put("opt_url","");
				paramMap.put("is_menu_opt","Y");
				this.sysMenuoptService.create(paramMap);
			}else{
				paramMap.put("is_menu_opt","Y");
				List<Map<String,Object>> list = this.sysMenuoptService.findAll(paramMap);
				if(list != null && list.size() > 0){
					paramMap.put("menuopt_id",list.get(0).get("menuopt_id"));
					paramMap.put("opt_code",formMap.getFormMap().get("menu_code")+"_LIST_VIEW");
					this.sysMenuoptService.modify(paramMap);
				}
			}
		}
	}
	
	/**
	 * 设置菜单等级
	 * @param formMap
	 */
	private void setMenuLevel(FormMap formMap){
		String parent_id = formMap.getFormMap().get("parent_id").toString();
		if("0".equals(parent_id) || "-1".equals(parent_id)){
			formMap.getFormMap().put("menu_level",1);
		}else{
			formMap.getFormMap().put("menu_level",2);
		}
	}
	
	/**
	 * 查询并设置所有一级菜单
	 * @param formMap
	 */
	private void getFirstMenu(ModelMap map){
		Map<String,Object> paramMap = new HashMap<String,Object>();
		paramMap.put("menu_level",1);
		map.put("menu_list",this.sysMenuService.findAll(paramMap));
	}
	
	/**
	 * Deleting
	 * @author 谭文广
	 * @param formMap
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value = "/delete")
	public String delete(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map) throws Exception{
		this.sysMenuService.remove(formMap.getFormMap());
		return "redirect:/pc/menu/listByPage";
	}
	

	/**
	 * To enter view
	 * @author 谭文广
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/entryView")
	public String entryView(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map){
		map.put("data",this.sysMenuService.findById(formMap.getFormMap()));
		return "menu/sys_menu_view";
	}

	
	/**
	 * 验证菜单编码是否存在
	 * @param formMap
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = "/verificationMenuCode", method = RequestMethod.POST, produces = { "application/json;charset=UTF-8" })
	public  @ResponseBody Map<String,Object> verificationMenuCode(FormMap formMap) throws IOException {
		Map<String,Object> paramMap = new HashMap<String,Object>();
		paramMap.put("menu_code",formMap.getFormMap().get("menu_code"));
		List<Map<String, Object>> list = this.sysMenuService.findAll(paramMap);
		if(list != null && list.size() > 0){
			if(formMap.getFormMap().get("menu_id") != null){
				String menu_id_f = formMap.getFormMap().get("menu_id").toString();
				String menu_id_r = list.get(0).get("menu_id").toString();
				if(menu_id_f.equals(menu_id_r)){
					paramMap.put("result","N");//未重复
				}else{
					paramMap.put("result","Y");//重复
				}
			}else{
				paramMap.put("result","Y");//重复
			}
		}else{
			paramMap.put("result","N");//未重复
		}
		return paramMap;
	}
	
}	