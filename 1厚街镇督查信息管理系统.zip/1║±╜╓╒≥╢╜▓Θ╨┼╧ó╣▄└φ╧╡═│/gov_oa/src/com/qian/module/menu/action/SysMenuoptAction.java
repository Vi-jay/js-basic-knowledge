package com.qian.module.menu.action;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.gzdec.framework.page.Pagination;

import com.qian.module.menu.service.inter.SysMenuService;
import com.qian.module.menu.service.inter.SysMenuoptService;
import com.qian.module.menu.util.MenuUtils;
import com.qian.util.FormMap;
import com.qian.util.StringUtils;

/**
 * 描述：菜单操作管理
 * @author 谭文广
 */
@Controller
@Scope("prototype")
@RequestMapping(value = "/pc/menuopt")
public class SysMenuoptAction{
	
	@Autowired
	private SysMenuService sysMenuService;
	@Autowired
	private SysMenuoptService sysMenuoptService;
	
	/**
	 * To enter list
	 * @author 谭文广
	 * @param formMap
	 * @param pagination
	 * @return
	 */
	@RequestMapping(value = "/listByPage")
	public String listByPage(HttpServletRequest request,HttpServletResponse response,ModelMap map,FormMap formMap,Pagination p){
//		formMap.getFormMap().put("is_menu_opt","N");
		p.setPageCount(1000);
		List<Map<String, Object>> list =  this.sysMenuoptService.findByPage(formMap.getFormMap(), p);
		if(StringUtils.isNotNull(formMap.getFormMap().get("menu_name"))){
			map.put("list",list);
		}else{
			map.put("list",MenuUtils.getMenuToTree(list));
		}
		map.put("formMap",formMap.getFormMap());
		map.put("pagination",p);
		return "menu/sys_menuopt_list";
	}
	
	/**
	 * 查询并设置所有菜单
	 * @param formMap
	 */
	private void getMenu(ModelMap map){
		Map<String,Object> paramMap = new HashMap<String,Object>();
		List<Map<String, Object>> list =  this.sysMenuService.findAll(paramMap);
		map.put("menu_list",MenuUtils.getMenuToTree(list));
	}
	
	/**
	 * To enter edit
	 * @author 谭文广
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/entryEdit")
	public String entryEdit(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map){
		map.put("data",this.sysMenuoptService.findById(formMap.getFormMap()));
		this.getMenu(map);
		return "menu/sys_menuopt_edit";
	}
	
	/**
	 * Creating
	 * @author 谭文广
	 * @param formMap
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value = "/create")
	public String create(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map) throws Exception{
		this.sysMenuoptService.create(formMap.getFormMap());
		return "redirect:/pc/menuopt/listByPage";
	}
	
	/**
	 * Modifing
	 * @author 谭文广
	 * @param formMap
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value = "/modify")
	public String modify(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map) throws Exception{
		this.sysMenuoptService.modify(formMap.getFormMap());
		return "redirect:/pc/menuopt/listByPage";
	}
	
	/**
	 * Deleting
	 * @author 谭文广
	 * @param formMap
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value = "/delete")
	public String delete(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map) throws Exception{
		this.sysMenuoptService.remove(formMap.getFormMap());
		return "redirect:/pc/menuopt/listByPage";
	}
	

	/**
	 * To enter view
	 * @author 谭文广
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/entryView")
	public String entryView(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map){
		map.put("data",this.sysMenuoptService.findById(formMap.getFormMap()));
		return "menu/sys_menuopt_view";
	}

	
	/**
	 * 验证菜单操作编码是否存在
	 * @param formMap
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = "/verificationOptCode", method = RequestMethod.POST, produces = { "application/json;charset=UTF-8" })
	public  @ResponseBody Map<String,Object> verificationOptCode(FormMap formMap) throws IOException {
		Map<String,Object> paramMap = new HashMap<String,Object>();
		paramMap.put("opt_code",formMap.getFormMap().get("opt_code"));
		List<Map<String, Object>> list = this.sysMenuoptService.findAll(paramMap);
		if(list != null && list.size() > 0){
			if(formMap.getFormMap().get("menuopt_id") != null){
				String menuopt_id_f = formMap.getFormMap().get("menuopt_id").toString();
				String menuopt_id_r = list.get(0).get("menuopt_id").toString();
				if(menuopt_id_f.equals(menuopt_id_r)){
					paramMap.put("result","N");//未重复
				}else{
					paramMap.put("result","Y");//重复
				}
			}else{
				paramMap.put("result","Y");//重复
			}
		}else{
			paramMap.put("result","N");//未重复
		}
		return paramMap;
	}
	
}	