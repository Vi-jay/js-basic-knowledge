package com.qian.module.menu.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Service;
import com.gzdec.framework.dao.SqlMapBaseDao;
import com.gzdec.framework.page.Pagination;

/**
 * @author 谭文广
 */
@Service
public class SysMenuDao extends SqlMapBaseDao{
	/**
	 * Query List
	 * @author 谭文广
	 * @param valueMap
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<Map<String,Object>> findAll(Map<String,Object> to){
		return this.queryForList("menu.sysMenu.query", to);
	}
	
	/**
	 * Query Page List
	 * @author 谭文广
	 * @param valueMap
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<Map<String,Object>> findByPage(Map<String,Object> to,Pagination pagination){
		return this.queryForList("menu.sysMenu.query", to, pagination);
	}
	
	/**
	 * Get A Record
	 * @author 谭文广
	 * @param to
	 * @return
	 */
	@SuppressWarnings("unchecked")	 
	public Map<String,Object> find(Map<String,Object> to){
		return (Map<String,Object>)this.queryForObject("menu.sysMenu.query", to);
	}
	
	/**
	 * Creating
	 * @author 谭文广
	 * @param to
	 * @return
	 * @throws Exception 
	 */
	public int create(Map<String,Object> to) throws Exception{
		this.insert("menu.sysMenu.create", to);
		return 1;
	}
	
	/**
	 * Modify
	 * @author 谭文广
	 * @param to
	 * @return
	 * @throws Exception 
	 */
	public int modify(Map<String,Object> to) throws Exception{
		return this.update("menu.sysMenu.modify", to);
	}
	
	/**
	 * Deleting
	 * @author 谭文广
	 * @param to
	 * @return
	 * @throws Exception 
	 */
	public int remove(Map<String,Object> to) throws Exception{
		List<Map<String,Object>> list = new ArrayList<Map<String,Object>>();
		list.add(to);
		return this.remove(list);
	}
	
	/**
	 * Deleting List
	 * @author 谭文广
	 * @param list
	 * @return
	 */
	public int remove(List<Map<String,Object>> list){
		int count = 0;
		if(null == list || list.size() <= 0){
		    return count;
		}
		for(int i = 0; i < list.size(); i++){
		    Map<String,Object> to = list.get(i);
		    count += this.delete("menu.sysMenu.remove", to);
		    this.delete("menu.sysMenu.removeMenuoptBymenuId", to);//同时删除相关联的菜单操作
		}
		return count;
	}






}