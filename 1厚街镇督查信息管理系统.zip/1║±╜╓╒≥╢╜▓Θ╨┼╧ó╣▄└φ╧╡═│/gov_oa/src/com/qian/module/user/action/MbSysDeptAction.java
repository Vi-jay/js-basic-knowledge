package com.qian.module.user.action;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import com.gzdec.framework.page.Pagination;

import com.qian.module.user.service.inter.MbSysDeptService;
import com.qian.util.FormMap;

/**
 * 描述：部门管理
 * @author 谭文广
 */
@Controller
@Scope("prototype")
@RequestMapping(value = "/pc/dept")
public class MbSysDeptAction{
	
	@Autowired
	private MbSysDeptService mbSysDeptService;
	
	/**
	 * To enter list
	 * @author 谭文广
	 * @param formMap
	 * @param pagination
	 * @return
	 */
	@RequestMapping(value = "/listByPage")
	public String listByPage(HttpServletRequest request,HttpServletResponse response,ModelMap map,FormMap formMap,Pagination p){
		formMap.getFormMap().put("is_delete","N");
		List<Map<String, Object>> list =  this.mbSysDeptService.findByPage(formMap.getFormMap(), p);
		map.put("list",list);
		map.put("formMap",formMap.getFormMap());
		map.put("pagination",p);
		return "user/mb_sys_dept_list";
	}
	
	/**
	 * To enter edit
	 * @author 谭文广
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/entryEdit")
	public String entryEdit(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map){
		map.put("data",this.mbSysDeptService.findById(formMap.getFormMap()));
		this.loadBaseData(request, formMap, map);
		return "user/mb_sys_dept_edit";
	}
	
	/**
	 * 加载基础数据
	 * @author 谭文广
	 * @param formMap
	 * @return
	 */
	public void loadBaseData(HttpServletRequest request,FormMap formMap,ModelMap map){
		Map<String,Object> paramMap = new HashMap<String,Object>();
		paramMap.put("is_delete","N");
		List<Map<String, Object>> list =  this.mbSysDeptService.findAll(paramMap);
		map.put("dept_list",list);//加载角色
	}
	
	/**
	 * Creating
	 * @author 谭文广
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/create")
	public String create(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map) throws Exception{
		this.mbSysDeptService.create(formMap.getFormMap());
		return "redirect:/pc/dept/listByPage";
	}
	
	/**
	 * Modifing
	 * @author 谭文广
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/modify")
	public String modify(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map) throws Exception{
		this.mbSysDeptService.modify(formMap.getFormMap());
		return "redirect:/pc/dept/listByPage";
	}
	
	/**
	 * Deleting
	 * @author 谭文广
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/delete")
	public String delete(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map) throws Exception{
		this.mbSysDeptService.remove(formMap.getFormMap());
		return "redirect:/pc/dept/listByPage";
	}
	

	/**
	 * To enter view
	 * @author 谭文广
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/entryView")
	public String entryView(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map){
		map.put("data",this.mbSysDeptService.findById(formMap.getFormMap()));
		return "user/mb_sys_dept_view";
	}

	/**
	 * 进入选择用户页面
	 * @author 谭文广
	 * @param formMap
	 * @param pagination
	 * @return
	 */
	@RequestMapping(value = "/toChoosedeptPage")
	public String toChoosedeptPage(HttpServletRequest request,HttpServletResponse response,ModelMap map,FormMap formMap,Pagination p){
		formMap.getFormMap().put("is_delete","N");
		//查找所有部门
		List<Map<String, Object>> deptList = this.mbSysDeptService.findAll(formMap.getFormMap());
		map.put("dept_list", deptList);
		map.put("formMap",formMap.getFormMap());
		return "common/choose_dept";
	}
	
}	