package com.qian.module.user.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.gzdec.framework.page.Pagination;
import com.gzdec.framework.util.UniqueIDGenerator;
import com.qian.module.user.service.inter.SysDeptGroupService;
import com.qian.module.user.service.inter.SysGroupService;
import com.qian.module.common.dao.CommonDao;
import com.qian.util.StringUtils;

/**
 * @author twg
 */
@Service("sysGroupServiceImpl")
public class SysGroupServiceImpl implements SysGroupService{
	
	private final static String NAMESPACE_ID = "user.sysGroup.";
	
	@Autowired
	private CommonDao commonDao;
	@Autowired
	private SysDeptGroupService sysDeptGroupService;
	
	public Map<String,Object> find(Map<String,Object> valueMap) {
		return this.commonDao.find(NAMESPACE_ID+commonDao.QUERY,valueMap);
	}
	
	public Map<String,Object> findById(Map<String,Object> valueMap) {
		if(StringUtils.isNull(valueMap.get("sg_id"))){
			return new HashMap<String,Object>();
		}
		return this.commonDao.find(NAMESPACE_ID+commonDao.QUERY,valueMap);
	}

	public List<Map<String,Object>> findAll(Map<String,Object> valueMap) {
		return this.commonDao.findAll(NAMESPACE_ID+commonDao.QUERY,valueMap);
	}

	public List<Map<String,Object>> findByPage(Map<String,Object> valueMap,Pagination pagination) {
		return this.commonDao.findByPage(NAMESPACE_ID+commonDao.QUERY,valueMap, pagination);
	}
	
	public String create(Map<String,Object> valueMap)  throws Exception{
		if(StringUtils.isNull(valueMap.get("sg_id"))){
			valueMap.put("sg_id", UniqueIDGenerator.getUUID());
		}
		this.sysDeptGroupService.create(valueMap);
		return this.commonDao.create(NAMESPACE_ID+commonDao.CREATE,valueMap);
	}	

	public int modify(Map<String,Object> valueMap) throws Exception{
		this.sysDeptGroupService.create(valueMap);
		if(valueMap.get("sg_id") != null){
			return this.commonDao.modify(NAMESPACE_ID+commonDao.MODIFY,valueMap);
		}else{
			return -1;
		}
	}

	public int remove(Map<String,Object> valueMap) throws Exception{
		String[] idArr = new String[1];
		if(valueMap.get("ids") != null && valueMap.get("ids").toString().length() > 0){
			if (valueMap.get("ids") instanceof String) {
				idArr[0] = valueMap.get("ids").toString();
			}else{
		    	idArr = (String[]) valueMap.get("ids");
			}
			List<Map<String,Object>> list = new ArrayList<Map<String,Object>>();
			Map<String,Object> toMap = null;
			for(String id : idArr){
				toMap = new HashMap<String,Object>();
				toMap.put("sg_id", id);
				list.add(toMap);
			}
			return this.commonDao.remove(NAMESPACE_ID+commonDao.DELETE,list);
		}else{
			return -1;
		}
	}
	
	
}