package com.qian.module.user.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Service;
import com.gzdec.framework.dao.SqlMapBaseDao;
import com.gzdec.framework.page.Pagination;
import com.ibatis.sqlmap.client.SqlMapClient;

/**
 * @author 谭文广
 */
@Service
public class SysRoleDao extends SqlMapBaseDao{
	/**
	 * Query List
	 * @author 谭文广
	 * @param valueMap
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<Map<String,Object>> findAll(Map<String,Object> to){
		return this.queryForList("user.sysRole.query", to);
	}
	
	/**
	 * Query Page List
	 * @author 谭文广
	 * @param valueMap
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<Map<String,Object>> findByPage(Map<String,Object> to,Pagination pagination){
		return this.queryForList("user.sysRole.query", to, pagination);
	}
	
	/**
	 * Get A Record
	 * @author 谭文广
	 * @param to
	 * @return
	 */
	@SuppressWarnings("unchecked")	 
	public Map<String,Object> find(Map<String,Object> to){
		return (Map<String,Object>)this.queryForObject("user.sysRole.query", to);
	}
	
	/**
	 * Creating
	 * @author 谭文广
	 * @param to
	 * @return
	 * @throws Exception 
	 */
	public int create(Map<String,Object> to) throws Exception{
		this.insert("user.sysRole.create", to);
		return 1;
	}
	
	/**
	 * Modify
	 * @author 谭文广
	 * @param to
	 * @return
	 * @throws Exception 
	 */
	public int modify(Map<String,Object> to) throws Exception{
		return this.update("user.sysRole.modify", to);
	}
	
	/**
	 * Deleting
	 * @author 谭文广
	 * @param to
	 * @return
	 * @throws Exception 
	 */
	public int remove(Map<String,Object> to) throws Exception{
		List<Map<String,Object>> list = new ArrayList<Map<String,Object>>();
		list.add(to);
		return this.remove(list);
	}
	
	/**
	 * Deleting List
	 * @author 谭文广
	 * @param list
	 * @return
	 */
	public int remove(List<Map<String,Object>> list){
		int count = 0;
		if(null == list || list.size() <= 0){
		    return count;
		}
		for(int i = 0; i < list.size(); i++){
		    Map<String,Object> to = list.get(i);
		    count += this.delete("user.sysRole.remove", to);
		}
		return count;
	}

	/**
	 * 查询角色其他关联信息
	 * @author 谭文广
	 * @param valueMap
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<Map<String,Object>> queryRoleOtherInfo(Map<String,Object> to,Pagination pagination){
		return this.queryForList("user.sysRole.queryRoleOtherInfo", to,pagination);
	}
	
	/**
	 * 根据角色ID查询角色与菜单关联信息
	 * @author 谭文广
	 * @param valueMap
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<Map<String,Object>> queryRoleAndMenuOpt(Map<String,Object> to){
		return this.queryForList("user.sysRole.queryRoleAndMenuOpt", to);
	}
	
	/**
	 * 根据角色ID批量删除角色与菜单关联信息（角色授权）
	 * @author 谭文广
	 * @param list
	 * @return
	 */
	public int delRoleAndMenuOpt(Map<String,Object> to){
		int count = this.delete("user.sysRole.delRoleAndMenuOpt", to);
		return count;
	}

	/**
	 * 批量添加角色与菜单关联信息（角色授权）
	 * @param list
	 * @return
	 * @throws SQLException 
	 */
	public int insertRoleAndMenuOpt(List<Map<String,Object>> list) throws SQLException{
		SqlMapClient client = null;
		int resultCount = 0;//成功处理条数
		try{
			client = this.getSqlMapClient();
			client.setUserConnection(null);
			client.startTransaction();
			client.startBatch();
			for(Map<String,Object> to : list){
				client.insert("user.sysRole.insertRoleAndMenuOpt",to);//批量插入
//				client.update("user.sysRole.updateRoleAndMenuOpt",to);//批量更新
				resultCount++;
			}
			client.executeBatch();
			client.commitTransaction();
		}catch(RuntimeException e){
			throw new RuntimeException();
		}finally{
			try {
				client.endTransaction();
			} catch (RuntimeException e) {
				throw new RuntimeException();
			}
		}
		return resultCount;
	}
	
}