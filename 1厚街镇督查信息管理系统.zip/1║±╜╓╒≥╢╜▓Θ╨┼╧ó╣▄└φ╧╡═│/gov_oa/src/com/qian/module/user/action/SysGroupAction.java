package com.qian.module.user.action;

import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;

import net.sf.json.JSONArray;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import com.gzdec.framework.page.Pagination;

import com.qian.module.common.action.BaseAction;
import com.qian.module.user.service.inter.MbSysDeptService;
import com.qian.module.user.service.inter.SysDeptGroupService;
import com.qian.module.user.service.inter.SysGroupService;
import com.qian.util.FormMap;
import com.qian.util.StringUtils;

/**
 * 描述：群组管理
 * @author twg
 */
@Controller
@Scope("prototype")
@RequestMapping(value = "/pc/group")
public class SysGroupAction extends BaseAction{
	
	@Autowired
	private SysGroupService sysGroupService;
	@Autowired
	private MbSysDeptService mbSysDeptService;
	@Autowired
	private SysDeptGroupService sysDeptGroupService;
	
	/**
	 * To enter list
	 * @author twg
	 * @param formMap
	 * @param pagination
	 * @return
	 */
	@RequestMapping(value = "/listByPage")
	public String listByPage(HttpServletRequest request,ModelMap map,FormMap formMap,Pagination p){
		List<Map<String, Object>> list =  this.sysGroupService.findByPage(formMap.getFormMap(), p);
		map.put("list",list);
		map.put("formMap",formMap.getFormMap());
		map.put("pagination",p);
		return "user/sys_group_list";
	}
	
	/**
	 * To enter edit
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/entryEdit")
	public String entryEdit(HttpServletRequest request,FormMap formMap,ModelMap map){
		Map<String,Object> groupMap = this.sysGroupService.findById(formMap.getFormMap());
		map.put("data",groupMap);
		this.paramMap.put("is_delete", "N");
		List<Map<String,Object>> list = this.mbSysDeptService.findAll(this.paramMap);
		map.put("list", list);
		
		if(groupMap != null && StringUtils.isNotNull(groupMap.get("sg_id"))){
			this.paramMap.put("sg_id", groupMap.get("sg_id"));
			List<Map<String,Object>> dgList = this.sysDeptGroupService.findAll(this.paramMap);
			JSONArray array = new JSONArray();
			array.addAll(dgList);
			map.put("dgList", array);
		}else{
			map.put("dgList", new JSONArray());
		}
		return "user/sys_group_edit";
	}
	
	/**
	 * Creating
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/create")
	public String create(HttpServletRequest request,FormMap formMap,ModelMap map) throws Exception{
		this.sysGroupService.create(formMap.getFormMap());
		return "redirect:/pc/group/listByPage";
	}
	
	/**
	 * Modifing
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/modify")
	public String modify(HttpServletRequest request,FormMap formMap,ModelMap map) throws Exception{
		this.sysGroupService.modify(formMap.getFormMap());
		return "redirect:/pc/group/listByPage";
	}
	
	/**
	 * Deleting
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/delete")
	public String delete(HttpServletRequest request,FormMap formMap,ModelMap map) throws Exception{
		this.sysGroupService.remove(formMap.getFormMap());
		return "redirect:/pc/group/listByPage";
	}
	

	/**
	 * To enter view
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/entryView")
	public String entryView(HttpServletRequest request,FormMap formMap,ModelMap map){
		map.put("data",this.sysGroupService.findById(formMap.getFormMap()));
		return "user/sys_group_view";
	}

}	