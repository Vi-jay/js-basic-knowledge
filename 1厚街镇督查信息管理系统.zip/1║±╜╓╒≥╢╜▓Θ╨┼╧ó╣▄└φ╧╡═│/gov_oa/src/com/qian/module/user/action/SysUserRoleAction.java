package com.qian.module.user.action;

import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import com.gzdec.framework.page.Pagination;

import com.qian.module.user.service.inter.SysUserRoleService;
import com.qian.util.FormMap;

/**
 * 描述：用户与角色关联信息管理
 * @author 谭文广
 */
@Controller
@Scope("prototype")
@RequestMapping(value = "/pc/userrole")
public class SysUserRoleAction{
	
	@Autowired
	private SysUserRoleService sysUserRoleService;
	
	/**
	 * To enter list
	 * @author 谭文广
	 * @param formMap
	 * @param pagination
	 * @return
	 */
	@RequestMapping(value = "/listByPage")
	public String listByPage(HttpServletRequest request,HttpServletResponse response,ModelMap map,FormMap formMap,Pagination p){
		List<Map<String, Object>> list =  this.sysUserRoleService.findByPage(formMap.getFormMap(), p);
		map.put("list",list);
		map.put("formMap",formMap.getFormMap());
		map.put("pagination",p);
		return "user/sys_user_role_list";
	}
	
	/**
	 * To enter edit
	 * @author 谭文广
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/entryEdit")
	public String entryEdit(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map){
		map.put("data",this.sysUserRoleService.findById(formMap.getFormMap()));
		return "user/sys_user_role_edit";
	}
	
	/**
	 * Creating
	 * @author 谭文广
	 * @param formMap
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value = "/create")
	public String create(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map) throws Exception{
		this.sysUserRoleService.create(formMap.getFormMap());
		return "redirect:/pc/userrole/listByPage";
	}
	
	/**
	 * Modifing
	 * @author 谭文广
	 * @param formMap
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value = "/modify")
	public String modify(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map) throws Exception{
		this.sysUserRoleService.modify(formMap.getFormMap());
		return "redirect:/pc/userrole/listByPage";
	}
	
	/**
	 * Deleting
	 * @author 谭文广
	 * @param formMap
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value = "/delete")
	public String delete(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map) throws Exception{
		this.sysUserRoleService.remove(formMap.getFormMap());
		return "redirect:/pc/userrole/listByPage";
	}
	

	/**
	 * To enter view
	 * @author 谭文广
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/entryView")
	public String entryView(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map){
		map.put("data",this.sysUserRoleService.findById(formMap.getFormMap()));
		return "user/sys_user_role_view";
	}

}	