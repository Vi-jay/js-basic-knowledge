package com.qian.module.user.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Service;
import com.gzdec.framework.dao.SqlMapBaseDao;
import com.gzdec.framework.page.Pagination;

/**
 * @author 谭文广
 */
@Service
public class MbSysUserDeptDao extends SqlMapBaseDao{
	/**
	 * Query List
	 * @author 谭文广
	 * @param valueMap
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<Map<String,Object>> findAll(Map<String,Object> to){
		return this.queryForList("user.mbSysUserDept.query", to);
	}
	
	/**
	 * Query Page List
	 * @author 谭文广
	 * @param valueMap
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<Map<String,Object>> findByPage(Map<String,Object> to,Pagination pagination){
		return this.queryForList("user.mbSysUserDept.query", to, pagination);
	}
	
	/**
	 * Get A Record
	 * @author 谭文广
	 * @param to
	 * @return
	 */
	@SuppressWarnings("unchecked")	 
	public Map<String,Object> find(Map<String,Object> to){
		return (Map<String,Object>)this.queryForObject("user.mbSysUserDept.query", to);
	}
	
	/**
	 * Creating
	 * @author 谭文广
	 * @param to
	 * @return
	 */
	public int create(Map<String,Object> to) throws Exception{
		this.insert("user.mbSysUserDept.create", to);
		return 1;
	}
	
	/**
	 * Modify
	 * @author 谭文广
	 * @param to
	 * @return
	 */
	public int modify(Map<String,Object> to) throws Exception{
		return this.update("user.mbSysUserDept.modify", to);
	}
	
	/**
	 * Deleting
	 * @author 谭文广
	 * @param to
	 * @return
	 */
	public int remove(Map<String,Object> to) throws Exception{
		List<Map<String,Object>> list = new ArrayList<Map<String,Object>>();
		list.add(to);
		return this.remove(list);
	}
	
	/**
	 * Deleting List
	 * @author 谭文广
	 * @param list
	 * @return
	 */
	public int remove(List<Map<String,Object>> list){
		int count = 0;
		if(null == list || list.size() <= 0){
		    return count;
		}
		for(int i = 0; i < list.size(); i++){
		    Map<String,Object> to = list.get(i);
		    count += this.delete("user.mbSysUserDept.remove", to);
		}
		return count;
	}


	/**
	 * 根据用户ID删除用户与部门关联信息
	 * @author 谭文广
	 * @param list
	 * @return
	 */
	public int removeUserDept(Map<String,Object> to){
		int count = this.delete("user.mbSysUserDept.removeUserDept", to);
		return count;
	}

	/**
	 * Query List
	 * @author 谭文广
	 * @param valueMap
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<Map<String,Object>> queryAllUserByDept(Map<String,Object> to){
		return this.queryForList("user.mbSysUserDept.queryAllUserByDept", to);
	}

}