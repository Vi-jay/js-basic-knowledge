package com.qian.module.user.action;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.gzdec.framework.page.Pagination;
import com.gzdec.framework.util.UniqueIDGenerator;
import com.qian.module.common.action.BaseAction;
import com.qian.module.user.service.inter.MbSysDeptService;
import com.qian.module.user.service.inter.SysRoleService;
import com.qian.module.user.service.inter.SysUserService;
import com.qian.util.FormMap;
import com.qian.util.SessionUtil;

/**
 * 描述：角色管理
 * @author 谭文广
 */
@Controller
@Scope("prototype")
@RequestMapping(value = "/pc/role")
public class SysRoleAction extends BaseAction{
	
	@Autowired
	private SysRoleService sysRoleService;
	@Autowired
	private SysUserService sysUserService;
	@Autowired
	private MbSysDeptService mbSysDeptService;
	
	/**
	 * To enter list
	 * @author 谭文广
	 * @param formMap
	 * @param pagination
	 * @return
	 */
	@RequestMapping(value = "/listByPage")
	public String listByPage(HttpServletRequest request,HttpServletResponse response,ModelMap map,FormMap formMap,Pagination p){
//		List<Map<String, Object>> list =  this.sysRoleService.findByPage(formMap.getFormMap(), p);
		formMap.getFormMap().put("role_type","B");
		if("A".equals(SessionUtil.getLoginUserType(request))){
			formMap.getFormMap().put("login_user_id",SessionUtil.getLoginUserId(request));
		}
		List<Map<String, Object>> list =  this.sysRoleService.findRoleOtherInfo(formMap.getFormMap(), p);
		map.put("list",list);
		map.put("formMap",formMap.getFormMap());
		map.put("pagination",p);
		
		this.loadBaseData(request,formMap, map);
//		this.test();
		return "user/sys_role_list";
	}
	

	public void test(){
		List<String> glList = new ArrayList<String>();//管理员
		glList.add("43fda9b040534138b1b8069b1ad0c694");
		glList.add("802bd956f06041448b20d3a4df1bff0a");
		glList.add("cb634a09252d4354b44c3d994ff284c0");
		glList.add("b12400bb93f741c08b6898677ca8eecf");
		glList.add("a87c8b3bad8342138ca9815a73ad5fa7");
		glList.add("8c7c46c31a414397a1194c3829fc49e6");
		glList.add("c1ee9595662646138f430465ef76340c");
		glList.add("72cd8b29073b4d919e8cfa5c6b421acb");
		glList.add("5dcfa18c43834c66af48f0b13a866925");
		glList.add("21e80ed36ef640ea8ae078c0bb07a130");
		
		List<String> tbList = new ArrayList<String>();//填报员
		tbList.add("b12400bb93f741c08b6898677ca8eecf");
		tbList.add("cb634a09252d4354b44c3d994ff284c0");
		tbList.add("21e80ed36ef640ea8ae078c0bb07a130");
		tbList.add("8c7c46c31a414397a1194c3829fc49e6");
		tbList.add("c1ee9595662646138f430465ef76340c");
		tbList.add("a87c8b3bad8342138ca9815a73ad5fa7");
		
		//查询所有角色
		List<Map<String, Object>> list =  this.sysRoleService.findAll(null);
		int a = 0;
		int b = 0;
		int c = 0;
		for(Map<String, Object> map : list){
			a++;
			if(map.get("role_id").toString().equals("2f68b783b7e2485ba329d37f11540000") 
					|| map.get("role_id").toString().equals("2f68b783b7e2485ba329d37f11540001") 
					|| map.get("role_id").toString().equals("2f68b783b7e2485ba329d37f11540002")
					|| map.get("role_id").toString().equals("2f68b783b7e2485ba329d37f11540038")
					|| map.get("role_id").toString().equals("2f68b783b7e2485ba329d37f11540096")){
			}else if(map.get("role_name").toString().contains("管理员")){
				for(String gl : glList){
					this.log.info("INSERT INTO mb_sys_role_menuopt VALUE ('"+UniqueIDGenerator.getUUID()+"', '"+map.get("role_id").toString()+"', '"+gl+"');");
				}
				b++;
			}else if(map.get("role_name").toString().contains("填报员")){
				for(String tb : tbList){
					this.log.info("INSERT INTO mb_sys_role_menuopt VALUE ('"+UniqueIDGenerator.getUUID()+"', '"+map.get("role_id").toString()+"', '"+tb+"');");
				}
				c++;
			}
		}
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
	}
	
	/**
	 * 加载基础数据
	 * @author 谭文广
	 * @param formMap
	 * @return
	 */
	public void loadBaseData(HttpServletRequest request,FormMap formMap,ModelMap map){
		Map<String,Object> paramMap = new HashMap<String,Object>();
		paramMap.put("is_delete","N");
		if("A".equals(SessionUtil.getLoginUserType(request))){
			paramMap.put("login_user_id",SessionUtil.getLoginUserId(request));
		}
		List<Map<String, Object>> list =  this.sysRoleService.findAll(paramMap);
		map.put("role_list",list);//加载角色
		
		List<Map<String, Object>> deptList =  this.mbSysDeptService.findAll(paramMap);
		map.put("dept_list",deptList);//加载部门
	}
	
	/**
	 * To enter edit
	 * @author 谭文广
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/entryEdit")
	public String entryEdit(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map){
		map.put("data",this.sysRoleService.findById(formMap.getFormMap()));
		this.loadBaseData(request,formMap, map);
		return "user/sys_role_edit";
	}
	
	/**
	 * Creating
	 * @author 谭文广
	 * @param formMap
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value = "/create")
	public String create(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map) throws Exception{
		this.sysRoleService.create(formMap.getFormMap());
		return "redirect:/pc/role/listByPage";
	}
	
	/**
	 * Modifing
	 * @author 谭文广
	 * @param formMap
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value = "/modify")
	public String modify(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map) throws Exception{
		this.sysRoleService.modify(formMap.getFormMap());
		return "redirect:/pc/role/listByPage";
	}
	
	/**
	 * Deleting
	 * @author 谭文广
	 * @param formMap
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value = "/delete")
	public String delete(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map) throws Exception{
		this.sysRoleService.remove(formMap.getFormMap());
		return "redirect:/pc/role/listByPage";
	}
	

	/**
	 * To enter view
	 * @author 谭文广
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/entryView")
	public String entryView(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map){
		map.put("data",this.sysRoleService.findById(formMap.getFormMap()));
		return "user/sys_role_view";
	}
	
	/**
	 * 进入角色授权页面
	 * @author 谭文广
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/roleAuthorize")
	public String roleAuthorize(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map){
		map.put("data",this.sysRoleService.findById(formMap.getFormMap()));
		this.paramMap.put("user_id", SessionUtil.getLoginUserId(request));
		this.paramMap.put("user_type", SessionUtil.getLoginUserType(request));
		List<Map<String, Object>> list = this.sysUserService.findUserMenu(this.paramMap);
//		List<Map<String, Object>> list = sysMenuoptService.findAll(this.paramMap);//所有菜单
		JSONArray jsonArray = new JSONArray();
		//1、添加根元素
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("name","所有菜单");
		jsonObject.put("id","all");
		jsonObject.put("open","true");//默认展开
		jsonArray.add(jsonObject);
		//2、PC
		jsonObject = new JSONObject();
		jsonObject.put("name","PC端所有菜单");
		jsonObject.put("id","0");
		jsonObject.put("pid","all");
		jsonObject.put("open","true");//默认展开
		jsonArray.add(jsonObject);
		//3、APP
		jsonObject = new JSONObject();
		jsonObject.put("name","APP端所有菜单");
		jsonObject.put("id","-1");
		jsonObject.put("pid","all");
		jsonObject.put("open","true");//默认展开
		jsonArray.add(jsonObject);
		for(Map<String, Object> menuMap : list){
			jsonObject = new JSONObject();
			if("Y".equals(menuMap.get("is_menu_opt").toString())){
				jsonObject.put("name",menuMap.get("menu_name"));
				jsonObject.put("id",menuMap.get("menu_id"));
				jsonObject.put("pid",menuMap.get("parent_id"));
				jsonObject.put("temp",menuMap.get("menuopt_id"));
			}else{
				jsonObject.put("name",menuMap.get("opt_name"));
				jsonObject.put("id",menuMap.get("menuopt_id"));
				jsonObject.put("pid",menuMap.get("menu_id"));
				jsonObject.put("temp",menuMap.get("menuopt_id"));
			}
			if("2".equals(menuMap.get("menu_level").toString()) || "B".equals(menuMap.get("menu_type").toString())){
				jsonObject.put("check",menuMap.get("menuopt_id").toString()+"_check");//操作菜单ID
			}
			jsonArray.add(jsonObject);
		}
		map.put("menuAndOpt",jsonArray);
		
		List<Map<String, Object>> alreadylist = sysRoleService.findRoleAndMenuOpt(formMap.getFormMap());
		jsonArray = new JSONArray();
		jsonArray.addAll(alreadylist);
		map.put("menuToRole", jsonArray);
		return "user/sys_role_authorize";
	}
	
	/**
	 * 角色授权操作
	 * @author 谭文广
	 * @param request
	 * @param response
	 * @param formMap
	 * @param map
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value = "/authorize")
	public String authorize(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map,String menuOptIds) throws Exception{
		formMap.getFormMap().put("menuOptIds",menuOptIds);
		this.sysRoleService.createRoleAndMenuOpt(formMap.getFormMap());
		return "redirect:/pc/role/listByPage";
	}

	/**
	 * 验证角色编码是否已经存在
	 * @param formMap
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = "/verificationRoleCode", method = RequestMethod.POST, produces = { "application/json;charset=UTF-8" })
	public  @ResponseBody Map<String,Object> verificationRoleCode(HttpServletRequest request,FormMap formMap) throws IOException {
		Map<String,Object> paramMap = new HashMap<String,Object>();
		paramMap.put("role_code",formMap.getFormMap().get("role_code"));
		List<Map<String, Object>> list = this.sysRoleService.findAll(paramMap);
		if(list != null && list.size() > 0){
			if(formMap.getFormMap().get("role_id") != null){
				String role_id_f = formMap.getFormMap().get("role_id").toString();
				String role_id_r = list.get(0).get("role_id").toString();
				if(role_id_f.equals(role_id_r)){
					paramMap.put("result","N");//未重复
				}else{
					paramMap.put("result","Y");//重复
				}
			}else{
				paramMap.put("result","Y");//重复
			}
		}else{
			paramMap.put("result","N");//未重复
		}
		return paramMap;
	}
	
	
}	
