package com.qian.module.user.action;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.gzdec.framework.page.Pagination;
import com.qian.module.user.service.inter.SysDeptGroupService;
import com.qian.util.FormMap;

/**
 * 描述：部门群组管理
 * @author twg
 */
@Controller
@Scope("prototype")
@RequestMapping(value = "/pc/deptgroup")
public class SysDeptGroupAction{
	
	@Autowired
	private SysDeptGroupService sysDeptGroupService;
	
	/**
	 * To enter list
	 * @author twg
	 * @param formMap
	 * @param pagination
	 * @return
	 */
	@RequestMapping(value = "/listByPage")
	public String listByPage(HttpServletRequest request,ModelMap map,FormMap formMap,Pagination p){
		List<Map<String, Object>> list =  this.sysDeptGroupService.findByPage(formMap.getFormMap(), p);
		map.put("list",list);
		map.put("formMap",formMap.getFormMap());
		map.put("pagination",p);
		return "user/sys_dept_group_list";
	}
	
	/**
	 * To enter edit
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/entryEdit")
	public String entryEdit(HttpServletRequest request,FormMap formMap,ModelMap map){
		map.put("data",this.sysDeptGroupService.findById(formMap.getFormMap()));
		return "user/sys_dept_group_edit";
	}
	
	/**
	 * Creating
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/create")
	public String create(HttpServletRequest request,FormMap formMap,ModelMap map) throws Exception{
		this.sysDeptGroupService.create(formMap.getFormMap());
		return "redirect:/pc/deptgroup/listByPage";
	}
	
	/**
	 * Modifing
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/modify")
	public String modify(HttpServletRequest request,FormMap formMap,ModelMap map) throws Exception{
		this.sysDeptGroupService.modify(formMap.getFormMap());
		return "redirect:/pc/deptgroup/listByPage";
	}
	
	/**
	 * Deleting
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/delete")
	public String delete(HttpServletRequest request,FormMap formMap,ModelMap map) throws Exception{
		this.sysDeptGroupService.remove(formMap.getFormMap());
		return "redirect:/pc/deptgroup/listByPage";
	}
	

	/**
	 * To enter view
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/entryView")
	public String entryView(HttpServletRequest request,FormMap formMap,ModelMap map){
		map.put("data",this.sysDeptGroupService.findById(formMap.getFormMap()));
		return "user/sys_dept_group_view";
	}

	/**
	 * 进入选择单位群组页面
	 * @author 谭文广
	 * @param formMap
	 * @param pagination
	 * @return
	 */
	@RequestMapping(value = "/chooseDeptGroup")
	public String chooseDeptGroup(HttpServletRequest request,ModelMap map,FormMap formMap,Pagination p){
		map.put("formMap", formMap.getFormMap());
		//查询所有组以及组下所有部门
		List<Map<String, Object>> dgList = this.sysDeptGroupService.findGroupDept(null);
		map.put("dgList", dgList);
		
//		formMap.getFormMap().put("is_delete","N");
//		//查找所有部门
//		List<Map<String, Object>> deptList = this.mbSysDeptService.findAll(formMap.getFormMap());
//		map.put("deptlist", deptList);
		return "common/choose_deptgroup";
	}
	
	/**
	 * 根据部门组ID查询部门
	 * @param formMap
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = "/findDeptByGroup", method = RequestMethod.POST, produces = { "application/json;charset=UTF-8" })
	public @ResponseBody Map<String,Object> findDeptByGroup(FormMap formMap) throws IOException {
		Map<String,Object> paramMap = new HashMap<String,Object>();
		formMap.getFormMap().put("groupIds", formMap.getFormMap().get("groupIds").toString().substring(0, formMap.getFormMap().get("groupIds").toString().length()-1));
		paramMap.put("list", this.sysDeptGroupService.findDeptByGroup(formMap.getFormMap()));
		return paramMap;
	}
	
}	