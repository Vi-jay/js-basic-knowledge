package com.qian.module.user.service.inter;

import java.util.List;
import java.util.Map;
import com.gzdec.framework.page.Pagination;

/**
 * @author 谭文广
 */
public interface SysUserService {

	/**
	 * Query List
	 * @author 谭文广
	 * @param valueMap
	 * @return
	 */
	public List<Map<String,Object>> findAll(Map<String,Object> valueMap);
	
	/**
	 * Query Page List
	 * @author 谭文广
	 * @param valueMap
	 * @return
	 */
	public List<Map<String,Object>> findByPage(Map<String,Object> valueMap,Pagination pagination);
	
	/**
	 * Get A Record
	 * @author 谭文广
	 * @param valueMap
	 * @return
	 */
	public Map<String,Object> find(Map<String,Object> valueMap);
	
	/**
	 * Get A Record
	 * @author 谭文广
	 * @param valueMap
	 * @return
	 */
	public Map<String,Object> findById(Map<String,Object> valueMap);
	
	/**
	 * Creating
	 * @author 谭文广
	 * @param valueMap
	 * @return
	 */
	public int create(Map<String,Object> valueMap) throws Exception ;	
	
	/**
	 * Modifing
	 * @author 谭文广
	 * @param valueMap
	 * @return
	 */
	public int modify(Map<String,Object> valueMap) throws Exception ;	
	
	/**
	 * Deleting
	 * @author 谭文广
	 * @param valueMap
	 * @return
	 */
	public int remove(Map<String,Object> valueMap) throws Exception ;
	
	/**
	 * 查询用户其他关联信息（角色，部门）
	 * @author 谭文广
	 * @param valueMap
	 * @return
	 */
	public List<Map<String,Object>> findUserOtherInfo(Map<String,Object> valueMap,Pagination pagination);

	/**
	 * 根据用户ID查询用户菜单
	 * @author 谭文广
	 * @param valueMap
	 * @return
	 */
	public List<Map<String,Object>> findUserMenu(Map<String,Object> valueMap);

	/**
	 * 根据channel_id取消所有已绑定用户
	 * @author 谭文广
	 * @param valueMap
	 * @return
	 */
	public int removeUserByChannelId(Map<String,Object> valueMap) throws Exception;
}