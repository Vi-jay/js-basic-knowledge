package com.qian.module.user.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Service;
import com.gzdec.framework.dao.SqlMapBaseDao;
import com.gzdec.framework.page.Pagination;

/**
 * @author 谭文广
 */
@Service
public class SysUserRoleDao extends SqlMapBaseDao{
	/**
	 * Query List
	 * @author 谭文广
	 * @param valueMap
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<Map<String,Object>> findAll(Map<String,Object> to){
		return this.queryForList("user.sysUserRole.query", to);
	}
	
	/**
	 * Query Page List
	 * @author 谭文广
	 * @param valueMap
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<Map<String,Object>> findByPage(Map<String,Object> to,Pagination pagination){
		return this.queryForList("user.sysUserRole.query", to, pagination);
	}
	
	/**
	 * Get A Record
	 * @author 谭文广
	 * @param to
	 * @return
	 */
	@SuppressWarnings("unchecked")	 
	public Map<String,Object> find(Map<String,Object> to){
		return (Map<String,Object>)this.queryForObject("user.sysUserRole.query", to);
	}
	
	/**
	 * Creating
	 * @author 谭文广
	 * @param to
	 * @return
	 * @throws Exception 
	 */
	public int create(Map<String,Object> to) throws Exception{
		this.insert("user.sysUserRole.create", to);
		return 1;
	}
	
	/**
	 * Modify
	 * @author 谭文广
	 * @param to
	 * @return
	 * @throws Exception 
	 */
	public int modify(Map<String,Object> to) throws Exception{
		return this.update("user.sysUserRole.modify", to);
	}
	
	/**
	 * Deleting
	 * @author 谭文广
	 * @param to
	 * @return
	 * @throws Exception 
	 */
	public int remove(Map<String,Object> to) throws Exception{
		List<Map<String,Object>> list = new ArrayList<Map<String,Object>>();
		list.add(to);
		return this.remove(list);
	}
	
	/**
	 * Deleting List
	 * @author 谭文广
	 * @param list
	 * @return
	 */
	public int remove(List<Map<String,Object>> list){
		int count = 0;
		if(null == list || list.size() <= 0){
		    return count;
		}
		for(int i = 0; i < list.size(); i++){
		    Map<String,Object> to = list.get(i);
		    count += this.delete("user.sysUserRole.remove", to);
		}
		return count;
	}

	/**
	 * 根据用户ID删除用户与角色关联信息
	 * @author 谭文广
	 * @param list
	 * @return
	 */
	public int removeUserRole(Map<String,Object> to){
		int count = this.delete("user.sysUserRole.removeUserRole", to);
		return count;
	}




}