package com.qian.module.user.action;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.qian.module.user.service.inter.MbSysDeptService;
import com.qian.module.user.service.inter.MbSysUserDeptService;
import com.qian.module.user.service.inter.SysRoleService;
import com.qian.module.user.service.inter.SysUserRoleService;
import com.qian.module.user.service.inter.SysUserService;
import com.qian.util.FormMap;
import com.qian.util.MD5Utils;
import com.qian.util.SessionUtil;
import com.qian.util.StringUtils;
import com.gzdec.framework.page.Pagination;

/**
 * 描述：用户管理
 * @author 谭文广
 */
@Controller
@Scope("prototype")
@RequestMapping(value = "/pc/user")
public class SysUserAction{
	
	@Autowired
	private SysUserService sysUserService;
	@Autowired
	private SysRoleService sysRoleService;
	@Autowired
	private MbSysDeptService mbSysDeptService;
	@Autowired
	private SysUserRoleService sysUserRoleService;
	@Autowired
	private MbSysUserDeptService mbSysUserDeptService;
	
	/**
	 * To enter list
	 * @author 谭文广
	 * @param formMap
	 * @param pagination
	 * @return
	 */
	@RequestMapping(value = "/listByPage")
	public String listByPage(HttpServletRequest request,HttpServletResponse response,ModelMap map,FormMap formMap,Pagination p){
		formMap.getFormMap().put("user_type","A");
		if(StringUtils.isNotNull(formMap.getFormMap().get("is_frozen"))){
		}else{
			formMap.getFormMap().put("is_frozen","N");
		}
		if("A".equals(SessionUtil.getLoginUserType(request))){
			formMap.getFormMap().put("login_user_id",SessionUtil.getLoginUserId(request));//根据登录用户ID查询部门用户
			formMap.getFormMap().remove("search_dept_name");
		}
		List<Map<String, Object>> list =  this.sysUserService.findByPage(formMap.getFormMap(), p);
//		List<Map<String, Object>> list =  this.sysUserService.findUserOtherInfo(formMap.getFormMap(), p);
		map.put("list",list);
		map.put("formMap",formMap.getFormMap());
		map.put("pagination",p);
		
		this.loadBaseData(request,formMap, map);
		return "user/sys_user_list";
	}
	
	/**
	 * 进入选择用户页面
	 * @author 谭文广
	 * @param formMap
	 * @param pagination
	 * @return
	 */
	@RequestMapping(value = "/toChooseUserPage")
	public String toChooseUserPage(HttpServletRequest request,HttpServletResponse response,ModelMap map,FormMap formMap,Pagination p){
		formMap.getFormMap().put("user_type","A");
		formMap.getFormMap().put("is_frozen","N");
		formMap.getFormMap().put("is_delete","N");
		//查找所有部门
		List<Map<String, Object>> deptList = this.mbSysDeptService.findAll(formMap.getFormMap());
		//查找所有部门下的用户
		if(deptList != null && deptList.size() > 0){
			List<Map<String, Object>> userDeptList =  this.mbSysUserDeptService.findAll(formMap.getFormMap());
			List<Map<String, Object>> userList = null;
			Map<String, Object> userMap = null;
			for(Map<String, Object> deptMap : deptList){
				userList = new ArrayList<Map<String, Object>>();
				for(Map<String, Object> userDeptMap : userDeptList){
					if(deptMap.get("dept_id").toString().equals(userDeptMap.get("dept_id").toString())){
						userMap = new HashMap<String,Object>();
						userMap.put("user_id",userDeptMap.get("user_id"));
						userMap.put("real_name",userDeptMap.get("real_name"));
						userMap.put("title_explain",userDeptMap.get("title_explain"));
						userList.add(userMap);
					}
				}
				deptMap.put("user_list", userList);
			}
		}
		map.put("dept_user_list", deptList);
		map.put("formMap",formMap.getFormMap());
		return "common/choose_user";
	}
	
	/**
	 * 加载基础数据
	 * @author 谭文广
	 * @param formMap
	 * @return
	 */
	public void loadBaseData(HttpServletRequest request,FormMap formMap,ModelMap map){
		Map<String,Object> paramMap = new HashMap<String,Object>();
		paramMap.put("is_delete","N");
		if("A".equals(SessionUtil.getLoginUserType(request))){
			paramMap.put("login_user_id",SessionUtil.getLoginUserId(request));
		}
		List<Map<String, Object>> list =  this.sysRoleService.findAll(paramMap);
		map.put("role_list",list);//加载角色
		List<Map<String, Object>> deptList =  this.mbSysDeptService.findAll(paramMap);
		map.put("dept_list",deptList);//加载角色
	}
	
	/**
	 * To enter edit
	 * @author 谭文广
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/entryEdit")
	public String entryEdit(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map){
		Map<String, Object> roleMap = this.sysUserService.findById(formMap.getFormMap());
		this.getUserRole(roleMap, formMap, map);//查询该用户所对应的所有角色（已分配）
//		this.getUserDept(roleMap, formMap, map);//查询该用户所对应的所有部门（已分配）
		map.put("data",roleMap);
		this.getDeptRoleList(request, map);
//		this.loadBaseData(request,formMap, map);
		return "user/sys_user_edit";
	}
	
	/**
	 * 根据登录用户ID查询相应的部门以及角色
	 */
	private void getDeptRoleList(HttpServletRequest request,ModelMap map){
		Map<String,Object> paramMap = new HashMap<String,Object>();
		paramMap.put("is_delete","N");
//		paramMap.put("login_user_id",SessionUtil.getLoginUserId(request));
		if("A".equals(SessionUtil.getLoginUserType(request))){
			paramMap.put("login_user_id",SessionUtil.getLoginUserId(request));
		}
		List<Map<String,Object>> deptList = this.mbSysDeptService.findAll(paramMap);
		if(deptList != null && deptList.size() > 0){
//			paramMap.put("role_type","B");//普通角色
			List<Map<String,Object>> roleList = this.sysRoleService.findAll(paramMap);//所有角色
			List<Map<String,Object>> deptRoleList = null;
			Map<String,Object> roleInfo = null;
			for(Map<String,Object> dept : deptList){
				deptRoleList = new ArrayList<Map<String,Object>>();
				for(Map<String,Object> role : roleList){
					if(dept.get("dept_id").toString().equals(role.get("dept_id").toString())){
						roleInfo = new HashMap<String,Object>();
						roleInfo.put("role_id", role.get("role_id"));
						roleInfo.put("dept_id", role.get("dept_id"));
						roleInfo.put("role_name", role.get("role_name"));
						roleInfo.put("role_code", role.get("role_code"));
						deptRoleList.add(roleInfo);
					}
				}
				dept.put("deptRoleList", deptRoleList);
			}
			map.put("allDeptRoleList", deptList);
		}
	}
	
	/**
	 * 1、查找某一用户对应所有角色信息（修改操作）
	 * @param formMap
	 * @param map
	 */
	private void getUserRole(Map<String, Object> roleMap,FormMap formMap,ModelMap map){
		JSONArray jsonArray = new JSONArray(); 
		if(roleMap != null && roleMap.get("user_id") != null){
			Map<String,Object> paramMap = new HashMap<String,Object>();
			paramMap.put("user_id",roleMap.get("user_id"));
			List<Map<String, Object>> list =  this.sysUserRoleService.findAll(paramMap);
			if(list != null && list.size() > 0){
				jsonArray.addAll(list);
			}
		}else{
			roleMap = new HashMap<String,Object>();
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("role_id", formMap.getFormMap().get("role_id"));
			jsonArray.add(jsonObject);
		}
		map.put("role_list_json",jsonArray.toJSONString());
	}
	
//	/**
//	 * 1、查找某一用户对应所有部门信息（修改操作）
//	 * @param formMap
//	 * @param map
//	 */
//	private void getUserDept(Map<String, Object> roleMap,FormMap formMap,ModelMap map){
//		JSONArray jsonArray = new JSONArray(); 
//		if(roleMap != null && roleMap.get("user_id") != null){
//			Map<String,Object> paramMap = new HashMap<String,Object>();
//			paramMap.put("user_id",roleMap.get("user_id"));
//			List<Map<String, Object>> list =  this.mbSysUserDeptService.findAll(paramMap);
//			if(list != null && list.size() > 0){
//				jsonArray.addAll(list);
//			}
//		}else{
//			roleMap = new HashMap<String,Object>();
//			JSONObject jsonObject = new JSONObject();
//			jsonObject.put("dept_id", formMap.getFormMap().get("dept_id"));
//			jsonArray.add(jsonObject);
//		}
//		map.put("dept_list_json",jsonArray.toJSONString());
//	}
	
	/**
	 * Creating
	 * @author 谭文广
	 * @param formMap
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value = "/create")
	public String create(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map) throws Exception{
		this.setPassword(formMap);
		this.sysUserService.create(formMap.getFormMap());
//		this.userRoleInfo(formMap);
		return "redirect:/pc/user/listByPage";
	}
	
	/**
	 * Modifing
	 * @author 谭文广
	 * @param formMap
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value = "/modify")
	public String modify(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map) throws Exception{
		this.setPassword(formMap);
		this.sysUserService.modify(formMap.getFormMap());
//		this.userRoleInfo(formMap);
		return "redirect:/pc/user/listByPage";
	}
	
	/**
	 * 冻结用户操作
	 * @author 谭文广
	 * @param formMap
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value = "/frozen")
	public String frozen(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map) throws Exception{
		if(StringUtils.isNotNull(formMap.getFormMap().get("user_id")) && StringUtils.isNotNull(formMap.getFormMap().get("is_frozen"))){
			this.sysUserService.modify(formMap.getFormMap());
		}
		return "redirect:/pc/user/listByPage";
	}
	
	/**
	 * 设置密码
	 * @author 谭文广
	 * @param formMap
	 * @return
	 */
	public boolean setPassword(FormMap formMap){
		if(formMap.getFormMap().get("password") != null){
			formMap.getFormMap().put("password",MD5Utils.getMD5Code(formMap.getFormMap().get("password").toString()));//第一次加密
			formMap.getFormMap().put("password",MD5Utils.getMD5Code(formMap.getFormMap().get("password").toString()));//第二次加密
			return true;
		}
		return false;
	}
	
//	/**
//	 * 用户与角色关联信息处理
//	 * @author 谭文广
//	 * @param formMap
//	 * @return
//	 * @throws Exception 
//	 */
//	public boolean userRoleInfo(FormMap formMap) throws Exception{
//		if(formMap.getFormMap().get("user_id") == null || formMap.getFormMap().get("role_id") == null){
//			return false;
//		}
//		Map<String,Object> paramMap = new HashMap<String,Object>();
//		//1、删除用户与角色关联信息
//		paramMap.put("user_id", formMap.getFormMap().get("user_id"));
//		sysUserRoleService.removeUserRole(paramMap);
//		this.mbSysUserDeptService.removeUserDept(paramMap);
//		//2、添加用户与角色关联信息
//		String[] roleIds = (String[]) formMap.getFormMap().get("role_id");
//		for(int i = 0;i<roleIds.length;i++){
//			if(i<roleIds.length-1){//去掉最后一个
//				paramMap = new HashMap<String,Object>();
//				paramMap.put("user_id", formMap.getFormMap().get("user_id"));
//				paramMap.put("role_id", roleIds[i]);
//				sysUserRoleService.create(paramMap);
//			}
//		}
//		//2、添加用户与角色关联信息
//		String[] deptIds = (String[]) formMap.getFormMap().get("dept_id");
//		for(int i = 0;i<deptIds.length;i++){
//			if(i<deptIds.length-1){//去掉最后一个
//				paramMap = new HashMap<String,Object>();
//				paramMap.put("user_id", formMap.getFormMap().get("user_id"));
//				paramMap.put("dept_id", deptIds[i]);
//				this.mbSysUserDeptService.create(paramMap);
//			}
//		}
//		return true;
//	}
	
	/**
	 * Deleting
	 * @author 谭文广
	 * @param formMap
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value = "/delete")
	public String delete(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map) throws Exception{
		this.sysUserService.remove(formMap.getFormMap());
		return "redirect:/pc/user/listByPage";
	}
	

	/**
	 * To enter view
	 * @author 谭文广
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/entryView")
	public String entryView(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map){
		map.put("data",this.sysUserService.findById(formMap.getFormMap()));
		return "user/sys_user_view";
	}
	
	/**
	 * 验证用户帐号是否存在
	 * @param formMap
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = "/verificationAccount", method = RequestMethod.POST, produces = { "application/json;charset=UTF-8" })
	public  @ResponseBody Map<String,Object> verificationAccount(FormMap formMap) throws IOException {
		Map<String,Object> paramMap = new HashMap<String,Object>();
		paramMap.put("account",formMap.getFormMap().get("account"));
		List<Map<String, Object>> list = this.sysUserService.findAll(paramMap);
		if(list != null && list.size() > 0){
			if(formMap.getFormMap().get("user_id") != null){
				String user_id_f = formMap.getFormMap().get("user_id").toString();
				String user_id_r = list.get(0).get("user_id").toString();
				if(user_id_f.equals(user_id_r)){
					paramMap.put("result","N");//未重复
				}else{
					paramMap.put("result","Y");//重复
				}
			}else{
				paramMap.put("result","Y");//重复
			}
		}else{
			paramMap.put("result","N");//未重复
		}
		return paramMap;
	}
	
	
	/**
	 * 重置密码
	 * @param formMap
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = "/modifyPwd", method = RequestMethod.POST, produces = { "application/json;charset=UTF-8" })
	public  @ResponseBody Map<String,Object> modifyPwd(FormMap formMap) throws IOException {
		Map<String,Object> paramMap = new HashMap<String,Object>();
		if(StringUtils.isNotNull(formMap.getFormMap().get("user_id")) 
				&& StringUtils.isNotNull(formMap.getFormMap().get("password"))
				&& StringUtils.isNotNull(formMap.getFormMap().get("confirm_password"))){
			if(formMap.getFormMap().get("password").toString().equals(formMap.getFormMap().get("confirm_password").toString())){
				if(formMap.getFormMap().get("password").toString().trim().length() > 5){
					try {
						this.setPassword(formMap);
						this.sysUserService.modify(formMap.getFormMap());
						paramMap.put("result","Y");
					} catch (Exception e) {
						paramMap.put("result","error");//参数不全，系统异常
					}
				}else{
					paramMap.put("result","N");//密码长度不能少于6位
				}
			}else{
				paramMap.put("result","N");//信息有误
			}
		}else{
			paramMap.put("result","N");//信息有误
		}
		return paramMap;
	}
	
}	