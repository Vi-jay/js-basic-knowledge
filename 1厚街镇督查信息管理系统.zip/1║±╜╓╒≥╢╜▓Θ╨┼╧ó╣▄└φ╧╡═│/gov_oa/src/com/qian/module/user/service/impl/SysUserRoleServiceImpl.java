package com.qian.module.user.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.gzdec.framework.page.Pagination;
import com.gzdec.framework.util.UniqueIDGenerator;

import com.qian.module.user.dao.SysUserRoleDao;
import com.qian.module.user.service.inter.SysUserRoleService;

/**
 * @author 谭文广
 */
@Service("sysUserRoleServiceImpl")
public class SysUserRoleServiceImpl implements SysUserRoleService{
	
	@Autowired
	private SysUserRoleDao sysUserRoleDao;
	
	public Map<String,Object> find(Map<String,Object> valueMap) {
		return this.sysUserRoleDao.find(valueMap);
	}
	
	public Map<String,Object> findById(Map<String,Object> valueMap) {
		String id = "";
		if(valueMap.get("user_role_id") != null){
			id = valueMap.get("user_role_id").toString().trim();
		}
		if("".equals(id)){
			return new HashMap<String,Object>();
		}
		return this.sysUserRoleDao.find(valueMap);
	}

	public List<Map<String,Object>> findAll(Map<String,Object> valueMap) {
		return this.sysUserRoleDao.findAll(valueMap);
	}

	public List<Map<String,Object>> findByPage(Map<String,Object> valueMap,Pagination pagination) {
		return this.sysUserRoleDao.findByPage(valueMap, pagination);
	}
	
	public int create(Map<String,Object> valueMap) throws Exception {
		String id = "";
		if(valueMap.get("user_role_id") != null){
			id = valueMap.get("user_role_id").toString().trim();
		}
		if("".equals(id)){
			valueMap.put("user_role_id", UniqueIDGenerator.getUUID());
		}		
		if(valueMap.get("create_time") == null || (valueMap.get("create_time") != null && valueMap.get("create_time").toString().trim() == "")){
			valueMap.put("create_time",new Date());
		}
		return this.sysUserRoleDao.create(valueMap);
	}	

	public int modify(Map<String,Object> valueMap) throws Exception {
		if(valueMap.get("user_role_id") != null){
			if(valueMap.get("update_time") == null || (valueMap.get("update_time") != null && valueMap.get("update_time").toString().trim() == "")){
				valueMap.put("update_time",new Date());
			}
			return this.sysUserRoleDao.modify(valueMap);
		}else{
			return -1;
		}
	}

	public int remove(Map<String,Object> valueMap) {
		String[] idArr = new String[1];
		if(valueMap.get("ids") != null && valueMap.get("ids").toString().length() > 0){
			if (valueMap.get("ids") instanceof String) {
				idArr[0] = valueMap.get("ids").toString();
			}else{
		    		idArr = (String[]) valueMap.get("ids");
			}
			List<Map<String,Object>> list = new ArrayList<Map<String,Object>>();
			String id = "";
			Map<String,Object> toMap = new HashMap<String,Object>();
			for(int i = 0; i < idArr.length; i++){
				id = idArr[i];
				toMap = new HashMap<String,Object>();
				toMap.put("user_role_id", id);
				list.add(toMap);
			}
			return this.sysUserRoleDao.remove(list);
		}else{
			return -1;
		}
	}

	@Override
	public int removeUserRole(Map<String, Object> valueMap) {
		return this.sysUserRoleDao.removeUserRole(valueMap);
	}
	
}