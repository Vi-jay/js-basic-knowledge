package com.qian.module.user.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gzdec.framework.page.Pagination;
import com.gzdec.framework.util.UniqueIDGenerator;

import com.qian.module.menu.dao.SysMenuoptDao;
import com.qian.module.menu.util.MenuUtils;
import com.qian.module.user.dao.SysUserDao;
import com.qian.module.user.service.inter.MbSysUserDeptService;
import com.qian.module.user.service.inter.SysUserRoleService;
import com.qian.module.user.service.inter.SysUserService;
import com.qian.util.StringUtils;

/**
 * @author 谭文广
 */
@Service("sysUserServiceImpl")
public class SysUserServiceImpl implements SysUserService{
	
	@Autowired
	private SysUserDao sysUserDao;
	@Autowired
	private SysMenuoptDao sysMenuoptDao;
	@Autowired
	private SysUserRoleService sysUserRoleService;
	@Autowired
	private MbSysUserDeptService mbSysUserDeptService;
	
	
	public Map<String,Object> find(Map<String,Object> valueMap) {
		return this.sysUserDao.find(valueMap);
	}
	
	public Map<String,Object> findById(Map<String,Object> valueMap) {
		String id = "";
		if(valueMap.get("user_id") != null){
			id = valueMap.get("user_id").toString().trim();
		}
		if("".equals(id)){
			return new HashMap<String,Object>();
		}
		Map<String,Object> result = this.sysUserDao.find(valueMap);
		return result;
	}

	public List<Map<String,Object>> findAll(Map<String,Object> valueMap) {
		return this.sysUserDao.findAll(valueMap);
	}

	public List<Map<String,Object>> findByPage(Map<String,Object> valueMap,Pagination pagination) {
		return this.sysUserDao.findByPage(valueMap, pagination);
	}
	
	public int create(Map<String,Object> valueMap) throws Exception {
		String id = "";
		if(valueMap.get("user_id") != null){
			id = valueMap.get("user_id").toString().trim();
		}
		if("".equals(id)){
			valueMap.put("user_id", UniqueIDGenerator.getUUID());
		}		
		if(valueMap.get("create_time") == null || (valueMap.get("create_time") != null && valueMap.get("create_time").toString().trim() == "")){
			valueMap.put("create_time",new Date());
		}
		int count = this.sysUserDao.create(valueMap);
		this.updateDeptRole(valueMap);
		return count;
	}	

	/**
	 * 用户与角色关联信息处理
	 * @author 谭文广
	 * @param formMap
	 * @return
	 * @throws Exception 
	 */
	private boolean updateDeptRole(Map<String,Object> userMap) throws Exception{
		if(userMap.get("user_id") == null || userMap.get("role_id") == null){
			return false;
		}
		//数据解析
		Set<String> deptSet = new HashSet<String>();
		Set<String> roleSet = new HashSet<String>();
		String[] deptRoleIds = (String[]) userMap.get("role_id");//所有数值
		String[] deptAndRole = null;
		for(String deptRole : deptRoleIds){
			if("temp_role_id".equals(deptRole)){
			}else{
				deptAndRole = deptRole.split(",");
				deptSet.add(deptAndRole[0]);
				roleSet.add(deptAndRole[1]);
			}
		}
		Map<String,Object> paramMap = new HashMap<String,Object>();
		//1、删除用户与角色关联信息
		paramMap.put("user_id", userMap.get("user_id"));
		this.sysUserRoleService.removeUserRole(paramMap);
		this.mbSysUserDeptService.removeUserDept(paramMap);
		//2、添加用户与角色关联信息
		for(String role : roleSet){
			paramMap = new HashMap<String,Object>();
			paramMap.put("user_id", userMap.get("user_id"));
			paramMap.put("role_id", role);
			sysUserRoleService.create(paramMap);
		}
		//3、添加用户与部门关联信息
		for(String dept : deptSet){
			paramMap = new HashMap<String,Object>();
			paramMap.put("user_id", userMap.get("user_id"));
			paramMap.put("dept_id", dept);
			this.mbSysUserDeptService.create(paramMap);
		}
		return true;
	}
	
	
	public int modify(Map<String,Object> valueMap) throws Exception {
		if(valueMap.get("user_id") != null){
			int count = this.sysUserDao.modify(valueMap);
			this.updateDeptRole(valueMap);
			return count;
		}else{
			return -1;
		}
	}

	public int remove(Map<String,Object> valueMap) {
		String[] idArr = new String[1];
		if(valueMap.get("ids") != null && valueMap.get("ids").toString().length() > 0){
			if (valueMap.get("ids") instanceof String) {
				idArr[0] = valueMap.get("ids").toString();
			}else{
		    		idArr = (String[]) valueMap.get("ids");
			}
			List<Map<String,Object>> list = new ArrayList<Map<String,Object>>();
			String id = "";
			Map<String,Object> toMap = new HashMap<String,Object>();
			for(int i = 0; i < idArr.length; i++){
				id = idArr[i];
				toMap = new HashMap<String,Object>();
				toMap.put("user_id", id);
				list.add(toMap);
			}
			return this.sysUserDao.remove(list);
		}else{
			return -1;
		}
	}

	@Override
	public List<Map<String, Object>> findUserOtherInfo(Map<String, Object> valueMap,Pagination pagination) {
		return this.sysUserDao.queryUserOtherInfo(valueMap,pagination);
	}

	@Override
	public List<Map<String, Object>> findUserMenu(Map<String, Object> valueMap) {
		List<Map<String, Object>> list = null;
		if(StringUtils.isNotNull(valueMap) && StringUtils.isNotNull(valueMap.get("user_type")) && 
				"B".equals(valueMap.get("user_type").toString())){
//			valueMap.put("is_menu_opt","Y");
			list = this.sysMenuoptDao.findAll(valueMap);//读取全部菜单
		}else{
			list = this.sysUserDao.queryUserMenu(valueMap);//读取用户所属菜单
		}
		return MenuUtils.getMenuToTree(list);
	}

	@Override
	public int removeUserByChannelId(Map<String, Object> valueMap)
			throws Exception {
		return this.sysUserDao.removeUserByChannelId(valueMap);
	}
	
	
	
	
}