package com.qian.module.appversion.service.inter;

import java.util.List;
import java.util.Map;
import com.gzdec.framework.page.Pagination;

/**
 * @author twg
 */
public interface AppVersionUpService {

	/**
	 * Query List
	 * @author 冯颖伟
	 * @param valueMap
	 * @return
	 */
	public List<Map<String,Object>> findAll(Map<String,Object> valueMap);
	
	/**
	 * Query Page List
	 * @author 冯颖伟
	 * @param valueMap
	 * @return
	 */
	public List<Map<String,Object>> findByPage(Map<String,Object> valueMap,Pagination pagination);
	
	/**
	 * Get A Record
	 * @author 冯颖伟
	 * @param valueMap
	 * @return
	 */
	public Map<String,Object> find(Map<String,Object> valueMap);
	
	/**
	 * Get A Record
	 * @author 冯颖伟
	 * @param valueMap
	 * @return
	 */
	public Map<String,Object> findById(Map<String,Object> valueMap);
	
	/**
	 * Creating
	 * @author 冯颖伟
	 * @param valueMap
	 * @return
	 */
	public int create(Map<String,Object> valueMap) throws Exception ;	
	
	/**
	 * Modifing
	 * @author 冯颖伟
	 * @param valueMap
	 * @return
	 */
	public int modify(Map<String,Object> valueMap) throws Exception ;	
	
	/**
	 * Deleting
	 * @author 冯颖伟
	 * @param valueMap
	 * @return
	 */
	public int remove(Map<String,Object> valueMap) throws Exception ;
	






}