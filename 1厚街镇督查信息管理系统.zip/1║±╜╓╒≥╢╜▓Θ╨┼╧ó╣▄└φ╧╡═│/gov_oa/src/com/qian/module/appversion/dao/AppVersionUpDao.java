package com.qian.module.appversion.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Service;
import com.gzdec.framework.dao.SqlMapBaseDao;
import com.gzdec.framework.page.Pagination;

/**
 * @author twg
 */
@Service
public class AppVersionUpDao extends SqlMapBaseDao{
	/**
	 * Query List
	 * @author 冯颖伟
	 * @param valueMap
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<Map<String,Object>> findAll(Map<String,Object> to){
		return this.queryForList("app.appVersionUp.query", to);
	}
	
	/**
	 * Query Page List
	 * @author 冯颖伟
	 * @param valueMap
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<Map<String,Object>> findByPage(Map<String,Object> to,Pagination pagination){
		return this.queryForList("app.appVersionUp.query", to, pagination);
	}
	
	/**
	 * Get A Record
	 * @author 冯颖伟
	 * @param to
	 * @return
	 */
	@SuppressWarnings("unchecked")	 
	public Map<String,Object> find(Map<String,Object> to){
		return (Map<String,Object>)this.queryForObject("app.appVersionUp.query", to);
	}
	
	/**
	 * Creating
	 * @author 冯颖伟
	 * @param to
	 * @return
	 * @throws SQLException 
	 */
	public int create(Map<String,Object> to) throws Exception{
		this.insert("app.appVersionUp.create", to);
		return 1;
	}
	
	/**
	 * Modify
	 * @author 冯颖伟
	 * @param to
	 * @return
	 * @throws Exception 
	 */
	public int modify(Map<String,Object> to) throws Exception{
		return this.update("app.appVersionUp.modify", to);
	}
	
	/**
	 * Deleting
	 * @author 冯颖伟
	 * @param to
	 * @return
	 * @throws Exception 
	 */
	public int remove(Map<String,Object> to) throws Exception{
		List<Map<String,Object>> list = new ArrayList<Map<String,Object>>();
		list.add(to);
		return this.remove(list);
	}
	
	/**
	 * Deleting List
	 * @author 冯颖伟
	 * @param list
	 * @return
	 */
	public int remove(List<Map<String,Object>> list){
		int count = 0;
		if(null == list || list.size() <= 0){
		    return count;
		}
		for(int i = 0; i < list.size(); i++){
		    Map<String,Object> to = list.get(i);
		    count += this.delete("app.appVersionUp.remove", to);
		}
		return count;
	}






}