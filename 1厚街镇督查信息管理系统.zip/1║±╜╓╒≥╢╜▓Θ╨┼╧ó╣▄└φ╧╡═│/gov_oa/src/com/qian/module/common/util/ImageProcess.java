package com.qian.module.common.util;

import java.io.InputStream;

/**
 * 为了提高用户体验，对大图压缩采用多线程方式
 * @author Administrator
 */
public class ImageProcess implements Runnable{
	
	InputStream is;
	int imageWidth = 0;
	String imagePath = "";
	
	
	/**
	 * 参数初始化
	 * @param is
	 * @param imageWidth
	 * @param imagePath
	 */
	public ImageProcess(InputStream is,int imageWidth,String imagePath){
		this.is = is;
		this.imageWidth = imageWidth;
		this.imagePath = imagePath;
	}
	
	@Override
	public void run() {
		ImageZip.zipImageFile(is,imageWidth,imagePath);
	}

}
