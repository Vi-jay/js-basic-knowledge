package com.qian.module.common.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.gzdec.framework.dao.SqlMapBaseDao;

@Service
public class LocationDao extends SqlMapBaseDao{

	/**
	 * 查找所有省份
	 * @param to
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<Map<String, String>> queryProvince(){
		return this.queryForList("common.location.queryProvince");
	}
	
	/**
	 * 根据省份名称查找 城市名称
	 * @param to
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<Map<String, String>> queryCity(String to){
		return this.queryForList("common.location.queryCity", to);
	}
	
	/**
	 * 根据城市名称查找区县名称
	 * @param to
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<Map<String, String>> queryArea(String to){
		return this.queryForList("common.location.queryArea", to);
	}
	
	/**
	 * 根据ID查询附件信息
	 * @author 谭文广
	 * @param to
	 * @return
	 */
	@SuppressWarnings("unchecked")	 
	public Map<String,Object> queryAttr(Map<String,Object> to){
		return (Map<String,Object>)this.queryForObject("common.location.queryAttr", to);
	}
	
	/**
	 * 删除附件
	 * @author 谭文广
	 * @param to
	 * @return
	 * @throws Exception 
	 */
	public int removeAttr(Map<String,Object> to) throws Exception{
		return this.update("common.location.removeAttr", to);
	}
	
}
