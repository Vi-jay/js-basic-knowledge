package com.qian.module.common.service.inter;

import java.util.List;
import java.util.Map;

public interface LocationService {
	
	public List<Map<String, String>> getProvince();
	
	public List<Map<String, String>> getCitiesByProvinceName(String provinceName);

	public List<Map<String, String>> getAreasByCityName(String cityName);
	
	/**
	 * 删除附件
	 * @author 谭文广
	 * @param valueMap
	 * @return
	 */
	public int removeAttr(Map<String,Object> valueMap) throws Exception;	
}
