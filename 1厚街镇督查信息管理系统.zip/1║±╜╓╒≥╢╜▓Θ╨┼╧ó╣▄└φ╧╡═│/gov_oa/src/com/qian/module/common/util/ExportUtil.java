package com.qian.module.common.util;

import java.io.FileInputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;

import net.sf.jxls.transformer.XLSTransformer;

import org.apache.poi.ss.usermodel.Workbook;

import com.qian.util.StringUtils;

public class ExportUtil {
	public static boolean exportOrder(Map<String,Object> order,String srcPath,OutputStream os) throws Exception{
		if(order==null||!StringUtils.isNotNull(srcPath)||os==null){
			return false;
		}else{
			Map<String,Object> beans = new HashMap<String,Object>();
			beans.put("order", order);
			XLSTransformer transformer = new XLSTransformer();
			//获得模板的输入流
			FileInputStream in = new FileInputStream(srcPath);
			//将beans通过模板输入流写到workbook中
			Workbook workbook = transformer.transformXLS(in, beans);
			//将workbook中的内容用输出流写出去
			workbook.write(os);
			os.close();
			return true;
		}
	}
}
