package com.qian.module.common.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qian.module.common.dao.JudgeDataDao;
import com.qian.module.common.service.inter.JudgeDataService;
import com.qian.util.StringUtils;

/**
 * @author 谭文广
 */
@Service("judgeDataServiceImpl")
public class JudgeDataServiceImpl implements JudgeDataService{
	
	@Autowired
	private JudgeDataDao judgeDataDao;

	@Override
	public List<Map<String, Object>> fieldRepeat(Map<String, Object> valueMap) {
		if(StringUtils.isNotNull(valueMap.get("id")) && StringUtils.isNotNull(valueMap.get("table"))
				&& StringUtils.isNotNull(valueMap.get("con"))){
			Map<String,Object> paramMap = new HashMap<String,Object>();
			paramMap.put("id_name", valueMap.get("id"));
			paramMap.put("table_name", valueMap.get("table"));
			String[] con = valueMap.get("con").toString().replaceAll(" ","").split(",");
			StringBuffer conditions = new StringBuffer();
			String[] temp = null; 
			for(int i = 0;i<con.length;i++){
				temp = con[i].split("=");
				conditions.append(temp[0]+"='"+temp[1]+"'");
				if(i < con.length-1){
					conditions.append(" and ");
				}
			}
			paramMap.put("conditions",conditions.toString());
			return judgeDataDao.fieldRepeat(paramMap);
		}else{
			return null;//参数有误
		}
	}
	
}