package com.qian.module.common.service.impl;

import java.io.File;
import java.util.List;
import java.util.Map;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qian.module.common.dao.LocationDao;
import com.qian.module.common.service.inter.LocationService;
import com.qian.util.StringUtils;
import com.qian.util.UploadFile;

@Service("locationService")
public class LocationServiceImpl implements LocationService{

	@Autowired
	private LocationDao locationDao;
	
	@Override
	public List<Map<String, String>> getProvince() {
		List<Map<String, String>> province = locationDao.queryProvince();
		return province;
	}

	@Override
	public List<Map<String, String>> getCitiesByProvinceName(String provinceName) {
		
		return locationDao.queryCity(provinceName);
	}

	@Override
	public List<Map<String, String>> getAreasByCityName(String cityName) {
		
		return locationDao.queryArea(cityName);
	}

	@Override
	public int removeAttr(Map<String, Object> valueMap) throws Exception {
		Map<String,Object> attrInfo = this.locationDao.queryAttr(valueMap);
		if(attrInfo != null && StringUtils.isNotNull(attrInfo.get(valueMap.get("attr_url")))){
			File attrFile = new File(UploadFile.config.getProperty("attachment.path").trim()+attrInfo.get(valueMap.get("attr_url")).toString());
		    // 路径为文件且不为空则进行删除  
		    if (attrFile.isFile() && attrFile.exists()) {  
		    	attrFile.delete();
		    }
		}
		return this.locationDao.removeAttr(valueMap);
	}

	
}
