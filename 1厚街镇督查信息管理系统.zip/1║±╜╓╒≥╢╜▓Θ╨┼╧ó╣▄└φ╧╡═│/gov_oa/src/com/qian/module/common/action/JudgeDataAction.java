package com.qian.module.common.action;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.qian.module.common.service.inter.JudgeDataService;
import com.qian.util.FormMap;

/**
 * 通用验证（例如：验证字段是否重复）
 * @author twg
 */
@Controller
@RequestMapping(value = "/pc/judge")
public class JudgeDataAction extends BaseAction{
	
	@Autowired
	private JudgeDataService judgeDataService;
	
	/**
	 * 判断某字段是否重复（通用）
	 * @param formMap 
	 * key=id（主键ID）
	 * key=table（表名）
	 * key=con（条件，格式：a=1,b=2,c=3.....）
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = "/fieldRepeat", method = RequestMethod.POST, produces = { "application/json;charset=UTF-8" })
	public  @ResponseBody Map<String, Object> fieldRepeat(FormMap formMap) throws IOException {
		List<Map<String, Object>> list = judgeDataService.fieldRepeat(formMap.getFormMap());
		if(list != null && list.size() > 0){
			this.paramMap.put("result","Y");//重复
			this.paramMap.put("id",list.get(0).get(formMap.getFormMap().get("id").toString()));//重复
		}else if(list == null){
			this.paramMap.put("result","F");//参数不全
			this.paramMap.put("id","nodata");//重复
		}else{
			this.paramMap.put("result","N");//未重复
		}
		return this.paramMap;
	}

	
	
}
