package com.qian.module.common.action;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.gzdec.framework.util.UniqueIDGenerator;
import com.qian.module.common.service.inter.LocationService;
import com.qian.util.FormMap;
import com.qian.util.StringUtils;
import com.qian.util.UploadFile;

/**
 * 地区位置请求
 * @author Chonghui
 *
 */
@Controller
@RequestMapping(value = "/pc/common")
public class LocationAction extends BaseAction{
	
	@Resource
	private LocationService locationService;
	
	
	@RequestMapping(value = "/getProvinces", method = RequestMethod.POST, produces = { "application/json;charset=UTF-8" })
	public  @ResponseBody List<Map<String, String>> getProvinces() throws IOException {
		List<Map<String, String>> provinceList = locationService.getProvince();
		return provinceList;
	}
	@RequestMapping(value = "/getCities", method = RequestMethod.POST, produces = { "application/json;charset=UTF-8" })
	public @ResponseBody List<Map<String, String>> getCitys(String province_name) {
		List<Map<String, String>> cityList = locationService.getCitiesByProvinceName(province_name); 
		return cityList;
	}
	@RequestMapping(value = "/getAreas", method = RequestMethod.POST, produces = { "application/json;charset=UTF-8" })
	public @ResponseBody List<Map<String, String>> getAreas(String city_name) {
		List<Map<String, String>> areaList = locationService.getAreasByCityName(city_name);
		return areaList;
	}
	
	/**
	 * 异步上传附件（通用）
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/uploadAttr", method = RequestMethod.POST, produces = { "application/json;charset=UTF-8" })
	public @ResponseBody Map<String,Object> uploadAttr(HttpServletRequest request,FormMap formMap) throws IOException {
		formMap.getFormMap().put("id",UniqueIDGenerator.getUUID());
		UploadFile.uploadAttachment(request, formMap);
		return formMap.getFormMap();
	}
	
	/**
	 * 删除附件
	 * @author twg
	 * @param formMap
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/removeAttr", method = RequestMethod.POST, produces = { "application/json;charset=UTF-8" })
	public @ResponseBody Map<String,Object> removeAttr(HttpServletRequest request,FormMap formMap){
		if(StringUtils.isNotNull(formMap.getFormMap().get("type")) && 
				StringUtils.isNotNull(formMap.getFormMap().get("id"))){
			if("A".equals(formMap.getFormMap().get("type").toString())){//用户执行明细表：wt_task_execution
				formMap.getFormMap().put("table_name", "wt_task_execution");
				formMap.getFormMap().put("attr_name", "attachment_name");
				formMap.getFormMap().put("attr_url", "attachment");
				formMap.getFormMap().put("id_name", "task_execution_id");
			}else if("B".equals(formMap.getFormMap().get("type").toString())){//任务主表表：wt_worktask
				formMap.getFormMap().put("table_name", "wt_worktask");
				formMap.getFormMap().put("attr_name", "attachment_name");
				formMap.getFormMap().put("attr_url", "attachment");
				formMap.getFormMap().put("id_name", "worktask_id");
			}else if("C".equals(formMap.getFormMap().get("type").toString())){//部门/主办单位任务表：wt_dept_task
				formMap.getFormMap().put("table_name", "wt_dept_task");
				formMap.getFormMap().put("attr_name", "dt_schedule_attname");
				formMap.getFormMap().put("attr_url", "dt_schedule_atturl");
				formMap.getFormMap().put("id_name", "dt_dept_task_id");
			}
			try {
				this.locationService.removeAttr(formMap.getFormMap());
			} catch (Exception e) {
			}
			this.paramMap.put("result","Y");
			return this.paramMap;
		}
		this.paramMap.put("result","N");
		return this.paramMap;
	}
}
