package com.qian.module.common.dao;

import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Service;
import com.gzdec.framework.dao.SqlMapBaseDao;

/**
 * @author 谭文广
 */
@Service
public class JudgeDataDao extends SqlMapBaseDao{
	
	/**
	 * 判断某字段是否重复（通用）
	 * @author 谭文广
	 * @param valueMap
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<Map<String,Object>> fieldRepeat(Map<String,Object> to){
		return this.queryForList("judge.data.fieldRepeat", to);
	}
	

}