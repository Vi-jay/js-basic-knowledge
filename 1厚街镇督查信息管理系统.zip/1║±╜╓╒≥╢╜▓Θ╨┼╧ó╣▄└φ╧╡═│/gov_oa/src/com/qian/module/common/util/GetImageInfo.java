package com.qian.module.common.util;

import java.util.HashMap;
import java.util.Map;

import com.gzdec.framework.util.UniqueIDGenerator;
import com.qian.util.DateTimeUtils;


public class GetImageInfo{   
	
	private static final String seeding = "seeding";//苗木路径
    
	/**
	 * 
	 * @param oldFile
	 * @param smallIcon
	 */
    public static void seedingPath(Map<String,Object> valueMap) {
    	if(valueMap == null){valueMap = new HashMap<String,Object>();}
    	String uuid = UniqueIDGenerator.getUUID();//图片文件名前缀
    	String curDate = DateTimeUtils.getCurFormatDate();//图片路径（时间部分）
    	String path = "/photo/"+seeding+"/"+curDate+"/";
    	Integer pic_count = Integer.parseInt(valueMap.get("pic_count").toString());//上传图片数量
    	/**
    	 * 第一张图片
    	 */
    	String pic_first_name = uuid+"_"+curDate+"_01.jpg";
    	valueMap.put("pic_first_name",pic_first_name);
    	valueMap.put("pic_first",path+pic_first_name);
    	/**
		 * 第二张图片
		 */
    	if(pic_count > 1){
    		String pic_second_name = uuid+"_"+curDate+"_02.jpg";
    		valueMap.put("pic_second_name",pic_second_name);
    		valueMap.put("pic_second",path+pic_second_name);
    	}
    	/**
		 * 第三张图片
		 */
    	if(pic_count > 2){
    		String pic_third_name = uuid+"_"+curDate+"_03.jpg";
    		valueMap.put("pic_third_name",pic_third_name);
    		valueMap.put("pic_third",path+pic_third_name);
    	}
    	
    }
    
    
    
    public static void main(String args[]){ 
    	
    }
    
} 