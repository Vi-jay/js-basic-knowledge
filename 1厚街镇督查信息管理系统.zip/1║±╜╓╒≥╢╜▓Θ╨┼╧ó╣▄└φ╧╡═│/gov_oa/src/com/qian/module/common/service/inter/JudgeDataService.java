package com.qian.module.common.service.inter;

import java.util.List;
import java.util.Map;

/**
 * @author 谭文广
 */
public interface JudgeDataService {
	
	/**
	 * 判断某字段是否重复（通用）
	 * @author 谭文广
	 * @param valueMap
	 * @return
	 */
	public List<Map<String,Object>> fieldRepeat(Map<String,Object> valueMap);

}