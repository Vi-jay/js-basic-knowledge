package com.qian.module.common.service.impl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.qian.module.common.service.inter.InfoPushService;
import com.qian.util.StringUtils;

@Service("infoPushService")
public class InfoPushServiceImpl implements InfoPushService{
	
	/**
	 * 流程审核信息推送（申请人，审核人，抄送人）
	 * @author 谭文广
	 * @param valueMap
	 * @return
	 */
	@Override
	public boolean processPush(Map<String, Object> map,boolean sqUser,boolean spUser,boolean csUser) {
		if(StringUtils.isNotNull(map.get("process_apply_id"))){
			Map<String,Object> paramMap = new HashMap<String,Object>();//查询参数
			paramMap.put("process_apply_id", map.get("process_apply_id"));
//			Map<String,Object> processInfo = this.worProcessApplyService.findById(paramMap);
//			if(sqUser){//推送给申请人
//				paramMap.clear();
//				paramMap.put("user_id",processInfo.get("user_id"));//
//				List<Map<String, Object>> userList = sysUserDao.findAll(paramMap);
//				String title = "您的申请已审核";
//				String description = "【"+processInfo.get("apply_num")+"】查看详情";
//				JSONObject paramJson = new JSONObject();//
//				paramJson.put("process_apply_id", map.get("process_apply_id"));
//				paramJson.put("activity", "ViewApplyActivity");
//				BaiduPushTool.push(userList, title, description, paramJson);
//			}
//			if(spUser && StringUtils.isNotNull(map.get("current_opt_user"))){//推送给审核人
//				paramMap.clear();
//				paramMap.put("user_id",map.get("current_opt_user"));//
//				List<Map<String, Object>> userList = sysUserDao.findAll(paramMap);
//				String title = "单据审核";
//				String description = "";
//				if("A".equals(processInfo.get("important_level"))){
//					description = "[普通]"+processInfo.get("defini_name")+"（"+processInfo.get("real_name")+"）";
//				}else if("B".equals(processInfo.get("important_level"))){
//					description = "[重要]"+processInfo.get("defini_name")+"（"+processInfo.get("real_name")+"）";
//				}else{
//					description = "[紧急]"+processInfo.get("defini_name")+"（"+processInfo.get("real_name")+"）";
//				}
//				JSONObject paramJson = new JSONObject();//
//				paramJson.put("process_apply_id", map.get("process_apply_id"));
//				paramJson.put("activity", "ViewApprovalActivity");
//				BaiduPushTool.push(userList, title, description, paramJson);
//			}
//			if(csUser){//推送给抄送人
//				List<Map<String, Object>> userList = this.worCopyToService.findPushCopyUser(map);
//				String title = "审核抄送";
//				String description = "";
//				if("A".equals(processInfo.get("important_level"))){
//					description = "【普通】查看详情";
//				}else if("B".equals(processInfo.get("important_level"))){
//					description = "【重要】查看详情";
//				}else{
//					description = "【紧急】查看详情";
//				}
//				JSONObject paramJson = new JSONObject();//推送参数
//				paramJson.put("process_apply_id", map.get("process_apply_id"));
//				paramJson.put("activity", "ViewApplyActivity");
//				BaiduPushTool.push(userList, title, description, paramJson);
//			}
			return true;
		}
		return false;
	}

	@Override
	public boolean noticePush(Map<String, Object> map){
//		if(StringUtils.isNotNull(map.get("notice_id"))){
//			List<Map<String, Object>> userList = tzNoticeUserService.findPushUserByNoticeId(map);
//			String title = "公告通知";
//			String description = map.get("title").toString();
//			if("B".equals(map.get("no_level").toString())){
//				description = "【重大公告】"+description;
//			}
//			JSONObject paramJson = new JSONObject();//
//			paramJson.put("notice_id", map.get("notice_id"));
//			paramJson.put("activity", "NoViewNoticeActivity");
//			BaiduPushTool.push(userList, title, description, paramJson);
//			return true;
//		}
		return false;
	}
	
}
