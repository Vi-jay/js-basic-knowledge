package com.qian.module.common.service.inter;

import java.util.Map;

/**
 * 消息推送公共类
 * @author twg
 */
public interface InfoPushService {
	
	/**
	 * 流程审核信息推送（申请人，审核人，抄送人）
	 * @author twg
	 * @param valueMap
	 * @return
	 */
	public boolean processPush(Map<String,Object> paramMap,boolean sqUser,boolean spUser,boolean csUser);
	/**
	 * 推送公告通知
	 * @author twg
	 * @param valueMap
	 * @return
	 */
	public boolean noticePush(Map<String, Object> map);

}