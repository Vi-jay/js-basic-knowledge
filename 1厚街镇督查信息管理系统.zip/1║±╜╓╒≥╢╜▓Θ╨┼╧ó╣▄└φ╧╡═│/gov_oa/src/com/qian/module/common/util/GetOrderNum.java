package com.qian.module.common.util;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** 获取订单号 */
public class GetOrderNum {
	
	private static final String ORDER_SIGN = "";
	
	/**
	 * 获取采购单号
	 * @return
	 */
	public static String getPurOrderNum(){
		return ORDER_SIGN+"P"+GetOrderNum.getTime();
	}
	
	/**
	 * 获取入库单号
	 * @return
	 */
	public static String getStoOrderNum(){
		return ORDER_SIGN+"I"+GetOrderNum.getTime();
	}
	
	/**
	 * 获取销售单号
	 * @return
	 */
	public static String getSelOrderNum(){
		return ORDER_SIGN+"S"+GetOrderNum.getTime();
	}
	
	/**
	 * 获取出库单号
	 * @return
	 */
	public static String getOutOrderNum(){
		return ORDER_SIGN+"O"+GetOrderNum.getTime();
	}
	
	/**
	 * 获取调整单号
	 * @return
	 */
	public static String getAdjustOrderNum(){
		return ORDER_SIGN+"A"+GetOrderNum.getTime();
	}
	
	/**
	 * 获取苗木编号
	 * @return
	 */
	public static String getSeedlingNum(){
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmssSSS",Locale.CHINA);
		return "MC"+sdf.format(new Date());
	}
	
	/**
	 * 获取格式化时间
	 * @return
	 */
	private static String getTime(){
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss",Locale.CHINA);
		return sdf.format(new Date());
	}
	
	public static void main(String[] args) {
		System.out.println(GetOrderNum.getAdjustOrderNum());
		System.out.println(GetOrderNum.getOutOrderNum());
		System.out.println(GetOrderNum.getPurOrderNum());
		System.out.println(GetOrderNum.getSelOrderNum());
		System.out.println(GetOrderNum.getStoOrderNum());
		System.out.println(GetOrderNum.getSeedlingNum());
	}
	
}