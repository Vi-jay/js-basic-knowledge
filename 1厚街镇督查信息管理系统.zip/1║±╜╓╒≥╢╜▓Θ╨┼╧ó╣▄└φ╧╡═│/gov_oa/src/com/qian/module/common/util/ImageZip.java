package com.qian.module.common.util;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;  
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import javax.imageio.ImageIO;
import com.sun.image.codec.jpeg.JPEGCodec;
import com.sun.image.codec.jpeg.JPEGEncodeParam;
import com.sun.image.codec.jpeg.JPEGImageEncoder;

public class ImageZip{   
	
    /**  
     * 描述：压缩图片（只压缩图片文件大小）
     * @param oldFile  要进行压缩的文件全路径
     * @param smallIcon   压缩后的图片文件全路径
     * @return  返回压缩后的文件的全路径 
     */  
    public static String zipImageFile(String oldFile,String smallIcon) {   
        if (oldFile == null) {   
            return null;
        }   
        String newImage = null;
        try {
            /** 对服务器上的临时文件进行处理 */  
            Image srcFile = ImageIO.read(new File(oldFile));
            int w = srcFile.getWidth(null);
            int h = srcFile.getHeight(null);
            
            /** 宽,高设定 */  
            BufferedImage tag = new BufferedImage(w, h,BufferedImage.TYPE_INT_RGB);   
            tag.getGraphics().drawImage(srcFile, 0, 0, w, h,Color.white, null);   
            
            /** 压缩后的文件名 */  
            newImage = smallIcon;
  
            /** 压缩之后临时存放位置 */  
            FileOutputStream out = new FileOutputStream(newImage);   
  
            JPEGImageEncoder encoder = JPEGCodec.createJPEGEncoder(out);   
            JPEGEncodeParam jep = JPEGCodec.getDefaultJPEGEncodeParam(tag);   
            /** 压缩质量 */  
            jep.setQuality(0.8f, true);//设置压缩质量  
            encoder.encode(tag, jep);   
            out.close();   
  
        } catch (FileNotFoundException e) {   
            e.printStackTrace();   
        } catch (IOException e) {   
            e.printStackTrace();   
        }   
        return newImage;   
    }
    
    /**
     * 描述：压缩图片（只压缩图片文件大小）
     * @param oldFile
     * @return
     */
	public static InputStream zipImageFile(InputStream oldFile,String file) {   
        if (oldFile == null) {   
            return null;
        }   
        InputStream is = null;
        try {
            /** 对服务器上的临时文件进行处理 */  
            Image srcFile = ImageIO.read(oldFile);
            int w = srcFile.getWidth(null);
            int h = srcFile.getHeight(null);
            
            /** 宽,高设定 */  
            BufferedImage tag = new BufferedImage(w, h,BufferedImage.TYPE_INT_RGB);   
            tag.getGraphics().drawImage(srcFile, 0, 0, w, h,Color.white, null);   
  
            FileOutputStream out = new FileOutputStream(file);
  
            JPEGImageEncoder encoder = JPEGCodec.createJPEGEncoder(out);
            JPEGEncodeParam jep = JPEGCodec.getDefaultJPEGEncodeParam(tag); 
            /** 压缩质量 */  
            jep.setQuality(0.9f, true);//设置压缩质量  
            encoder.encode(tag, jep);   
            out.close();   
  
        } catch (FileNotFoundException e) {   
            e.printStackTrace();   
        } catch (IOException e) {   
            e.printStackTrace();   
        }   
        return is;
    }
    
    /**  
     * 描述：压缩图片文件大小以及图片尺寸
     * @param oldFile  要进行压缩的文件全路径
     * @param smallIcon   压缩后的图片文件全路径
     * @param proportion   压缩比例（必须是小于1的正浮点数）
     * @return  返回压缩后的文件的全路径 
     */  
    public static String zipImageFile(String oldFile,String smallIcon,double proportion) {   
        if (oldFile == null) {   
            return null;
        }   
        String newImage = null;
        try {
            /** 对服务器上的临时文件进行处理 */  
            Image srcFile = ImageIO.read(new File(oldFile));
            int w = srcFile.getWidth(null);
            int h = srcFile.getHeight(null);
            
            if(0 < proportion && proportion < 1){
            	w = (int)(proportion * w);
                h = (int)(proportion * h);
            }
            
            /** 宽,高设定 */  
            BufferedImage tag = new BufferedImage(w, h,BufferedImage.TYPE_INT_RGB);   
            tag.getGraphics().drawImage(srcFile, 0, 0, w, h, Color.white,null);
            
            /** 压缩后的文件名 */
            newImage = smallIcon;
  
            /** 压缩之后临时存放位置 */  
            FileOutputStream out = new FileOutputStream(newImage);   
  
            JPEGImageEncoder encoder = JPEGCodec.createJPEGEncoder(out);   
            JPEGEncodeParam jep = JPEGCodec.getDefaultJPEGEncodeParam(tag);   
            /** 压缩质量 */  
            jep.setQuality(0.8f, true);//设置压缩质量  
            encoder.encode(tag, jep);   
            out.close();   
  
        } catch (FileNotFoundException e) {   
            e.printStackTrace();   
        } catch (IOException e) {   
            e.printStackTrace();   
        }   
        return newImage;   
    }
    
    
    /**
     * 描述：压缩图片文件大小以及图片尺寸
     * @param oldFile
     * @param proportion
     * @return
     */
    public static InputStream zipImageFile(InputStream oldFile,double proportion) {   
        if (oldFile == null) {   
            return null;
        }   
        InputStream is = null;
        try {
            /** 对服务器上的临时文件进行处理 */  
            Image srcFile = ImageIO.read(oldFile);
            int w = srcFile.getWidth(null);
            int h = srcFile.getHeight(null);
            
            if(0 < proportion && proportion < 1){
            	w = (int)(proportion * w);
                h = (int)(proportion * h);
            }
            
            /** 宽,高设定 */  
            BufferedImage tag = new BufferedImage(w, h,BufferedImage.TYPE_INT_RGB);   
            tag.getGraphics().drawImage(srcFile, 0, 0, w, h,Color.white, null);
            
            ByteArrayOutputStream bs = new ByteArrayOutputStream();
  
            JPEGImageEncoder encoder = JPEGCodec.createJPEGEncoder(bs);   
            JPEGEncodeParam jep = JPEGCodec.getDefaultJPEGEncodeParam(tag);   
            /** 压缩质量 */  
            jep.setQuality(0.4f, true);//设置压缩质量  
            encoder.encode(tag, jep);   
            
            is = new ByteArrayInputStream(bs.toByteArray());
            
            bs.close();   
  
        } catch (FileNotFoundException e) {   
            e.printStackTrace();   
        } catch (IOException e) {   
            e.printStackTrace();   
        }   
        return is;   
    }
    
    
    /**
     * 描述：压缩图片文件大小以及图片尺寸（根据网站规格压缩）
     * @param oldFile
     * @param picType
     * @return
     */
	public static InputStream zipImageFile(InputStream oldFile,int maxWidth,String file) {   
        if (oldFile == null) {   
            return null;
        }   
        try {
            /** 对服务器上的临时文件进行处理 */  
            Image srcFile = ImageIO.read(oldFile);
            int w = srcFile.getWidth(null);
            int h = srcFile.getHeight(null);
            
            if(w > maxWidth){//压缩
            	double d = (maxWidth/(double)w);
            	h = (int)(d*h);
            	w = maxWidth;
            }
            
            /** 宽,高设定 */  
            BufferedImage tag = new BufferedImage(w, h,BufferedImage.TYPE_INT_RGB);   
            Graphics g = tag.getGraphics();
            g.drawImage(srcFile, 0, 0, w, h,Color.white, null);
            srcFile.flush();
            
            FileOutputStream out = new FileOutputStream(file);
  
            JPEGImageEncoder encoder = JPEGCodec.createJPEGEncoder(out);   
            JPEGEncodeParam jep = JPEGCodec.getDefaultJPEGEncodeParam(tag);   
            /** 压缩质量 */  
            jep.setQuality(0.8f, true);//设置压缩质量  
            encoder.encode(tag, jep);   
            out.close();
  
        } catch (FileNotFoundException e) {   
            e.printStackTrace();   
        } catch (IOException e) {   
            e.printStackTrace();   
        }   
        return null;
    }
	
	
	/**
     * 描述：压缩图片文件大小以及图片尺寸（根据网站规格压缩）
     * @param oldFile
     * @param picType
     * @return
     */
	public static InputStream zipImageFileForApp(InputStream oldFile,int maxWidth,String file) {   
        if (oldFile == null) {   
            return null;
        }   
        try {
            /** 对服务器上的临时文件进行处理 */  
            Image srcFile = ImageIO.read(oldFile);
            int w = srcFile.getWidth(null);
            int h = srcFile.getHeight(null);
            
            if(w > maxWidth){//压缩
            	double d = (maxWidth/(double)w);
            	h = (int)(d*h);
            	w = maxWidth;
            }
            
            /** 宽,高设定 */  
            BufferedImage tag = new BufferedImage(w, h,BufferedImage.TYPE_INT_RGB); 
            Graphics g = tag.getGraphics();
            g.drawImage(srcFile, 0, 0, w, h,Color.white, null);
            srcFile.flush();
            FileOutputStream out = new FileOutputStream(file);
  
            JPEGImageEncoder encoder = JPEGCodec.createJPEGEncoder(out);   
            JPEGEncodeParam jep = JPEGCodec.getDefaultJPEGEncodeParam(tag);   
            /** 压缩质量 */  
            jep.setQuality(0.9f, true);//设置压缩质量  
            encoder.encode(tag, jep);   
            out.close();
  
        } catch (FileNotFoundException e) {   
            e.printStackTrace();   
        } catch (IOException e) {   
            e.printStackTrace();   
        }   
        return null;
    }
    
    /**  
     * 描述：按照宽高直接压缩
     * @param oldFile  要进行压缩的文件全路径
     * @param smallIcon   压缩后的图片文件全路径
     * @param width   压缩后的图片宽度
     * @param height   压缩后的图片高度
     * @return  返回压缩后的文件的全路径 
     */  
    public static String zipImageFile(String oldFile,String smallIcon,int width, int height) {   
        if (oldFile == null) {   
            return null;
        }   
        String newImage = null;
        try {
            /** 对服务器上的临时文件进行处理 */  
            Image srcFile = ImageIO.read(new File(oldFile));
            int w = srcFile.getWidth(null);
            int h = srcFile.getHeight(null);
            
            if(30 <= width && width < w){
            	w = width;
            }
            if(30 <= height && height < h){
            	h = height;
            }
            
            
            /** 宽,高设定 */  
            BufferedImage tag = new BufferedImage(w, h,BufferedImage.TYPE_INT_RGB);   
            tag.getGraphics().drawImage(srcFile, 0, 0, w, h,Color.white, null);
            
            /** 压缩后的文件名 */
            newImage = smallIcon;
  
            /** 压缩之后临时存放位置 */  
            FileOutputStream out = new FileOutputStream(newImage);   
  
            JPEGImageEncoder encoder = JPEGCodec.createJPEGEncoder(out);   
            JPEGEncodeParam jep = JPEGCodec.getDefaultJPEGEncodeParam(tag);   
            /** 压缩质量 */  
            jep.setQuality(0.8f, true);//设置压缩质量  
            encoder.encode(tag, jep);   
            out.close();   
  
        } catch (FileNotFoundException e) {   
            e.printStackTrace();   
        } catch (IOException e) {   
            e.printStackTrace();   
        }   
        return newImage;   
    }
    
    
    /**  
     * 描述：按照宽高直接压缩
     * @param oldFile  要进行压缩的文件全路径
     * @param smallIcon   压缩后的图片文件全路径
     * @param width   压缩后的图片宽度
     * @param height   压缩后的图片高度
     * @return  返回压缩后的文件的全路径 
     */  
	public static InputStream zipImageFile(InputStream fileInputStream,int width, int height,String file) {   
        if (fileInputStream == null) {   
            return null;
        }
        InputStream is = null;
        try {
            /** 对服务器上的临时文件进行处理 */  
            Image srcFile = ImageIO.read(fileInputStream);
            int w = srcFile.getWidth(null);
            int h = srcFile.getHeight(null);
            
            w=width;
            h=height;
            
            /** 宽,高设定 */  
            BufferedImage tag = new BufferedImage(w, h,BufferedImage.TYPE_INT_RGB);   
            tag.getGraphics().drawImage(srcFile, 0, 0, w, h,Color.white, null);
            
  
            /** 压缩之后临时存放位置 */  
            FileOutputStream out = new FileOutputStream(file);
  
            JPEGImageEncoder encoder = JPEGCodec.createJPEGEncoder(out);   
            JPEGEncodeParam jep = JPEGCodec.getDefaultJPEGEncodeParam(tag);
            /** 压缩质量 */  
            jep.setQuality(0.8f, true);//设置压缩质量  
            encoder.encode(tag, jep);
            out.close();
  
        } catch (FileNotFoundException e) {   
            e.printStackTrace();   
        } catch (IOException e) {   
            e.printStackTrace();   
        }   
        return is;
    }
    
    
    /**  
     * 保存文件到服务器临时路径  
     *   
     * @param fileName  
     * @param is  
     * @return 文件全路径  
     */  
    public static String writeFile(String fileName, InputStream is) {   
        if (fileName == null || fileName.trim().length() == 0) {   
            return null;   
        }   
        try {   
            /** 首先保存到临时文件 */  
            FileOutputStream fos = new FileOutputStream(fileName); 
            byte[] readBytes = new byte[512];// 缓冲大小   
            int readed = 0;   
            while ((readed = is.read(readBytes)) > 0) {   
                fos.write(readBytes, 0, readed);   
            }   
            fos.close();   
            is.close();   
        } catch (FileNotFoundException e) {   
            e.printStackTrace();   
        } catch (IOException e) {   
            e.printStackTrace();   
        }   
        return fileName;   
    }
    
  
    public static void main(String args[]){ 
    	long start = System.currentTimeMillis();
//        ImageZip.zipImageFile("E:/333.jpg","E:/3.jpg");//只压缩图片文件大小
//        ImageZip.zipImageFile("F:/aaa.png","F:/bbb.png",0.5);//比例压缩（同时压缩大小和尺寸）
//        ImageZip.zipImageFile("F:/test.jpg","F:/888.jpg",800,800);//直接压缩（同时压缩大小和尺寸）
    	ImageZip.zipImageFile("F:/testpic/002.jpg","F:/testpic/00222.jpg",0.8);//比例压缩（同时压缩大小和尺寸）
        long end = System.currentTimeMillis();
        System.out.println(end-start);
    }
} 