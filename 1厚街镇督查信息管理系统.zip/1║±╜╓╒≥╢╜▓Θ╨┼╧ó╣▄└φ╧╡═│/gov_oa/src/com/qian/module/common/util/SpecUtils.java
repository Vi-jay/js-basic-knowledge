package com.qian.module.common.util;

import java.util.List;
import java.util.Map;

public class SpecUtils {
	public static void concatSpec(List<Map<String, Object>> listMap){
		if(listMap!=null&&listMap.size()>0){
			for(int i=0;i<listMap.size();i++){
				Map<String, Object> map = listMap.get(i);
				String str="";
				Object chest_type = map.get("chest_type");
				Object chest_fr = map.get("chest_fr");
				Object chest_to = map.get("chest_to");
				Object height_fr = map.get("height_fr");
				Object height_to = map.get("height_to");
				Object crown_fr = map.get("crown_fr");
				Object crown_to = map.get("crown_to");
				Object stem_fr = map.get("stem_fr");
				Object stem_to = map.get("stem_to");
				Object pole_fr = map.get("pole_fr");
				Object pole_to = map.get("pole_to");
				Object branch_fr = map.get("branch_fr");
				Object branch_to = map.get("branch_to");
				Object size_spec = map.get("size_spec");
				if(chest_type!=null){
					if("A".equals(chest_type)){
						str+="胸径：";
					}
					if("B".equals(chest_type)){
						str+="头径：";
					}
					if("C".equals(chest_type)){
						str+="米径：";
					}
					if("D".equals(chest_type)){
						str+="地径：";
					}
				}
				if(chest_fr!=null&&(Double)chest_fr!=0){
					str+=chest_fr;
				}
				if(chest_to!=null&&(Double)chest_to!=0){
					str+="- "+chest_to;
				}
				
				if(height_fr!=null&&(Double)height_fr!=0){
					str+=" 高度："+height_fr;
				}
				if(height_to!=null&&(Double)height_to!=0){
					str+="- "+height_to;
				}
				if(crown_fr!=null&&(Double)crown_fr!=0){
					str+=" 冠幅："+crown_fr;
				}
				if(crown_to!=null&&(Double)crown_to!=0){
					str+="- "+crown_to;
				}
				if(stem_fr!=null&&(Double)stem_fr!=0){
					str+=" 茎粗："+stem_fr;
				}
				if(stem_to!=null&&(Double)stem_to!=0){
					str+="- "+stem_to;
				}
				if(pole_fr!=null&&(Double)pole_fr!=0){
					str+=" 杆高："+pole_fr;
				}
				if(pole_to!=null&&(Double)pole_to!=0){
					str+="- "+pole_to;
				}
				if(branch_fr!=null&&(Integer)branch_fr!=0){
					str+=" 枝或丛："+branch_fr;
				}
				if(branch_to!=null&&(Integer)branch_to!=0){
					str+="- "+branch_to;
				}
				if(size_spec!=null){
					str+=" 尺码规格："+size_spec;
				}
				listMap.get(i).put("concatSpec", str);
			}
		}
	}
}
