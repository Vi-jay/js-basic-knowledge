package com.qian.module.common.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Service;
import com.gzdec.framework.dao.SqlMapBaseDao;
import com.gzdec.framework.page.Pagination;
import com.qian.util.ListUtils;

@Service
public class CommonDao extends SqlMapBaseDao{
	
	/**select*/
	public final String QUERY = "query";
	/**create*/
	public final String CREATE = "create";
	/**update*/
	public final String MODIFY = "modify";
	/**delete*/
	public final String DELETE = "remove";
	
	/**
	 * Query List
	 * @author twg
	 * @param valueMap
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<Map<String,Object>> findAll(String namespaceId,Map<String,Object> to){
		return this.queryForList(namespaceId, to);
	}
	
	/**
	 * Query Page List
	 * @author twg
	 * @param valueMap
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<Map<String,Object>> findByPage(String namespaceId,Map<String,Object> to,Pagination p){
		return this.queryForList(namespaceId, to, p);
	}
	
	/**
	 * Get A Record
	 * @author twg
	 * @param to
	 * @return
	 */
	@SuppressWarnings("unchecked")	 
	public Map<String,Object> find(String namespaceId,Map<String,Object> to){
		return (Map<String,Object>)this.queryForObject(namespaceId, to);
	}
	
	/**
	 * Create A Record
	 * @author twg
	 * @param to
	 * @return
	 */
	public String create(String namespaceId,Map<String,Object> to) throws Exception{
		Object obj = this.insert(namespaceId, to);
		if(obj != null){
			return (String) obj;
		}else{
			return null;
		}
	}
	
	/**
	 * Update A Record
	 * @author twg
	 * @param to
	 * @return
	 */
	public int modify(String namespaceId,Map<String,Object> to) throws Exception{
		return this.update(namespaceId, to);
	}
	
	/**
	 * Delete A Record
	 * @author twg
	 * @param to
	 * @return
	 */
	public int remove(String namespaceId,Map<String,Object> to) throws Exception{
		List<Map<String,Object>> list = new ArrayList<Map<String,Object>>();
		list.add(to);
		return this.remove(namespaceId,list);
	}
	
	/**
	 * Batch Delete Record
	 * @author twg
	 * @param list
	 * @return
	 */
	public int remove(String namespaceId,List<Map<String,Object>> list){
		int count = 0;
		if(ListUtils.isNotNull(list)){
			for(Map<String,Object> map : list){
				count += this.delete(namespaceId, map);
			}
		}
		return count;
	}
}