package com.qian.module.common.util;

import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;

import com.gzdec.framework.page.Pagination;

public class SearchKey {
	/**
	 * 
	 * @param request request
	 * @param map 条件map（formMap.getFormMap()）
	 * @param sessName session中的AttributeName
	 * @param keyName 页面属性值
	 * @param p 页面分页参数
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static HashMap<String,Object> getSearchKey(HttpServletRequest request,HashMap<String,Object> map,String sessName,String keyName,Pagination p){
		if(map.get(keyName) != null){
			request.getSession().setAttribute(sessName, map);
			request.getSession().setAttribute(sessName+"_p", p);
		}
		map = (HashMap<String, Object>) request.getSession().getAttribute(sessName);
		Pagination pTemp = (Pagination) request.getSession().getAttribute(sessName+"_p");
		if(map == null){
			map = new HashMap<String,Object>();
		}
		if(pTemp == null){
			pTemp = new Pagination();
		}else{
			p.setPageCount(pTemp.getPageCount());
			p.setCurrent(pTemp.getCurrent());
		}
		return map;
	}
	
	
}
