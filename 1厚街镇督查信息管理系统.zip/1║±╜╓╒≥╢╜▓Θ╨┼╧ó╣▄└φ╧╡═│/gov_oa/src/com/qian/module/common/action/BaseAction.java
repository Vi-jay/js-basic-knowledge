package com.qian.module.common.action;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.qian.module.worktask.service.inter.WtProjectTypeService;
import com.qian.util.StringUtils;


public class BaseAction {
	
	public static final Logger log = Logger.getLogger(BaseAction.class);
	public Map<String,Object> paramMap = new HashMap<String,Object>();
	public Map<String,Object> resultMap = new HashMap<String,Object>();
	public Map<String, Object> getParamMap() {
		return paramMap;
	}
	public void setParamMap(Map<String, Object> paramMap) {
		this.paramMap = paramMap;
	}
	public void setParamMapVal(Map<String, Object> formMap,String keys) {
		Map<String,Object> tempMap = new HashMap<String,Object>();
		String[] key = keys.split(",");
		for(String keyStr : key){
			tempMap.put(keyStr, formMap.get(keyStr));
		}
		this.paramMap.clear();
		this.paramMap.putAll(tempMap);
	}

	
	@Autowired
	private WtProjectTypeService wtProjectTypeService;
	public List<Map<String,Object>> getProjectTypeList(String fileType){
		Map<String,Object> tempMap = new HashMap<String,Object>();
		tempMap.put("wpt_is_use","Y");
		tempMap.put("wpt_file_type",fileType);
		return this.wtProjectTypeService.findAll(tempMap);
	}
	

	/**
	 * 判断请求来源于哪个平台
	 * @param request
	 * @param pcurl
	 * @param mobileurl
	 * @return
	 */
	public String platformType(HttpServletRequest request,String pcurl,String mobileurl){
		if(StringUtils.isNotNull(request.getSession().getAttribute("platformType"))){
			return mobileurl;
		}else{
			return pcurl;
		}
	}
	
}
