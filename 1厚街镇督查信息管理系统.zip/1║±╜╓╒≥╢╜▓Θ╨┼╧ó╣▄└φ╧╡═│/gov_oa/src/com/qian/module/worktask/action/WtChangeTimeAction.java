package com.qian.module.worktask.action;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.gzdec.framework.page.Pagination;

import com.qian.module.common.action.BaseAction;
import com.qian.module.worktask.service.inter.WtChangeTimeService;
import com.qian.module.worktask.service.inter.WtDeptTaskService;
import com.qian.util.FormMap;
import com.qian.util.SessionUtil;
import com.qian.util.StringUtils;

/**
 * 描述：申请改期
 * @author twg
 */
@Controller
@Scope("prototype")
@RequestMapping(value = "/pc/changetime")
public class WtChangeTimeAction extends BaseAction{
	
	@Autowired
	private WtChangeTimeService wtChangeTimeService;
	@Autowired
	private WtDeptTaskService wtDeptTaskService;
	
	/**
	 * To enter list
	 * @author twg
	 * @param formMap
	 * @param pagination
	 * @return
	 */
	@RequestMapping(value = "/listByPage")
	public String listByPage(HttpServletRequest request,ModelMap map,FormMap formMap,Pagination p){
		List<Map<String, Object>> list =  this.wtChangeTimeService.findByPage(formMap.getFormMap(), p);
		map.put("list",list);
		map.put("formMap",formMap.getFormMap());
		map.put("pagination",p);
		return "worktask/wt_change_time_list";
	}
	
	/**
	 * To enter edit
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/entryEdit")
	public String entryEdit(HttpServletRequest request,FormMap formMap,ModelMap map){
//		map.put("data",this.wtChangeTimeService.findById(formMap.getFormMap()));
		map.put("data", this.wtDeptTaskService.findById(formMap.getFormMap()));
		this.paramMap.put("dt_dept_task_id", formMap.getFormMap().get("dt_dept_task_id"));
		List<Map<String, Object>> ctList = this.wtChangeTimeService.findAll(this.paramMap);//历史申请记录
		map.put("ctList", ctList);
		return "worktask/wt_change_time_edit";
	}
	
	/**
	 * To enter edit
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/entryAduit")
	public String entryAduit(HttpServletRequest request,FormMap formMap,ModelMap map){
		this.paramMap.put("ct_change_time_id", formMap.getFormMap().get("ct_change_time_id"));
		Map<String, Object> ctMap = this.wtChangeTimeService.findById(this.paramMap);
		if(ctMap != null && ctMap.size() > 0){
			formMap.getFormMap().put("dt_dept_task_id", ctMap.get("dt_dept_task_id"));
			map.put("data", this.wtDeptTaskService.findById(formMap.getFormMap()));
			map.put("ctMap",ctMap);
		}else{
			request.getSession().setAttribute("ct_session_mark", "CLOSE");
		}
		return "worktask/wt_change_time_aduit";
	}
	
	/**
	 * Creating
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/create")
	public String create(HttpServletRequest request,FormMap formMap,ModelMap map) throws Exception{
		formMap.getFormMap().put("ct_apply_user",SessionUtil.getUserName(request));
		formMap.getFormMap().put("ct_apply_time",new Date());
		this.wtChangeTimeService.create(formMap.getFormMap());
		request.getSession().setAttribute("ct_session_mark", "CLOSE");
		return "redirect:/pc/changetime/entryEdit";
	}
	
	/**
	 * Modifing
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/modify")
	public String modify(HttpServletRequest request,FormMap formMap,ModelMap map) throws Exception{
		this.wtChangeTimeService.modify(formMap.getFormMap());
		return "redirect:/pc/changetime/listByPage";
	}
	
	/**
	 * Deleting
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/delete")
	public String delete(HttpServletRequest request,FormMap formMap,ModelMap map) throws Exception{
		this.wtChangeTimeService.remove(formMap.getFormMap());
		return "redirect:/pc/changetime/listByPage";
	}
	

	/**
	 * To enter view
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/entryView")
	public String entryView(HttpServletRequest request,FormMap formMap,ModelMap map){
		map.put("data",this.wtChangeTimeService.findById(formMap.getFormMap()));
		return "worktask/wt_change_time_view";
	}

	
	/**
	 * 
	 * @param formMap
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/removeById", method = RequestMethod.POST, produces = { "application/json;charset=UTF-8" })
	public  @ResponseBody Map<String,Object> removeById(FormMap formMap) throws Exception {
		Map<String,Object> paramMap = new HashMap<String,Object>();
		this.wtChangeTimeService.remove(formMap.getFormMap());
		return paramMap;
	}
	
	
	/**
	 * 改期审核
	 * @param formMap
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/modifyCtStatus", method = RequestMethod.POST, produces = { "application/json;charset=UTF-8" })
	public  @ResponseBody Map<String,Object> modifyCtStatus(HttpServletRequest request,FormMap formMap) throws Exception {
		if(StringUtils.isNotNull(formMap.getFormMap().get("ct_change_time_id"))
				&& StringUtils.isNotNull(formMap.getFormMap().get("ct_status"))){
			this.paramMap.put("ct_change_time_id", formMap.getFormMap().get("ct_change_time_id"));
			Map<String,Object> ctMap = this.wtChangeTimeService.findById(this.paramMap);
			if("O".equals(ctMap.get("ct_status").toString())){
				formMap.getFormMap().put("ct_handle_user", SessionUtil.getUserName(request));
				formMap.getFormMap().put("ct_handle_time", new Date());
				int count = this.wtChangeTimeService.modify(formMap.getFormMap());
				if(count > 0){
					resultMap.put("result","Y");
					if("Y".equals(formMap.getFormMap().get("ct_status").toString())){//更新部门任务时间
						this.paramMap.clear();
						this.paramMap.put("dt_dept_task_id",ctMap.get("dt_dept_task_id"));
						this.paramMap.put("dt_change_stime",ctMap.get("ct_start_time"));
						this.paramMap.put("dt_change_etime",ctMap.get("ct_end_time"));
						this.wtDeptTaskService.modify(this.paramMap);
					}
				}
			}
		}
		return this.resultMap;
	}
	
	
}	