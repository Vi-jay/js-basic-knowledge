package com.qian.module.worktask.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.gzdec.framework.page.Pagination;
import com.gzdec.framework.util.UniqueIDGenerator;

import com.qian.module.worktask.dao.WtDeptTaskDao;
import com.qian.module.worktask.dao.WtTaskArrangeDao;
import com.qian.module.worktask.service.inter.WtTaskArrangeService;
import com.qian.util.StringUtils;

/**
 * @author twg
 */
@Service("wtTaskArrangeServiceImpl")
public class WtTaskArrangeServiceImpl implements WtTaskArrangeService{
	
	@Autowired
	private WtTaskArrangeDao wtTaskArrangeDao;
	@Autowired
	private WtDeptTaskDao wtDeptTaskDao;
	
	public Map<String,Object> find(Map<String,Object> valueMap) {
		return this.wtTaskArrangeDao.find(valueMap);
	}
	
	public Map<String,Object> findById(Map<String,Object> valueMap) {
		String id = "";
		if(valueMap.get("task_arrange_id") != null){
			id = valueMap.get("task_arrange_id").toString().trim();
		}
		if("".equals(id)){
			return new HashMap<String,Object>();
		}
		return this.wtTaskArrangeDao.find(valueMap);
	}

	public List<Map<String,Object>> findAll(Map<String,Object> valueMap) {
		return this.wtTaskArrangeDao.findAll(valueMap);
	}

	public List<Map<String,Object>> findByPage(Map<String,Object> valueMap,Pagination pagination) {
		return this.wtTaskArrangeDao.findByPage(valueMap, pagination);
	}
	
	public int create(Map<String,Object> valueMap)  throws Exception{
		int count = 0;
		//任务安排表
		Map<String,Object> paramMap = new HashMap<String,Object>();
		String user_id = valueMap.get("user_ids").toString();//所有用户ID
		if(user_id.trim().length() == 32){//单个用户
			paramMap.put("task_arrange_id", UniqueIDGenerator.getUUID());
			paramMap.put("worktask_id", valueMap.get("worktask_id"));
			paramMap.put("user_id", user_id);
			paramMap.put("dept_id", valueMap.get("dept_id"));
			paramMap.put("arrange_explain", valueMap.get("arrange_explain"));
			paramMap.put("task_status","A");
			paramMap.put("arr_start_time", valueMap.get("arr_start_time"));
			paramMap.put("arr_end_time", valueMap.get("arr_end_time"));
			paramMap.put("attr_name", valueMap.get("attr_name"));
			paramMap.put("attr_url", valueMap.get("attr_url"));
			paramMap.put("create_time", new Date());
			count += this.wtTaskArrangeDao.create(paramMap);
		}else{//多个部门
			String[] user_ids = (String[]) valueMap.get("user_ids");
			String[] arrange_explain = (String[]) valueMap.get("arrange_explain");
			String[] arr_start_time = (String[]) valueMap.get("arr_start_time");
			String[] arr_end_time = (String[]) valueMap.get("arr_end_time");
			String[] attr_name = (String[]) valueMap.get("attr_name");
			String[] attr_url = (String[]) valueMap.get("attr_url");
			for(int i=0;i<user_ids.length;i++){
				paramMap = new HashMap<String,Object>();
				paramMap.put("task_arrange_id", UniqueIDGenerator.getUUID());
				paramMap.put("worktask_id", valueMap.get("worktask_id"));
				paramMap.put("user_id", user_ids[i]);
				paramMap.put("dept_id", valueMap.get("dept_id"));
				paramMap.put("arrange_explain", arrange_explain[i]);
				paramMap.put("task_status","A");
				paramMap.put("arr_start_time", arr_start_time[i]);
				paramMap.put("arr_end_time", arr_end_time[i]);
				paramMap.put("attr_name", attr_name[i]);
				paramMap.put("attr_url", attr_url[i]);
				paramMap.put("create_time", new Date());
				count += this.wtTaskArrangeDao.create(paramMap);
			}
		}
		if(count > 0){//设置已分配
			paramMap.clear();
			paramMap.put("dt_dept_task_id",valueMap.get("dt_dept_task_id"));
			paramMap.put("dt_status","Y");
			this.wtDeptTaskDao.modify(paramMap);
		}
		return count;
	}	

	public int modify(Map<String,Object> valueMap) throws Exception{
		if(valueMap.get("task_arrange_id") != null){
			return this.wtTaskArrangeDao.modify(valueMap);
		}else{
			return -1;
		}
	}

	public int remove(Map<String,Object> valueMap) throws Exception{
		String[] idArr = new String[1];
		if(valueMap.get("ids") != null && valueMap.get("ids").toString().length() > 0){
			if (valueMap.get("ids") instanceof String) {
				idArr[0] = valueMap.get("ids").toString();
			}else{
		    		idArr = (String[]) valueMap.get("ids");
			}
			List<Map<String,Object>> list = new ArrayList<Map<String,Object>>();
			String id = "";
			Map<String,Object> toMap = new HashMap<String,Object>();
			for(int i = 0; i < idArr.length; i++){
				id = idArr[i];
				toMap = new HashMap<String,Object>();
				toMap.put("task_arrange_id", id);
				list.add(toMap);
			}
			return this.wtTaskArrangeDao.remove(list);
		}else{
			return -1;
		}
	}

	@Override
	public List<Map<String, Object>> findMyWorkTask(Map<String, Object> valueMap,Pagination p) {
		
		return this.wtTaskArrangeDao.queryMyWorkTask(valueMap,p);
	}

	@Override
	public int modifyAlreadyRead(Map<String, Object> valueMap) throws Exception {
		if(StringUtils.isNotNull(valueMap.get("task_arrange_id")) 
				&& StringUtils.isNotNull(valueMap.get("arr_task_status")) 
				&& "A".equals(valueMap.get("arr_task_status").toString())){
			Map<String,Object> map = new HashMap<String,Object>();
			map.put("task_arrange_id",valueMap.get("task_arrange_id"));
			map.put("task_status","B");
			return this.modify(map);
		}else{
			return 0;
		}
	}

	@Override
	public int modifyToBath(Map<String, Object> valueMap) throws Exception {
		int count = 0;
		if(StringUtils.isNotNull(valueMap.get("worktask_id")) && StringUtils.isNotNull(valueMap.get("dept_id"))){
			Map<String,Object> tempMap = new HashMap<String,Object>();
			tempMap.put("worktask_id",valueMap.get("worktask_id"));
			tempMap.put("dept_id",valueMap.get("dept_id"));
			List<Map<String,Object>> list = this.wtTaskArrangeDao.findAll(tempMap);
			boolean flag = true;
			Map<String,Object> paramMap = new HashMap<String,Object>();
			String user_id = valueMap.get("user_ids").toString();//所有用户ID
			if(user_id.trim().length() == 32){//单个用户
				if(list != null && list.size() > 0){
					for(Map<String,Object> map : list){
						if(user_id.trim().equals(map.get("user_id").toString())){
							flag = false;
						}
					}
				}
				if(flag){
					paramMap.put("task_arrange_id", UniqueIDGenerator.getUUID());
					paramMap.put("worktask_id", valueMap.get("worktask_id"));
					paramMap.put("user_id", user_id);
					paramMap.put("dept_id", valueMap.get("dept_id"));
					paramMap.put("arrange_explain", valueMap.get("arrange_explain"));
					paramMap.put("task_status","A");
					paramMap.put("arr_start_time", valueMap.get("arr_start_time"));
					paramMap.put("arr_end_time", valueMap.get("arr_end_time"));
					paramMap.put("attr_name", valueMap.get("attr_name"));
					paramMap.put("attr_url", valueMap.get("attr_url"));
					paramMap.put("create_time", new Date());
					count += this.wtTaskArrangeDao.create(paramMap);
				}
			}else{
				String[] user_ids = (String[]) valueMap.get("user_ids");
				String[] arrange_explain = (String[]) valueMap.get("arrange_explain");
				String[] arr_start_time = (String[]) valueMap.get("arr_start_time");
				String[] arr_end_time = (String[]) valueMap.get("arr_end_time");
				String[] attr_name = (String[]) valueMap.get("attr_name");
				String[] attr_url = (String[]) valueMap.get("attr_url");
				for(int i=0;i<user_ids.length;i++){
					flag = true;
					if(list != null && list.size() > 0){//存在则不允许修改
						for(Map<String,Object> map : list){
							if(user_ids[i].trim().equals(map.get("user_id").toString())){
								flag = false;
							}
						}
					}
					if(flag){
						paramMap = new HashMap<String,Object>();
						paramMap.put("task_arrange_id", UniqueIDGenerator.getUUID());
						paramMap.put("worktask_id", valueMap.get("worktask_id"));
						paramMap.put("user_id", user_ids[i]);
						paramMap.put("dept_id", valueMap.get("dept_id"));
						paramMap.put("arrange_explain", arrange_explain[i]);
						paramMap.put("task_status","A");
						paramMap.put("arr_start_time", arr_start_time[i]);
						paramMap.put("arr_end_time", arr_end_time[i]);
						paramMap.put("attr_name", attr_name[i]);
						paramMap.put("attr_url", attr_url[i]);
						paramMap.put("create_time", new Date());
						count += this.wtTaskArrangeDao.create(paramMap);
					}
				}
			}
			
		}
		return count;
	}

	@Override
	public List<Map<String, Object>> statisticsByDeptAndType(Map<String, Object> valueMap) {
		return this.wtTaskArrangeDao.statisticsByDeptAndType(valueMap);
	}
	
	
	
	
	
	
	
	
	
}