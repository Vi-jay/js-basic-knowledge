package com.qian.module.worktask.action;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.gzdec.framework.page.Pagination;

import com.qian.module.worktask.service.inter.WtAssistunitService;
import com.qian.util.FormMap;

/**
 * 描述：协办单位任务管理
 * @author twg
 */
@Controller
@Scope("prototype")
@RequestMapping(value = "/pc/assistunit")
public class WtAssistunitAction{
	
	@Autowired
	private WtAssistunitService wtAssistunitService;
	
	/**
	 * To enter list
	 * @author twg
	 * @param formMap
	 * @param pagination
	 * @return
	 */
	@RequestMapping(value = "/listByPage")
	public String listByPage(HttpServletRequest request,ModelMap map,FormMap formMap,Pagination p){
		List<Map<String, Object>> list =  this.wtAssistunitService.findByPage(formMap.getFormMap(), p);
		map.put("list",list);
		map.put("formMap",formMap.getFormMap());
		map.put("pagination",p);
		return "worktask/wt_assistunit_list";
	}
	
	/**
	 * To enter edit
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/entryEdit")
	public String entryEdit(HttpServletRequest request,FormMap formMap,ModelMap map){
		map.put("data",this.wtAssistunitService.findById(formMap.getFormMap()));
		return "worktask/wt_assistunit_edit";
	}
	
	/**
	 * Creating
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/create")
	public String create(HttpServletRequest request,FormMap formMap,ModelMap map) throws Exception{
		this.wtAssistunitService.create(formMap.getFormMap());
		return "redirect:/pc/assistunit/listByPage";
	}
	
	/**
	 * Modifing
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/modify")
	public String modify(HttpServletRequest request,FormMap formMap,ModelMap map) throws Exception{
		this.wtAssistunitService.modify(formMap.getFormMap());
		return "redirect:/pc/assistunit/listByPage";
	}
	
	/**
	 * Deleting
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/delete")
	public String delete(HttpServletRequest request,FormMap formMap,ModelMap map) throws Exception{
		this.wtAssistunitService.remove(formMap.getFormMap());
		return "redirect:/pc/assistunit/listByPage";
	}
	

	/**
	 * To enter view
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/entryView")
	public String entryView(HttpServletRequest request,FormMap formMap,ModelMap map){
		map.put("data",this.wtAssistunitService.findById(formMap.getFormMap()));
		return "worktask/wt_assistunit_view";
	}

	
	/**
	 * 异步修改协办单位任务信息（在修改项目表时）
	 * @param formMap
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/modifyInfo", method = RequestMethod.POST, produces = { "application/json;charset=UTF-8" })
	public @ResponseBody Map<String,Object> modifyInfo(FormMap formMap) throws Exception {
		Map<String,Object> paramMap = new HashMap<String,Object>();
		this.wtAssistunitService.modify(formMap.getFormMap());
		return paramMap;
	}
	
}	