package com.qian.module.worktask.service.impl;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gzdec.framework.page.Pagination;
import com.gzdec.framework.util.UniqueIDGenerator;
import com.qian.module.system.action.WeiXinUtilAction;
import com.qian.module.user.service.inter.MbSysUserDeptService;
import com.qian.module.worktask.dao.WtNewsRemindDao;
import com.qian.module.worktask.service.inter.WtDeptTaskService;
import com.qian.module.worktask.service.inter.WtNewsRemindService;
import com.qian.module.worktask.util.NewsRemindUtil;
import com.qian.util.ListUtils;
import com.qian.util.StringUtils;

/**
 * @author twg
 */
@Service("wtNewsRemindServiceImpl")
public class WtNewsRemindServiceImpl implements WtNewsRemindService{
	
	@Autowired
	private WtNewsRemindDao wtNewsRemindDao;
	@Autowired
	private WtDeptTaskService wtDeptTaskService;
	@Autowired
	private MbSysUserDeptService mbSysUserDeptService;
	
	public Map<String,Object> find(Map<String,Object> valueMap) {
		return this.wtNewsRemindDao.find(valueMap);
	}
	
	public Map<String,Object> findById(Map<String,Object> valueMap) {
		String id = "";
		if(valueMap.get("wnr_news_remind_id") != null){
			id = valueMap.get("wnr_news_remind_id").toString().trim();
		}
		if("".equals(id)){
			return new HashMap<String,Object>();
		}
		return this.wtNewsRemindDao.find(valueMap);
	}

	public List<Map<String,Object>> findAll(Map<String,Object> valueMap) {
		return this.wtNewsRemindDao.findAll(valueMap);
	}

	public List<Map<String,Object>> findByPage(Map<String,Object> valueMap,Pagination pagination) {
		return this.wtNewsRemindDao.findByPage(valueMap, pagination);
	}
	
	public int create(Map<String,Object> valueMap)  throws Exception{
		String id = "";
		if(valueMap.get("wnr_news_remind_id") != null){
			id = valueMap.get("wnr_news_remind_id").toString().trim();
		}
		if("".equals(id)){
			valueMap.put("wnr_news_remind_id", UniqueIDGenerator.getUUID());
		}		
		if(valueMap.get("create_time") == null || (valueMap.get("create_time") != null && valueMap.get("create_time").toString().trim() == "")){
			valueMap.put("create_time",new Date());
		}
		return this.wtNewsRemindDao.create(valueMap);
	}	

	public int modify(Map<String,Object> valueMap) throws Exception{
		if(valueMap.get("wnr_news_remind_id") != null){
			if(valueMap.get("update_time") == null || (valueMap.get("update_time") != null && valueMap.get("update_time").toString().trim() == "")){
				valueMap.put("update_time",new Date());
			}
			return this.wtNewsRemindDao.modify(valueMap);
		}else{
			return -1;
		}
	}

	public int remove(Map<String,Object> valueMap) throws Exception{
		String[] idArr = new String[1];
		if(valueMap.get("ids") != null && valueMap.get("ids").toString().length() > 0){
			if (valueMap.get("ids") instanceof String) {
				idArr[0] = valueMap.get("ids").toString();
			}else{
		    		idArr = (String[]) valueMap.get("ids");
			}
			List<Map<String,Object>> list = new ArrayList<Map<String,Object>>();
			String id = "";
			Map<String,Object> toMap = new HashMap<String,Object>();
			for(int i = 0; i < idArr.length; i++){
				id = idArr[i];
				toMap = new HashMap<String,Object>();
				toMap.put("wnr_news_remind_id", id);
				list.add(toMap);
			}
			return this.wtNewsRemindDao.remove(list);
		}else{
			return -1;
		}
	}

	@Override
	public int updateReadStatusToBatch(Map<String, Object> valueMap)throws Exception {
		String[] idArr = new String[1];
		int count = 0;
		if(valueMap.get("ids") != null && valueMap.get("ids").toString().length() > 0){
			if (valueMap.get("ids") instanceof String) {
				idArr[0] = valueMap.get("ids").toString();
			}else{
		    	idArr = (String[]) valueMap.get("ids");
			}
			String id = "";
			Map<String,Object> toMap = new HashMap<String,Object>();
			for(int i = 0; i < idArr.length; i++){
				id = idArr[i];
				toMap = new HashMap<String,Object>();
				toMap.put("wnr_news_remind_id", id);
				toMap.put("wnr_is_read","Y");
				count += this.wtNewsRemindDao.modify(toMap);
			}
			return count;
		}else{
			return -1;
		}
	}

	@Override
	public List<Map<String, Object>> findDeptNewsRemind(Map<String, Object> valueMap, Pagination pagination) {
		return this.wtNewsRemindDao.queryDeptNewsRemind(valueMap, pagination);
	}

	@Override
	public boolean addMsg(Map<String, Object> valueMap) throws Exception {
		if(!StringUtils.isNotNull(valueMap.get("wnr_type"))){
			return false;
		}
		Map<String,Object> param = new HashMap<String,Object>();
//		wnr_news_remind_id varchar(32)提醒ID
		param.put("wnr_news_remind_id",UniqueIDGenerator.getUUID());
//		task_execution_id varchar(32)任务执行ID
		param.put("task_execution_id",valueMap.get("task_execution_id"));
//		dt_dept_task_id	varchar(32)部门任务ID
		param.put("dt_dept_task_id",valueMap.get("dt_dept_task_id"));
//		wnr_type int(1)0提醒，1督办，2退回，3不通过
		String wnr_type = valueMap.get("wnr_type").toString();
		param.put("wnr_type",wnr_type);
//		wnr_explain varchar(300)提醒说明
		if("2".equals(wnr_type)){
			param.put("wnr_explain","您所填写的任务阶段信息已被退回，请及时查阅并修改");
		}else if("3".equals(wnr_type)){
			param.put("wnr_explain","您所填写的任务阶段信息审核不通过，请及时查阅并修改");
		}
//		wnr_mode varchar(1)A电脑端，B手机端推送，C短信，D邮件，E电话
		param.put("wnr_mode",valueMap.get("wnr_mode"));
//		wnr_user_id varchar(32)提醒人
		param.put("wnr_user_id",valueMap.get("wnr_user_id"));
//		wnr_time datetime提醒时间
		param.put("wnr_time",new Date());
//		wnr_count int(3)提醒次数（待定）
		param.put("wnr_count","0");
//		wnr_is_read varchar(1)Y已读，N未读
		param.put("wnr_is_read","N");
		this.create(param);
		return true;
	}

	@Override
	public int removeByTeId(Map<String, Object> valueMap) throws Exception {
		return this.wtNewsRemindDao.removeByTeId(valueMap);
	}

	@Override
	public int createForAutomatic(Map<String, Object> valueMap)throws Exception {
		Map<String,Object> paramMap = new HashMap<String,Object>();
		NewsRemindUtil.getAllTime(paramMap);
        List<Map<String,Object>> dtList = this.wtDeptTaskService.findUnfinishedProject(paramMap);//查询部门未报送的事项
		if(ListUtils.isNotNull(dtList)){
			Calendar c = Calendar.getInstance();
			int day = c.get(Calendar.DATE);//当前日
			int whichweek = c.get(Calendar.DAY_OF_WEEK)-1;//当前星期
			Set<String> deptList = new TreeSet<String>();
			for(Map<String,Object> dtMap : dtList){//循环判断是否到了提醒或者督办日期
				//查询推送用户ID
//				System.out.println(dtMap);
				if("A".equals(dtMap.get("wt_opt_type").toString()) || "B".equals(dtMap.get("wt_opt_type").toString())
						&& day >= 20){
					deptList.add(dtMap.get("dept_id").toString());
				}else if("C".equals(dtMap.get("wt_opt_type").toString()) || "D".equals(dtMap.get("wt_opt_type").toString())
						&& (whichweek == 0 || whichweek >= 4)){
					deptList.add(dtMap.get("dept_id").toString());
				}
			}
			if(deptList.size() > 0){
				List<Map<String,Object>> userList = null;
				for(String dept_id : deptList){
					paramMap.clear();
					paramMap.put("dept_id",dept_id);
					userList = this.mbSysUserDeptService.findAllUserByDept(paramMap);
					if(ListUtils.isNotNull(userList)){
						WeiXinUtilAction.sendMsg(userList, null, 0, "<a href='https://open.weixin.qq.com/connect/oauth2/authorize?appid=wx1fb893be23aadfd6&redirect_uri=http%3A%2F%2Fwww.ppt123.top%3A8066%2Fpc%2Fsystem%2Fmlogin&response_type=code&scope=snsapi_base&state=STATE#wechat_redirect'>【温馨提示】贵单位有<1>件事项未报送进度，请尽快登录系统反馈</a>");
					}
				}
			}
			
		}
		return 0;
	}
	
}