package com.qian.module.worktask.action;

import java.util.Date;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import com.gzdec.framework.page.Pagination;

import com.qian.module.worktask.service.inter.WtEvaluateService;
import com.qian.util.FormMap;
import com.qian.util.SessionUtil;
import com.qian.util.StringUtils;

/**
 * 描述：任务评价管理
 * @author twg
 */
@Controller
@Scope("prototype")
@RequestMapping(value = "/pc/evaluate")
public class WtEvaluateAction{
	
	@Autowired
	private WtEvaluateService wtEvaluateService;
	
	/**
	 * To enter list
	 * @author twg
	 * @param formMap
	 * @param pagination
	 * @return
	 */
	@RequestMapping(value = "/listByPage")
	public String listByPage(HttpServletRequest request,HttpServletResponse response,ModelMap map,FormMap formMap,Pagination p){
		List<Map<String, Object>> list =  this.wtEvaluateService.findByPage(formMap.getFormMap(), p);
		map.put("list",list);
		map.put("formMap",formMap.getFormMap());
		map.put("pagination",p);
		return "worktask/wt_evaluate_list";
	}
	
	/**
	 * To enter edit
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/entryEdit")
	public String entryEdit(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map){
//		map.put("data",this.wtEvaluateService.findById(formMap.getFormMap()));
		map.put("formMap", formMap.getFormMap());
		return "worktask/wt_evaluate_edit";
	}
	
	/**
	 * Creating
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/create")
	public String create(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map) throws Exception{
//		this.wtEvaluateService.create(formMap.getFormMap());
//		return "redirect:/pc/evaluate/listByPage";
		if(StringUtils.isNotNull(formMap.getFormMap().get("task_execution_id"))
				&& StringUtils.isNotNull(formMap.getFormMap().get("we_content"))){
			formMap.getFormMap().put("we_user_id", SessionUtil.getLoginUserId(request));
			formMap.getFormMap().put("we_time", new Date());
			this.wtEvaluateService.create(formMap.getFormMap());
			request.getSession().setAttribute("we_session_mark","CLOSE");
		}
//		return "redirect:/pc/newsremind/listByPage";
		return "redirect:/pc/evaluate/entryEdit";
	}
	
	/**
	 * Modifing
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/modify")
	public String modify(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map) throws Exception{
		this.wtEvaluateService.modify(formMap.getFormMap());
		return "redirect:/pc/evaluate/listByPage";
	}
	
	/**
	 * Deleting
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/delete")
	public String delete(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map) throws Exception{
		this.wtEvaluateService.remove(formMap.getFormMap());
		return "redirect:/pc/evaluate/listByPage";
	}
	

	/**
	 * To enter view
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/entryView")
	public String entryView(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map){
		map.put("data",this.wtEvaluateService.findById(formMap.getFormMap()));
		return "worktask/wt_evaluate_view";
	}

}	