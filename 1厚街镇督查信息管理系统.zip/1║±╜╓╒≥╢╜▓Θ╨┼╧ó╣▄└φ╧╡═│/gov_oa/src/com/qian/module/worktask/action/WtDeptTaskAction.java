package com.qian.module.worktask.action;

import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import com.gzdec.framework.page.Pagination;
import com.qian.module.common.action.BaseAction;
import com.qian.module.worktask.service.inter.WtAssistunitService;
import com.qian.module.worktask.service.inter.WtDeptScheduleService;
import com.qian.module.worktask.service.inter.WtDeptTaskService;
import com.qian.module.worktask.service.inter.WtTaskArrangeService;
import com.qian.module.worktask.service.inter.WtTaskExecutionService;
import com.qian.module.worktask.service.inter.WtWorktaskService;
import com.qian.module.worktask.util.GetCycleListUtil;
import com.qian.module.worktask.util.NewsRemindUtil;
import com.qian.util.FormMap;
import com.qian.util.ListUtils;
import com.qian.util.SessionUtil;
import com.qian.util.StringUtils;
import com.qian.util.UploadFile;

/**
 * 描述：部门任务分配管理
 * @author twg
 */
@Controller
@Scope("prototype")
@RequestMapping(value = "/pc/depttask")
public class WtDeptTaskAction extends BaseAction{
	
	@Autowired
	private WtDeptTaskService wtDeptTaskService;
	@Autowired
	private WtDeptScheduleService wtDeptScheduleService;
	@Autowired
	private WtWorktaskService wtWorktaskService;
	@Autowired
	private WtTaskArrangeService wtTaskArrangeService;
	@Autowired
	private WtTaskExecutionService wtTaskExecutionService;
	@Autowired
	private WtAssistunitService wtAssistunitService;
	
	
	/**
	 * To enter list
	 * @author twg
	 * @param formMap
	 * @param pagination
	 * @return
	 */
	@RequestMapping(value = "/listByPage")
	public String listByPage(HttpServletRequest request,HttpServletResponse response,ModelMap map,FormMap formMap,Pagination p){
//		List<Map<String, Object>> list =  this.wtDeptTaskService.findByPage(formMap.getFormMap(), p);
		formMap.getFormMap().put("login_user_id",SessionUtil.getLoginUserId(request));
		if(StringUtils.isNotNull(formMap.getFormMap().get("dt_status"))){
		}else{
			formMap.getFormMap().put("dt_status","N");
		}
		formMap.getFormMap().put("task_status","A");
		formMap.getFormMap().put("is_delete","N");
		List<Map<String, Object>> list =  this.wtDeptTaskService.findByDeptId(formMap.getFormMap(), p);
		map.put("list",list);
		map.put("formMap",formMap.getFormMap());
		map.put("pagination",p);
		
		//加载事项类型
		List<Map<String,Object>> projectTypeList = this.getProjectTypeList("A");
		map.put("projectTypeList", projectTypeList);
		return "worktask/wt_dept_task_list";
	}
	
	/**
	 * 统计各种状态数量
	 * @param formMap
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = "/listByPageCount", method = RequestMethod.POST, produces = { "application/json;charset=UTF-8" })
	public  @ResponseBody Map<String,Object> listByPageCount(HttpServletRequest request,FormMap formMap) throws IOException {
		Map<String,Object> resultMap = new HashMap<String,Object>();
		
		formMap.getFormMap().put("login_user_id",SessionUtil.getLoginUserId(request));
		formMap.getFormMap().put("task_status","A");
		formMap.getFormMap().put("is_delete","N");
		Pagination p = new Pagination();
		formMap.getFormMap().put("dt_status","N");
		this.wtDeptTaskService.findByDeptId(formMap.getFormMap(), p);
		resultMap.put("N", p.getCount());
		
		p = new Pagination();
		formMap.getFormMap().put("dt_status","Y");
		this.wtDeptTaskService.findByDeptId(formMap.getFormMap(), p);
		resultMap.put("Y", p.getCount());
		
		return resultMap;
	}
	
	/**
	 * 单位任务
	 * @author twg
	 * @param formMap
	 * @param pagination
	 * @return
	 */
	@RequestMapping(value = "/unitTaskByPage")
	public String unitTaskByPage(HttpServletRequest request,ModelMap map,FormMap formMap,Pagination p){
		formMap.getFormMap().put("login_user_id",SessionUtil.getLoginUserId(request));
		if(StringUtils.isNull(formMap.getFormMap().get("task_status"))){
			formMap.getFormMap().put("task_status","A");
		}
		if(StringUtils.isNull(formMap.getFormMap().get("unit_task_type")) || "A".equals(formMap.getFormMap().get("unit_task_type").toString())){//主办任务
//			if(StringUtils.isNotNull(formMap.getFormMap().get("dt_status"))){
//			}else{
//				formMap.getFormMap().put("dt_status","N");
//			}
			formMap.getFormMap().put("is_delete","N");
			
			NewsRemindUtil.getAllTime(formMap.getFormMap());
			List<Map<String, Object>> list =  this.wtDeptTaskService.findByDeptId(formMap.getFormMap(), p);
			map.put("list",GetCycleListUtil.getUnfinishedDate(list));
			formMap.getFormMap().put("unit_task_type","A");
			NewsRemindUtil.setPageParam(map);
		}else{//协办任务
			List<Map<String, Object>> list =  this.wtAssistunitService.findAll(formMap.getFormMap());
			map.put("list",list);
		}
		
		map.put("formMap",formMap.getFormMap());
		map.put("pagination",p);
		//加载事项类型
		List<Map<String,Object>> projectTypeList = this.getProjectTypeList("A");
		map.put("projectTypeList", projectTypeList);
		return "worktask/wt_unit_task_list";
	}
	
	/**
	 * 统计各种状态数量
	 * @param formMap
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = "/unitTaskByPageCount", method = RequestMethod.POST, produces = { "application/json;charset=UTF-8" })
	public  @ResponseBody Map<String,Object> unitTaskByPageCount(HttpServletRequest request,FormMap formMap) throws IOException {
		Map<String,Object> resultMap = new HashMap<String,Object>();
		
		formMap.getFormMap().put("login_user_id",SessionUtil.getLoginUserId(request));
		if(StringUtils.isNull(formMap.getFormMap().get("task_status"))){
			formMap.getFormMap().put("task_status","A");
		}
		
		Pagination p = new Pagination();
		formMap.getFormMap().put("is_delete","N");
		this.wtDeptTaskService.findByDeptId(formMap.getFormMap(), p);
		resultMap.put("A", p.getCount());
		
		p = new Pagination();
		this.wtAssistunitService.findByPage(formMap.getFormMap(), p);
		resultMap.put("B", p.getCount());
		
		return resultMap;
	}
	
	/**
	 * To enter edit
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/entryEdit")
	public String entryEdit(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map){
		map.put("data",this.wtDeptTaskService.findById(formMap.getFormMap()));
		return "worktask/wt_dept_task_edit";
	}
	
	/**
	 * Creating
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/create")
	public String create(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map) throws Exception{
		this.wtDeptTaskService.create(formMap.getFormMap());
		return "redirect:/pc/depttask/listByPage";
	}
	
	/**
	 * Modifing
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/modify")
	public String modify(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map) throws Exception{
		this.wtDeptTaskService.modify(formMap.getFormMap());
		return "redirect:/pc/depttask/listByPage";
	}
	
	/**
	 * 仅修改部门进度信息
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/modifyDeptSchedule")
	public String modifyDeptSchedule(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map) throws Exception{
		UploadFile.uploadAttachment(request, formMap);
		formMap.getFormMap().put("dt_schedule_attname",formMap.getFormMap().get("attachment_name"));
		formMap.getFormMap().put("dt_schedule_atturl",formMap.getFormMap().get("attachment"));
		formMap.getFormMap().put("dt_update_time",new Date());
		formMap.getFormMap().put("dt_update_user",SessionUtil.getUserName(request));
		this.wtDeptTaskService.modify(formMap.getFormMap());
		
		this.paramMap.put("dt_dept_task_id",formMap.getFormMap().get("dt_dept_task_id"));
		Map<String,Object> deptTaskMapTemp = this.wtDeptTaskService.findById(this.paramMap);
		this.paramMap.put("ds_submit_year", deptTaskMapTemp.get("dt_submit_year"));
		this.paramMap.put("ds_submit_time", deptTaskMapTemp.get("dt_submit_time"));
		Map<String,Object> dtMap = null;
		List<Map<String,Object>> dsList = this.wtDeptScheduleService.findByPage(this.paramMap, new Pagination());
		if(ListUtils.isNotNull(dsList)){
			dtMap = dsList.get(0);
		}

		if(dtMap != null && dtMap.size() > 0){
			Map<String,Object> tempMap = new HashMap<String,Object>();
			tempMap.put("ds_id",dtMap.get("ds_id"));
			tempMap.put("worktask_id",dtMap.get("worktask_id"));
			tempMap.put("dt_dept_task_id",dtMap.get("dt_dept_task_id"));
			tempMap.put("dept_id",dtMap.get("dept_id"));
			tempMap.put("ds_schedule",dtMap.get("dt_schedule"));
			tempMap.put("ds_schedule_describe",formMap.getFormMap().get("dt_schedule_describe"));
			tempMap.put("ds_next_plan",formMap.getFormMap().get("dt_next_plan"));
			tempMap.put("ds_problem",formMap.getFormMap().get("dt_problem_explain"));
			tempMap.put("ds_evaluate",formMap.getFormMap().get("dt_schedule_evaluate"));
			tempMap.put("ds_attname",formMap.getFormMap().get("dt_schedule_attname"));
			tempMap.put("ds_atturl",formMap.getFormMap().get("dt_schedule_atturl"));
			tempMap.put("ds_update_time",formMap.getFormMap().get("dt_update_time"));
			tempMap.put("ds_update_user",formMap.getFormMap().get("dt_update_user"));
			this.wtDeptScheduleService.modify(tempMap);//修改部门进度历史信息最新一条记录
		}
		request.getSession().setAttribute("dt_session_mark","CLOSE");
		return "redirect:/pc/depttask/entryUpdatePage";
	}
	
	/**
	 * Deleting
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/delete")
	public String delete(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map) throws Exception{
		this.wtDeptTaskService.remove(formMap.getFormMap());
		return "redirect:/pc/depttask/listByPage";
	}
	

	/**
	 * To enter view
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/entryView")
	public String entryView(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map){
		map.put("data",this.wtDeptTaskService.findById(formMap.getFormMap()));
		return "worktask/wt_dept_task_view";
	}

	/**
	 * 异步修改部门任务信息（在修改事项表时）
	 * @param formMap
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/modifyDeptTask", method = RequestMethod.POST, produces = { "application/json;charset=UTF-8" })
	public  @ResponseBody Map<String,Object> modifyDeptTask(HttpServletRequest request,FormMap formMap) throws Exception {
		Map<String,Object> paramMap = new HashMap<String,Object>();
		if(StringUtils.isNotNull(formMap.getFormMap().get("dt_opt_status"))){//退回
			formMap.getFormMap().put("dt_opt_time",new Date());
			formMap.getFormMap().put("dt_opt_user",SessionUtil.getUserName(request));
		}
		formMap.getFormMap().put("wnr_mode","A");//消息提醒参数
		formMap.getFormMap().put("wnr_user_id",SessionUtil.getLoginUserId(request));//消息提醒参数
		this.wtDeptTaskService.modify(formMap.getFormMap());
		return paramMap;
	}
	
	/**
	 * 进入分配界面
	 * @author twg
	 * @param formMap
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value = "/entryAssigns")
	public String entryAssigns(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map) throws Exception{
		//事项信息
		Map<String,Object> wtMap = this.wtWorktaskService.findById(formMap.getFormMap());
		map.put("data",wtMap);
		//部门任务列表
		this.paramMap.put("worktask_id",wtMap.get("worktask_id"));
		this.paramMap.put("dept_id",formMap.getFormMap().get("dept_id"));
		List<Map<String,Object>> deptTaskList = this.wtDeptTaskService.findAll(this.paramMap);
		map.put("deptTaskList",deptTaskList);
		//部门分配结果
		List<Map<String,Object>> arrList = this.wtTaskArrangeService.findAll(this.paramMap);
		map.put("arrange_detail",arrList);
//		this.wtTaskArrangeService.modifyAlreadyRead(formMap.getFormMap());//设置已读
		map.put("formMap",formMap.getFormMap());
		return "worktask/wt_dept_task_edit";
	}
	
	/**
	 * 弹出更新进度页面
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/entryUpdatePage")
	public String entryUpdatePage(HttpServletRequest request,FormMap formMap,ModelMap map){
		Map<String,Object> data = this.wtDeptTaskService.findById(formMap.getFormMap());
		//设置已选择数据
		if(StringUtils.isNotNull(formMap.getFormMap().get("teIds"))){//更新部门进度
			String teIds = formMap.getFormMap().get("teIds").toString();
			teIds = teIds.substring(0, teIds.length()-1);
			this.paramMap.put("taskExecutionIds", teIds);
			List<Map<String,Object>> teList = this.wtTaskExecutionService.findAll(this.paramMap);
			if(ListUtils.isNotNull(teList)){
				StringBuffer dt_schedule_describe = new StringBuffer();
				StringBuffer dt_next_plan = new StringBuffer();
				StringBuffer dt_problem_explain = new StringBuffer();
				for(Map<String,Object> teMap : teList){
					dt_schedule_describe.append(teMap.get("execution_content")+"\r\n");
					dt_next_plan.append(teMap.get("next_plan")+"\r\n");
					dt_problem_explain.append(teMap.get("assist_explain")+"\r\n");
				}
				data.put("dt_schedule_describe",dt_schedule_describe.toString());
				data.put("dt_next_plan",dt_next_plan.toString());
				data.put("dt_problem_explain",dt_problem_explain.toString());
			}
		}
		map.put("data",data);
		
		//读取往期最新记录
		this.paramMap.put("dt_dept_task_id",formMap.getFormMap().get("dt_dept_task_id"));
		List<Map<String,Object>> dsList = this.wtDeptScheduleService.findByPage(this.paramMap, new Pagination());
		if(ListUtils.isNotNull(dsList)){
			if(StringUtils.isNotNull(data.get("wt_opt_type")) 
					&& (!"E".equals(data.get("wt_opt_type").toString()))
					&& StringUtils.isNotNull(formMap.getFormMap().get("dt_submit_year_temp")) && StringUtils.isNotNull(formMap.getFormMap().get("dt_submit_time_temp"))){
				for(Map<String,Object> tempMap : dsList){
					if(StringUtils.isNotNull(tempMap.get("ds_submit_year")) && StringUtils.isNotNull(tempMap.get("ds_submit_time"))){
						if(formMap.getFormMap().get("dt_submit_year_temp").toString().equals(tempMap.get("ds_submit_year").toString())
								&& formMap.getFormMap().get("dt_submit_time_temp").toString().equals(tempMap.get("ds_submit_time").toString()) ){
							formMap.getFormMap().put("opt_mark", "update");
							break;
						}else{
							formMap.getFormMap().put("opt_mark", "create");
						}
					}
				}
			}
			if("create".equals(formMap.getFormMap().get("opt_mark"))){//更新部门任务进度（即创建）
				map.put("dsMap", dsList.get(0));
			}else if("update".equals(formMap.getFormMap().get("opt_mark")) && dsList.size() > 1){//修改部门任务进度
				map.put("dsMap", dsList.get(1));
			}
		}else{
			formMap.getFormMap().put("opt_mark", "create");
		}
//		return "worktask/wt_dept_task_update";
		map.put("formMap",formMap.getFormMap());
//		this.paramMap.clear();
//		this.paramMap.put("dt_dept_task_id",formMap.getFormMap().get("dt_dept_task_id"));
//		Map<String,Object> dtMap = this.wtDeptTaskService.findById(this.paramMap);
		this.setParamMapVal(data, "worktask_id,dept_id");
		map.put("result",this.wtWorktaskService.setUnfinishedTime(this.paramMap, "DEPT"));
		
		map.put("cycle_list",this.wtDeptScheduleService.getReportingPeriod(data));
		return this.platformType(request, "worktask/wt_dept_task_update", "worktask/mobile/wt_dept_task_update");
	}
	
	/**
	 * 更新部门进度
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/updateSchedule")
	public String updateSchedule(HttpServletRequest request,FormMap formMap,ModelMap map) throws Exception{
		if(StringUtils.isNotNull(formMap.getFormMap().get("dt_dept_task_id"))){
			UploadFile.uploadAttachment(request, formMap);
			formMap.getFormMap().put("dt_schedule_attname",formMap.getFormMap().get("attachment_name"));
			formMap.getFormMap().put("dt_schedule_atturl",formMap.getFormMap().get("attachment"));
			formMap.getFormMap().put("dt_update_time",new Date());
			formMap.getFormMap().put("dt_update_user",SessionUtil.getUserName(request));
			formMap.getFormMap().put("dt_approval","O");
			formMap.getFormMap().put("dt_is_lock","N");
			formMap.getFormMap().put("dt_opt_status","O");
			boolean flag = true;
			this.paramMap.put("dt_dept_task_id", formMap.getFormMap().get("dt_dept_task_id"));
			Map<String,Object> deptTaskMapTemp = this.wtDeptTaskService.findById(this.paramMap);
			if(StringUtils.isNotNull(formMap.getFormMap().get("dt_submit_year"))
					&& StringUtils.isNotNull(formMap.getFormMap().get("dt_submit_time"))){//月报或者周报（非日报）
				if(StringUtils.isNotNull(deptTaskMapTemp.get("dt_submit_year")) 
						&& StringUtils.isNotNull(deptTaskMapTemp.get("dt_submit_time"))){
					//如果本次填报的进度是往期进度（非最新进度），则无需更新部门进度
					int new_y = Integer.parseInt(formMap.getFormMap().get("dt_submit_year").toString());
					int new_t = Integer.parseInt(formMap.getFormMap().get("dt_submit_time").toString());
					int old_y = Integer.parseInt(deptTaskMapTemp.get("dt_submit_year").toString());
					int old_t = Integer.parseInt(deptTaskMapTemp.get("dt_submit_time").toString());
					if((new_y >= old_y && new_t >= old_t) || new_y > old_y){
					}else{
						flag = false;
					}
				}
			}
			if(flag){
				this.wtDeptTaskService.modify(formMap.getFormMap());//更新最新部门进度消息
			}
			
			Map<String,Object> pMap = new HashMap<String,Object>();
			pMap.put("worktask_id", deptTaskMapTemp.get("worktask_id"));
			pMap.put("dept_id", deptTaskMapTemp.get("dept_id"));
			pMap.put("wt_opt_type", deptTaskMapTemp.get("wt_opt_type"));
			pMap.put("submit_year", formMap.getFormMap().get("dt_submit_year"));
			pMap.put("submit_time", formMap.getFormMap().get("dt_submit_time"));
			this.wtTaskExecutionService.modifyToY(pMap);
			
			//新增部门进度记录
			Map<String,Object> dtMap = this.wtDeptTaskService.findById(this.paramMap);
			Map<String,Object> tempMap = new HashMap<String,Object>();
			tempMap.put("worktask_id",dtMap.get("worktask_id"));
			tempMap.put("dt_dept_task_id",dtMap.get("dt_dept_task_id"));
			tempMap.put("dept_id",dtMap.get("dept_id"));
			tempMap.put("ds_schedule",dtMap.get("dt_schedule"));
			tempMap.put("ds_schedule_describe",formMap.getFormMap().get("dt_schedule_describe"));
			tempMap.put("ds_next_plan",formMap.getFormMap().get("dt_next_plan"));
			tempMap.put("ds_problem",formMap.getFormMap().get("dt_problem_explain"));
			tempMap.put("ds_evaluate",formMap.getFormMap().get("dt_schedule_evaluate"));
			tempMap.put("ds_attname",formMap.getFormMap().get("dt_schedule_attname"));
			tempMap.put("ds_atturl",formMap.getFormMap().get("dt_schedule_atturl"));
			tempMap.put("ds_update_time",formMap.getFormMap().get("dt_update_time"));
			tempMap.put("ds_update_user",formMap.getFormMap().get("dt_update_user"));
			tempMap.put("ds_submit_year",formMap.getFormMap().get("dt_submit_year"));
			tempMap.put("ds_submit_time",formMap.getFormMap().get("dt_submit_time"));
			this.wtDeptScheduleService.create(tempMap);
			
			if(StringUtils.isNotNull(formMap.getFormMap().get("task_execution_id"))){//更新职员操作记录表
				this.paramMap.put("update_time",new Date());
//				formMap.getFormMap().put("update_user",SessionUtil.getLoginUserId(request));
				this.paramMap.put("update_user",SessionUtil.getUserName(request));
				this.paramMap.put("task_execution_id", formMap.getFormMap().get("task_execution_id"));
				this.paramMap.put("approval_status","Y");
				this.wtTaskExecutionService.modify(this.paramMap);
			}
		}
		request.getSession().setAttribute("dt_session_mark","CLOSE");
//		return "redirect:/pc/depttask/entryUpdatePage";
		return this.platformType(request, "redirect:/pc/depttask/entryUpdatePage", "redirect:/pc/worktask/entryApprovalList");
	}
	
	
	/**
	 * 获取部门任务未报送时间
	 * @param formMap
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/getUnfinishedTime", method = RequestMethod.POST, produces = { "application/json;charset=UTF-8" })
	public @ResponseBody Map<String,Object> getUnfinishedTime(FormMap formMap){
		if(StringUtils.isNotNull(formMap.getFormMap().get("worktask_id")) && StringUtils.isNotNull(formMap.getFormMap().get("dept_id"))){//部门任务
			this.resultMap = this.wtWorktaskService.setUnfinishedTime(formMap.getFormMap(), "DEPT");
		}
		return this.resultMap;
	}
	
	
}	