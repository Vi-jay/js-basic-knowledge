package com.qian.module.worktask.action;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import com.gzdec.framework.page.Pagination;

import com.qian.module.common.action.BaseAction;
import com.qian.module.worktask.service.inter.WtDeptTaskService;
import com.qian.module.worktask.service.inter.WtTaskArrangeService;
import com.qian.module.worktask.service.inter.WtTaskExecutionService;
import com.qian.module.worktask.service.inter.WtTemporarySaveService;
import com.qian.module.worktask.service.inter.WtWorktaskService;
import com.qian.module.worktask.util.GetCycleListUtil;
import com.qian.module.worktask.util.NewsRemindUtil;
import com.qian.util.FormMap;
import com.qian.util.SessionUtil;
import com.qian.util.StringUtils;

/**
 * 描述：工作任务安排
 * @author twg
 */
@Controller
@Scope("prototype")
@RequestMapping(value = "/pc/taskarrange")
public class WtTaskArrangeAction extends BaseAction{
	
	
	@Autowired
	private WtWorktaskService wtWorktaskService;
	@Autowired
	private WtTaskArrangeService wtTaskArrangeService;
	@Autowired
	private WtTaskExecutionService wtTaskExecutionService;
	@Autowired
	private WtDeptTaskService wtDeptTaskService;
	@Autowired
	private WtTemporarySaveService wtTemporarySaveService;
	
	/**
	 * To enter list
	 * @author twg
	 * @param formMap
	 * @param pagination
	 * @return
	 */
	@RequestMapping(value = "/listByPage")
	public String listByPage(HttpServletRequest request,HttpServletResponse response,ModelMap map,FormMap formMap,Pagination p){
//		List<Map<String, Object>> list =  this.wtTaskArrangeService.findByPage(formMap.getFormMap(), p);
		formMap.getFormMap().put("user_id",SessionUtil.getLoginUserId(request));
		List<Map<String, Object>> list =  this.wtTaskArrangeService.findMyWorkTask(formMap.getFormMap(),p);
		map.put("list",list);
		map.put("formMap",formMap.getFormMap());
		map.put("pagination",p);
		return "worktask/wt_task_arrange_list";
	}
	
	/**
	 * 进入我的任务分类统计界面（APP端）
	 * @author twg
	 * @param formMap
	 * @param pagination
	 * @return
	 */
	@RequestMapping(value = "/entryMyTaskForApp")
	public String entryMyTaskForApp(HttpServletRequest request,HttpServletResponse response,ModelMap map,FormMap formMap,Pagination p){
		
		return "worktask/mobile/wt_task_arrange_count";
	}
	
	/**
	 * To enter list
	 * @author twg
	 * @param formMap
	 * @param pagination
	 * @return
	 */
	@RequestMapping(value = "/mytask")
	public String mytask(HttpServletRequest request,HttpServletResponse response,ModelMap map,FormMap formMap,Pagination p){
		//主任务
		formMap.getFormMap().put("user_id",SessionUtil.getLoginUserId(request));
		if(StringUtils.isNotNull(formMap.getFormMap().get("task_status"))){
		}else{
			formMap.getFormMap().put("my_task_status","Y");
		}
		NewsRemindUtil.getAllTime(formMap.getFormMap());
		List<Map<String, Object>> list =  this.wtTaskArrangeService.findMyWorkTask(formMap.getFormMap(),p);
//		map.put("list",list);
		map.put("list",GetCycleListUtil.getUnfinishedDate(list));
		//协助任务
//		formMap.getFormMap().put("assist_user",SessionUtil.getLoginUserId(request));
//		List<Map<String, Object>> assistList =  this.wtTaskExecutionService.findAssistTask(formMap.getFormMap());
//		if(assistList != null && assistList.size() > 0){
//			int assistListSize = assistList.size();
//			for(Map<String, Object> taMap : list){
//				for(int i=0;i<assistListSize;i++){
//					if(taMap.get("worktask_id").toString().equals(assistList.get(i).get("worktask_id").toString())){
//						assistList.remove(i);
//					}
//				}
//			}
//		}
//		map.put("assistList",assistList);
		//加载事项类型
		List<Map<String,Object>> projectTypeList = this.getProjectTypeList("A");
		map.put("projectTypeList", projectTypeList);
		map.put("formMap",formMap.getFormMap());
		map.put("pagination",p);
//		return "worktask/wt_task_arrange_list";
		NewsRemindUtil.setPageParam(map);
		return this.platformType(request, "worktask/wt_task_arrange_list", "worktask/mobile/wt_task_arrange_list");
	}
	
	/**
	 * 统计各种状态数量
	 * @param formMap
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = "/mytaskCount", method = RequestMethod.POST, produces = { "application/json;charset=UTF-8" })
	public  @ResponseBody Map<String,Object> mytaskCount(HttpServletRequest request,FormMap formMap) throws IOException {
		Map<String,Object> resultMap = new HashMap<String,Object>();
		
		formMap.getFormMap().put("user_id",SessionUtil.getLoginUserId(request));
		Pagination p = new Pagination();
		formMap.getFormMap().put("my_task_status","Y");
		this.wtTaskArrangeService.findMyWorkTask(formMap.getFormMap(),p);
		resultMap.put("Y", p.getCount());
		
		formMap.getFormMap().remove("my_task_status");
		
		p = new Pagination();
		formMap.getFormMap().put("task_status","A");
		this.wtTaskArrangeService.findMyWorkTask(formMap.getFormMap(),p);
		resultMap.put("A", p.getCount());
		
		p = new Pagination();
		formMap.getFormMap().put("task_status","B");
		this.wtTaskArrangeService.findMyWorkTask(formMap.getFormMap(),p);
		resultMap.put("B", p.getCount());
		
		p = new Pagination();
		formMap.getFormMap().put("task_status","C");
		this.wtTaskArrangeService.findMyWorkTask(formMap.getFormMap(),p);
		resultMap.put("C", p.getCount());
		
		p = new Pagination();
		formMap.getFormMap().put("task_status","D");
		this.wtTaskArrangeService.findMyWorkTask(formMap.getFormMap(),p);
		resultMap.put("D", p.getCount());
		
		p = new Pagination();
		formMap.getFormMap().put("task_status","E");
		this.wtTaskArrangeService.findMyWorkTask(formMap.getFormMap(),p);
		resultMap.put("E", p.getCount());
		
		return resultMap;
	}
	
	/**
	 * To enter edit
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/entryEdit")
	public String entryEdit(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map){
//		map.put("data",this.wtTaskArrangeService.findById(formMap.getFormMap()));//工作任务安排表
		Map<String,Object> wtMap = this.wtWorktaskService.findById(formMap.getFormMap());//工作任务表
		map.put("data",wtMap);
		//任务部门列表
		this.paramMap.put("dept_id",formMap.getFormMap().get("dept_id"));
		this.paramMap.put("worktask_id",wtMap.get("worktask_id"));
		List<Map<String,Object>> deptList = this.wtDeptTaskService.findAll(this.paramMap);
		map.put("deptTaskList", deptList);
		this.paramMap.put("user_id",SessionUtil.getLoginUserId(request));//只显示自己任务
		List<Map<String,Object>> arrList = this.wtTaskArrangeService.findAll(this.paramMap);//工作任务安排表
//		if(StringUtils.isNotNull(formMap.getFormMap().get("opt_mark")) && "mytask".equals(formMap.getFormMap().get("opt_mark").toString())){
//		}else{
//			this.paramMap.put("approval_status", "Y");//非当前操作用户，只允许查看已经通过审核的信息
//		}
		List<Map<String,Object>> exeList = this.wtTaskExecutionService.findAll(this.paramMap);//任务执行表
		if(exeList != null && exeList.size() > 0){
			List<Map<String,Object>> tempList = new ArrayList<Map<String,Object>>();
			tempList.add(exeList.get(exeList.size()-1));
			exeList = tempList;
			List<Map<String,Object>> detailList = new ArrayList<Map<String,Object>>();
			for(Map<String,Object> arrMap : arrList){
				detailList = new ArrayList<Map<String,Object>>();
				for(Map<String,Object> exeMap : exeList){
					if(arrMap.get("user_id").toString().equals(exeMap.get("user_id").toString())){
						detailList.add(exeMap);
					}
				}
				arrMap.put("detailList", detailList);
			}
			map.put("last_schedule", exeList.get(exeList.size()-1).get("schedule"));
		}else{
			map.put("last_schedule", 0);
		}
		map.put("detail",arrList);
		map.put("formMap",formMap.getFormMap());
//		return "worktask/wt_task_arrange_edit";
		
		this.paramMap.put("task_arrange_id", arrList.get(0).get("task_arrange_id"));
		this.setParamMapVal(formMap.getFormMap(), "worktask_id,task_arrange_id,user_id");
		map.put("result",this.wtWorktaskService.setUnfinishedTime(this.paramMap,"TA"));
		
		//读取暂存信息
		Map<String,Object> tempMap = new HashMap<String,Object>();
		tempMap.put("worktask_id", this.paramMap.get("worktask_id"));
		tempMap.put("task_arrange_id", arrList.get(0).get("task_arrange_id"));
		tempMap.put("user_id", this.paramMap.get("user_id"));
		map.put("tsdata",this.wtTemporarySaveService.find(tempMap));
		
		//获取进度填写周期列表
		map.put("cycle_list",this.wtTaskExecutionService.getReportingPeriod(wtMap, arrList.get(0)));
		return this.platformType(request, "worktask/wt_task_arrange_edit", "worktask/mobile/wt_task_arrange_edit");
	}
	
	/**
	 * Creating
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/create")
	public String create(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map) throws Exception{
		this.wtTaskArrangeService.create(formMap.getFormMap());
		return "redirect:/pc/depttask/listByPage";
	}
	
	/**
	 * Modifing
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/modify")
	public String modify(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map) throws Exception{
		this.wtTaskArrangeService.modify(formMap.getFormMap());
		return "redirect:/pc/depttask/listByPage";
	}
	
	/**
	 * Modifing
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/modifyToBath")
	public String modifyToBath(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map) throws Exception{
		this.wtTaskArrangeService.modifyToBath(formMap.getFormMap());
		return "redirect:/pc/depttask/listByPage";
	}
	
	/**
	 * Deleting
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/delete")
	public String delete(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map) throws Exception{
		this.wtTaskArrangeService.remove(formMap.getFormMap());
		return "redirect:/pc/taskarrange/listByPage";
	}
	

	/**
	 * To enter view
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/entryView")
	public String entryView(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map){
		map.put("data",this.wtTaskArrangeService.findById(formMap.getFormMap()));
		return "worktask/wt_task_arrange_view";
	}

	
	/**
	 * 异步修改用户安排表信息（修改任务表时）
	 * @param formMap
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/modifyTaskArrange", method = RequestMethod.POST, produces = { "application/json;charset=UTF-8" })
	public  @ResponseBody Map<String,Object> modifyTaskArrange(FormMap formMap) throws Exception {
		Map<String,Object> paramMap = new HashMap<String,Object>();
		this.wtTaskArrangeService.modify(formMap.getFormMap());
		return paramMap;
	}
	
	/**
	 * 暂停与启用
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/modifyToSuspend")
	public String modifyToSuspend(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map) throws Exception{
		this.wtTaskArrangeService.modify(formMap.getFormMap());
		return "redirect:/pc/taskarrange/mytask";
	}
	
	
	/**
	 * 异步删除或取消用户安排表信息（修改任务表时）
	 * @param formMap
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/removeTaskArrange", method = RequestMethod.POST, produces = { "application/json;charset=UTF-8" })
	public  @ResponseBody Map<String,Object> removeTaskArrange(FormMap formMap) throws Exception {
		Map<String,Object> paramMap = new HashMap<String,Object>();
		if(StringUtils.isNotNull(formMap.getFormMap().get("task_arrange_id")) 
				&& StringUtils.isNotNull(formMap.getFormMap().get("worktask_id")) 
				&& StringUtils.isNotNull(formMap.getFormMap().get("user_id"))){
			this.paramMap.put("worktask_id", formMap.getFormMap().get("worktask_id"));
			this.paramMap.put("user_id", formMap.getFormMap().get("user_id"));
			List<Map<String,Object>> list = this.wtTaskExecutionService.findAll(this.paramMap);
			if(list != null && list.size() > 0){//取消
				this.paramMap.put("is_cancel","Y");
				this.wtTaskArrangeService.modify(this.paramMap);
			}else{//物理删除
				this.paramMap.put("ids",formMap.getFormMap().get("task_arrange_id"));
				this.wtTaskArrangeService.remove(this.paramMap);
			}
		}
		return paramMap;
	}
	

	/**
	 * 开始执行任务
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/startPerformTasks")
	public String startPerformTasks(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map) throws Exception{
		if(StringUtils.isNotNull(formMap.getFormMap().get("task_arrange_id"))){
			this.paramMap.put("task_arrange_id",formMap.getFormMap().get("task_arrange_id"));
			this.paramMap.put("task_status","C");
			this.paramMap.put("task_status_time",new Date());
			this.wtTaskArrangeService.modify(this.paramMap);
		}
		return "redirect:/pc/taskarrange/mytask";
	}
	
	/**
	 * 标记操作
	 * @param formMap
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/toSign", method = RequestMethod.POST, produces = { "application/json;charset=UTF-8" })
	public  @ResponseBody Map<String,Object> toSign(FormMap formMap) throws Exception {
		Map<String,Object> paramMap = new HashMap<String,Object>();
		if(StringUtils.isNotNull(formMap.getFormMap().get("task_arrange_id")) && StringUtils.isNotNull(formMap.getFormMap().get("is_sign"))){
			this.wtTaskArrangeService.modify(formMap.getFormMap());
		}
		return paramMap;
	}
	
	
	/**
	 * 获取未报送时间
	 * @param formMap
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/getUnfinishedTime", method = RequestMethod.POST, produces = { "application/json;charset=UTF-8" })
	public @ResponseBody Map<String,Object> getUnfinishedTime(FormMap formMap){
		if(StringUtils.isNotNull(formMap.getFormMap().get("worktask_id")) 
				&& StringUtils.isNotNull(formMap.getFormMap().get("task_arrange_id"))
				&& StringUtils.isNotNull(formMap.getFormMap().get("user_id"))){
			this.resultMap = this.wtWorktaskService.setUnfinishedTime(formMap.getFormMap(), "TA");
		}
		return this.resultMap;
	}
	
	
}	