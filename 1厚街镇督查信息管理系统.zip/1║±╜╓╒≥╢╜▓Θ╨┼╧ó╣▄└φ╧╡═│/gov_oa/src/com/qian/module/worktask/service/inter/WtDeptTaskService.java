package com.qian.module.worktask.service.inter;

import java.util.List;
import java.util.Map;
import com.gzdec.framework.page.Pagination;

/**
 * @author twg
 */
public interface WtDeptTaskService {

	/**
	 * Query List
	 * @author twg
	 * @param valueMap
	 * @return
	 */
	public List<Map<String,Object>> findAll(Map<String,Object> valueMap);
	
	/**
	 * Query Page List
	 * @author twg
	 * @param valueMap
	 * @return
	 */
	public List<Map<String,Object>> findByPage(Map<String,Object> valueMap,Pagination pagination);
	
	/**
	 * Get A Record
	 * @author twg
	 * @param valueMap
	 * @return
	 */
	public Map<String,Object> find(Map<String,Object> valueMap);
	
	/**
	 * Get A Record
	 * @author twg
	 * @param valueMap
	 * @return
	 */
	public Map<String,Object> findById(Map<String,Object> valueMap);
	
	/**
	 * Creating
	 * @author twg
	 * @param valueMap
	 * @return
	 */
	public int create(Map<String,Object> valueMap) throws Exception;	
	
	/**
	 * Modifing
	 * @author twg
	 * @param valueMap
	 * @return
	 */
	public int modify(Map<String,Object> valueMap) throws Exception;	
	
	/**
	 * Deleting
	 * @author twg
	 * @param valueMap
	 * @return
	 */
	public int remove(Map<String,Object> valueMap) throws Exception;
	

	/**
	 * 根据部门ID查询该部门事项信息
	 * @author twg
	 * @param valueMap
	 * @return
	 */
	public List<Map<String,Object>> findByDeptId(Map<String,Object> valueMap,Pagination pagination);


	/**
	 * 更新部门进度
	 * @author twg
	 * @param valueMap
	 * @return
	 */
	public int updateSchedule(Map<String,Object> valueMap) throws Exception;
	/**
	 * 部门任务完成率统计报表
	 * @author twg
	 * @param valueMap
	 * @return
	 */
	public List<Map<String,Object>> findDeptTaskStatistics(Map<String,Object> valueMap);
	
	/**
	 * 事项计划图表
	 * @author twg
	 * @param valueMap
	 * @return
	 */
	public List<Map<String,Object>> findForChart(Map<String,Object> valueMap);
	
	/**
	 * 查询部门未报送的事项（消息提醒推送）
	 * @author twg
	 * @param valueMap
	 * @return
	 */
	public List<Map<String,Object>> findUnfinishedProject(Map<String,Object> valueMap);
	
}