package com.qian.module.worktask.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.gzdec.framework.page.Pagination;
import com.gzdec.framework.util.UniqueIDGenerator;

import com.qian.module.worktask.dao.WtChangeTimeDao;
import com.qian.module.worktask.service.inter.WtChangeTimeService;

/**
 * @author twg
 */
@Service("wtChangeTimeServiceImpl")
public class WtChangeTimeServiceImpl implements WtChangeTimeService{
	
	@Autowired
	private WtChangeTimeDao wtChangeTimeDao;
	
	public Map<String,Object> find(Map<String,Object> valueMap) {
		return this.wtChangeTimeDao.find(valueMap);
	}
	
	public Map<String,Object> findById(Map<String,Object> valueMap) {
		String id = "";
		if(valueMap.get("ct_change_time_id") != null){
			id = valueMap.get("ct_change_time_id").toString().trim();
		}
		if("".equals(id)){
			return new HashMap<String,Object>();
		}
		return this.wtChangeTimeDao.find(valueMap);
	}

	public List<Map<String,Object>> findAll(Map<String,Object> valueMap) {
		return this.wtChangeTimeDao.findAll(valueMap);
	}

	public List<Map<String,Object>> findByPage(Map<String,Object> valueMap,Pagination pagination) {
		return this.wtChangeTimeDao.findByPage(valueMap, pagination);
	}
	
	public int create(Map<String,Object> valueMap)  throws Exception{
		String id = "";
		if(valueMap.get("ct_change_time_id") != null){
			id = valueMap.get("ct_change_time_id").toString().trim();
		}
		if("".equals(id)){
			valueMap.put("ct_change_time_id", UniqueIDGenerator.getUUID());
		}
		Map<String,Object> paramMap = new HashMap<String,Object>();
		paramMap.put("dt_dept_task_id",valueMap.get("dt_dept_task_id"));
		paramMap.put("ct_status","O");
		List<Map<String,Object>> list = this.wtChangeTimeDao.findAll(paramMap);
		if(list != null && list.size() > 0){//未审核完毕，不允许继续申请
			return 0;
		}else{
			paramMap.put("ct_is_new",1);
			this.wtChangeTimeDao.modifyByDtId(paramMap);
			this.wtChangeTimeDao.create(valueMap);
		}
		return 1;
	}	

	public int modify(Map<String,Object> valueMap) throws Exception{
		if(valueMap.get("ct_change_time_id") != null){
			valueMap.put("update_time",new Date());
			return this.wtChangeTimeDao.modify(valueMap);
		}else{
			return -1;
		}
	}

	public int remove(Map<String,Object> valueMap) throws Exception{
		String[] idArr = new String[1];
		if(valueMap.get("ids") != null && valueMap.get("ids").toString().length() > 0){
			if (valueMap.get("ids") instanceof String) {
				idArr[0] = valueMap.get("ids").toString();
			}else{
		    		idArr = (String[]) valueMap.get("ids");
			}
			List<Map<String,Object>> list = new ArrayList<Map<String,Object>>();
			String id = "";
			Map<String,Object> toMap = new HashMap<String,Object>();
			for(int i = 0; i < idArr.length; i++){
				id = idArr[i];
				toMap = new HashMap<String,Object>();
				toMap.put("ct_change_time_id", id);
				list.add(toMap);
			}
			return this.wtChangeTimeDao.remove(list);
		}else{
			return -1;
		}
	}
	
	
	
	
	
	
	
	
	
}