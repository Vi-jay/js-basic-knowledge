package com.qian.module.worktask.service.inter;

import java.util.List;
import java.util.Map;
import com.gzdec.framework.page.Pagination;

/**
 * @author twg
 */
public interface WtTaskExecutionService {

	/**
	 * Query List
	 * @author twg
	 * @param valueMap
	 * @return
	 */
	public List<Map<String,Object>> findAll(Map<String,Object> valueMap);
	
	/**
	 * Query Page List
	 * @author twg
	 * @param valueMap
	 * @return
	 */
	public List<Map<String,Object>> findByPage(Map<String,Object> valueMap,Pagination pagination);
	
	/**
	 * Get A Record
	 * @author twg
	 * @param valueMap
	 * @return
	 */
	public Map<String,Object> find(Map<String,Object> valueMap);
	
	/**
	 * Get A Record
	 * @author twg
	 * @param valueMap
	 * @return
	 */
	public Map<String,Object> findById(Map<String,Object> valueMap);
	
	/**
	 * Creating
	 * @author twg
	 * @param valueMap
	 * @return
	 */
	public int create(Map<String,Object> valueMap) throws Exception;	
	
	/**
	 * Modifing
	 * @author twg
	 * @param valueMap
	 * @return
	 */
	public int modify(Map<String,Object> valueMap) throws Exception;	
	
	/**
	 * Deleting
	 * @author twg
	 * @param valueMap
	 * @return
	 */
	public int remove(Map<String,Object> valueMap) throws Exception;
	

	/**
	 * 根据用户ID查询用户协助任务
	 * @author twg
	 * @param valueMap
	 * @return
	 */
	public List<Map<String,Object>> findAssistTask(Map<String,Object> valueMap);


	/**
	 * 当任务结束时，将所有状态为协助中改为已完成
	 * @author twg
	 * @param valueMap
	 * @return
	 */
	public int modifyAssistStatus(Map<String,Object> valueMap) throws Exception;

	
	/**
	 * 根据搜索条件查询事项报表结果
	 * @author twg
	 * @param valueMap
	 * @return
	 */
	public List<Map<String,Object>> findReportResult(Map<String,Object> valueMap);
	
	/**
	 * 根据事项ID查询审核中，不通过，已退回的任务执行信息
	 * @author twg
	 * @param valueMap
	 * @return
	 */
	public List<Map<String,Object>> findInfoByWorkTaskId(Map<String,Object> valueMap);
	
	/**
	 * 任务执行时需更新其他数据表进度以及状态（在同一个事务内）
	 * @author twg
	 * @param valueMap
	 * @return
	 */
	public boolean updateSchedule(Map<String,Object> valueMap) throws Exception;
	
	/**
	 * 获取进度填写周期列表
	 * @author twg
	 * @param valueMap
	 * @return
	 */
	public List<Map<String,Object>> getReportingPeriod(Map<String,Object> worktask,Map<String, Object> taskArrange);
	
	
	/**
	 * 部门管理员上报部门进度时，将全部任务执行步骤改为审核通过
	 * @author twg
	 * @param valueMap
	 * @return
	 */
	public int modifyToY(Map<String,Object> valueMap) throws Exception;	
	
}