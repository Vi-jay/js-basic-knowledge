package com.qian.module.worktask.util;

import java.util.ArrayList;

import java.util.Calendar;
import java.util.List;
import java.util.Map;

import org.springframework.ui.ModelMap;

import com.qian.module.worktask.service.inter.WtNewsRemindService;
import com.qian.util.ListUtils;
public class NewsRemindUtil {
	
	private static final String PC_OPT_CODE = "RWFP_2_LIST_VIEW";//任务分配权限操作编码（PC端）
	private static final String APP_OPT_CODE = "INDEX_RWFP_LIST_VIEW";//任务分配权限操作编码（移动端）
	
	
	/**
	 * 判断当前登录用户是否是部门管理员 
	 */
	public static boolean judgeUserIdentity(List<Map<String,Object>> userMenuList){
		boolean flag = false;
		if(ListUtils.isNotNull(userMenuList)){
			for(Map<String,Object> menu : userMenuList){
				if(PC_OPT_CODE.equals(menu.get("opt_code").toString()) || APP_OPT_CODE.equals(menu.get("opt_code").toString())){
					flag = true;
					break;
				}
			}
		}
		return flag;
	}
	
	/**
	 * 判断并加载所属部门的事项消息
	 * @param wtNewsRemindService
	 * @param list 消息集合
	 * @param userMenuList 用户菜单
	 * @param opt_code 分配任务权限操作编码（首先判断该用户是否存在此操作编码）
	 * @return
	 */
	public static List<Map<String,Object>> getDeptNewsRemind(WtNewsRemindService wtNewsRemindService,List<Map<String,Object>> list,List<Map<String,Object>> userMenuList,Map<String,Object> parmamMap){
		if(ListUtils.isNull(list)){
			list = new ArrayList<Map<String,Object>>();
		}
		if(ListUtils.isNotNull(userMenuList)){
			boolean flag = NewsRemindUtil.judgeUserIdentity(userMenuList);
			if(flag){
				List<Map<String,Object>> deptNewsList = wtNewsRemindService.findDeptNewsRemind(parmamMap,null);
				if(ListUtils.isNotNull(deptNewsList)){
					list.addAll(deptNewsList);
				}
			}
		}
		return list;
	}
	
	@SuppressWarnings("static-access")
	public static void setPageParam(ModelMap map){
		Calendar c = Calendar.getInstance();
		int year = c.get(Calendar.YEAR);//当前年份
		int month = c.get(Calendar.MONTH)+1;//当前月份
		int week = c.get(c.WEEK_OF_YEAR);//当前周
		map.put("year", year);
		map.put("month", month);
		map.put("week", week);
	}
	
	/**获取本次周期以及上一次周期*/
	@SuppressWarnings("static-access")
	public static void getAllTime(Map<String,Object> map){
		Calendar c = Calendar.getInstance();
		int year = c.get(Calendar.YEAR);//当前年份
		int month = c.get(Calendar.MONTH)+1;//当前月份
		int week = c.get(c.WEEK_OF_YEAR);//当前周
		
		int back_year_month = year;
		int back_month = month-1;
		if(month == 1){
			back_year_month = year-1;
			back_month = 12;
		}
		
		int back_year_week = year;
		int back_week = week-1;
		if(week == 1){
			back_year_week = year-1;
			back_week = 52;
		}
		map.put("year", year);//当前年份
		map.put("back_year_month", back_year_month);//上一年
		map.put("back_year_week", back_year_week);//上一年
		map.put("month", month);//当前月
		map.put("back_month", back_month);//上一个月
		map.put("week", week);//当前周
		map.put("back_week", back_week);//上一周
	}
	
}