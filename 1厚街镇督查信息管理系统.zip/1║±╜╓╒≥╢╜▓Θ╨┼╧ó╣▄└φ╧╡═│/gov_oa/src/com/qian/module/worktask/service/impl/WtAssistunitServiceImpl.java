package com.qian.module.worktask.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.gzdec.framework.page.Pagination;
import com.gzdec.framework.util.UniqueIDGenerator;

import com.qian.module.worktask.dao.WtAssistunitDao;
import com.qian.module.worktask.service.inter.WtAssistunitService;
import com.qian.util.StringUtils;

/**
 * @author twg
 */
@Service("wtAssistunitServiceImpl")
public class WtAssistunitServiceImpl implements WtAssistunitService{
	
	@Autowired
	private WtAssistunitDao wtAssistunitDao;
	
	public Map<String,Object> find(Map<String,Object> valueMap) {
		return this.wtAssistunitDao.find(valueMap);
	}
	
	public Map<String,Object> findById(Map<String,Object> valueMap) {
		String id = "";
		if(valueMap.get("at_assistunit_id") != null){
			id = valueMap.get("at_assistunit_id").toString().trim();
		}
		if("".equals(id)){
			return new HashMap<String,Object>();
		}
		return this.wtAssistunitDao.find(valueMap);
	}

	public List<Map<String,Object>> findAll(Map<String,Object> valueMap) {
		return this.wtAssistunitDao.findAll(valueMap);
	}

	public List<Map<String,Object>> findByPage(Map<String,Object> valueMap,Pagination pagination) {
		return this.wtAssistunitDao.findByPage(valueMap, pagination);
	}
	
	public int create(Map<String,Object> valueMap)  throws Exception{
		String id = "";
		if(valueMap.get("at_assistunit_id") != null){
			id = valueMap.get("at_assistunit_id").toString().trim();
		}
		if("".equals(id)){
			valueMap.put("at_assistunit_id", UniqueIDGenerator.getUUID());
		}
		return this.wtAssistunitDao.create(valueMap);
	}	

	public int modify(Map<String,Object> valueMap) throws Exception{
		if(valueMap.get("at_assistunit_id") != null){
			return this.wtAssistunitDao.modify(valueMap);
		}else{
			return -1;
		}
	}

	public int remove(Map<String,Object> valueMap) throws Exception{
//		String[] idArr = new String[1];
//		if(valueMap.get("ids") != null && valueMap.get("ids").toString().length() > 0){
//			if (valueMap.get("ids") instanceof String) {
//				idArr[0] = valueMap.get("ids").toString();
//			}else{
//		    		idArr = (String[]) valueMap.get("ids");
//			}
//			List<Map<String,Object>> list = new ArrayList<Map<String,Object>>();
//			String id = "";
//			Map<String,Object> toMap = new HashMap<String,Object>();
//			for(int i = 0; i < idArr.length; i++){
//				id = idArr[i];
//				toMap = new HashMap<String,Object>();
//				toMap.put("at_assistunit_id", id);
//				list.add(toMap);
//			}
//			return this.wtAssistunitDao.remove(list);
//		}else{
//			return -1;
//		}
		return this.wtAssistunitDao.remove(valueMap);
	}

	@Override
	public int createMore(Map<String, Object> valueMap) throws Exception {
		if(StringUtils.isNull(valueMap.get("at_dept_ids"))){return 0;}
		//部门任务安排表
		Map<String,Object> paramMap = new HashMap<String,Object>();
		paramMap.put("worktask_id",valueMap.get("worktask_id"));
		String at_dept_ids = valueMap.get("at_dept_ids").toString();//所有协办单位ID
		if(at_dept_ids.trim().length() == 32){//单个部门
			paramMap.put("at_assistunit_id",UniqueIDGenerator.getUUID());
			String at_tasks = valueMap.get("at_tasks").toString();
			paramMap.put("at_task", at_tasks);
			paramMap.put("at_dept_id", at_dept_ids);
			this.wtAssistunitDao.create(paramMap);
		}else{//多个部门
			String[] at_dept_ids_arr = (String[]) valueMap.get("at_dept_ids");
			String[] at_tasks_arr = (String[]) valueMap.get("at_tasks");
			for(int i=0;i<at_dept_ids_arr.length;i++){
				paramMap.put("at_assistunit_id",UniqueIDGenerator.getUUID());
				paramMap.put("at_task", at_tasks_arr[i]);
				paramMap.put("at_dept_id", at_dept_ids_arr[i]);
				this.wtAssistunitDao.create(paramMap);
			}
		}
		return 1;
	}

	@Override
	public int modifyMore(Map<String, Object> valueMap) throws Exception {
		if(StringUtils.isNull(valueMap.get("at_dept_ids"))){return 0;}
		Map<String,Object> tempMap = new HashMap<String,Object>();
		tempMap.put("worktask_id",valueMap.get("worktask_id"));
		List<Map<String,Object>> list = this.wtAssistunitDao.findAll(tempMap);
		boolean flag = true;
		Map<String,Object> paramMap = new HashMap<String,Object>();
		String at_dept_ids = valueMap.get("at_dept_ids").toString();//所有协办单位ID
		if(at_dept_ids.trim().length() == 32){
			if(list != null && list.size() > 0){
				for(Map<String,Object> map : list){
					if(at_dept_ids.equals(map.get("at_dept_id").toString())){
						flag = false;
					}
				}
			}
			if(flag){
				String at_tasks = valueMap.get("at_tasks").toString();
				paramMap.put("at_assistunit_id",UniqueIDGenerator.getUUID());
				paramMap.put("worktask_id",valueMap.get("worktask_id"));
				paramMap.put("at_task", at_tasks);
				paramMap.put("at_dept_id", at_dept_ids);
				this.wtAssistunitDao.create(paramMap);
			}
		}else{
			String[] at_dept_ids_arr = (String[]) valueMap.get("at_dept_ids");
			String[] at_tasks_arr = (String[]) valueMap.get("at_tasks");
			for(int i=0;i<at_dept_ids_arr.length;i++){
				flag = true;
				if(list != null && list.size() > 0){//存在则不允许修改
					for(Map<String,Object> map : list){
						if(at_dept_ids_arr[i].equals(map.get("at_dept_id").toString())){
							flag = false;
						}
					}
				}
				if(flag){
					paramMap.put("at_assistunit_id",UniqueIDGenerator.getUUID());
					paramMap.put("worktask_id",valueMap.get("worktask_id"));
					paramMap.put("at_task", at_tasks_arr[i]);
					paramMap.put("at_dept_id", at_dept_ids_arr[i]);
					this.wtAssistunitDao.create(paramMap);
				}
			}
		}
		return 1;
	}
	
	
	
	
	
	
	
	
	
}