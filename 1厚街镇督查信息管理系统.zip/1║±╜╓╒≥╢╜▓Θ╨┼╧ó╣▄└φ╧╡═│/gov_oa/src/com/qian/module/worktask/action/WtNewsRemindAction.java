package com.qian.module.worktask.action;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.gzdec.framework.page.Pagination;

import com.qian.module.common.action.BaseAction;
import com.qian.module.user.service.inter.SysUserService;
import com.qian.module.worktask.service.inter.WtAssistunitService;
import com.qian.module.worktask.service.inter.WtDeptTaskService;
import com.qian.module.worktask.service.inter.WtNewsRemindService;
import com.qian.module.worktask.service.inter.WtWorktaskService;
import com.qian.module.worktask.util.NewsRemindUtil;
import com.qian.util.FormMap;
import com.qian.util.ListUtils;
import com.qian.util.SessionUtil;
import com.qian.util.StringUtils;

/**
 * 描述：任务消息提醒管理
 * @author twg
 */
@Controller
@Scope("prototype")
@RequestMapping(value = "/pc/newsremind")
public class WtNewsRemindAction extends BaseAction{
	
	@Autowired
	private WtNewsRemindService wtNewsRemindService;
	@Autowired
	private WtDeptTaskService wtDeptTaskService;
	@Autowired
	private WtAssistunitService wtAssistunitService;
	@Autowired
	private WtWorktaskService wtWorktaskService;
	@Autowired
	private SysUserService sysUserService;
	
	/**
	 * To enter list
	 * @author twg
	 * @param formMap
	 * @param pagination
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/listByPage")
	public String listByPage(HttpServletRequest request,ModelMap map,FormMap formMap,Pagination p){
		if(StringUtils.isNull(formMap.getFormMap().get("wnr_is_read"))){
			formMap.getFormMap().put("wnr_is_read","N");
		}
		formMap.getFormMap().put("user_id",SessionUtil.getLoginUserId(request));
		formMap.getFormMap().put("rec_user_id",SessionUtil.getLoginUserId(request));
		List<Map<String, Object>> list =  this.wtNewsRemindService.findByPage(formMap.getFormMap(), null);
		List<Map<String, Object>> userMenuList = (List<Map<String, Object>>) request.getSession().getAttribute("user_menu");
		list = NewsRemindUtil.getDeptNewsRemind(wtNewsRemindService, list, userMenuList, formMap.getFormMap());//判断并加载所属部门的事项消息
		map.put("list",list);
		map.put("formMap",formMap.getFormMap());
		map.put("pagination",p);
//		return "worktask/wt_news_remind_list";
		return this.platformType(request, "worktask/wt_news_remind_list", "worktask/mobile/wt_news_remind_list");
	}
	
	/**
	 * 判断是否存在未阅读信息
	 * @param formMap
	 * @return
	 * @throws IOException
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/isHasMsg", method = RequestMethod.POST, produces = { "application/json;charset=UTF-8" })
	public  @ResponseBody Map<String,Object> isHasMsg(HttpServletRequest request,FormMap formMap,Pagination p) throws IOException {
		Map<String,Object> paramMap = new HashMap<String,Object>();
		formMap.getFormMap().put("wnr_is_read","N");
		formMap.getFormMap().put("user_id",SessionUtil.getLoginUserId(request));
		formMap.getFormMap().put("rec_user_id",SessionUtil.getLoginUserId(request));
		List<Map<String, Object>> list =  this.wtNewsRemindService.findByPage(formMap.getFormMap(), p);
		List<Map<String, Object>> userMenuList = (List<Map<String, Object>>) request.getSession().getAttribute("user_menu");
		list = NewsRemindUtil.getDeptNewsRemind(wtNewsRemindService, list, userMenuList, formMap.getFormMap());//判断并加载所属部门的事项消息
		if(list != null && list.size() > 0){
			paramMap.put("count", list.size());
			paramMap.put("result","Y");//未重复
		}else{
			paramMap.put("result","N");//未重复
		}
		return paramMap;
	}
	
	/**
	 * To enter edit
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/entryEdit")
	public String entryEdit(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map){
//		map.put("data",this.wtNewsRemindService.findById(formMap.getFormMap()));
		if(StringUtils.isNotNull(formMap.getFormMap().get("dt_dept_task_id"))){
			this.paramMap.put("dt_dept_task_id", formMap.getFormMap().get("dt_dept_task_id"));
		}else{
			this.paramMap.put("task_execution_id", formMap.getFormMap().get("task_execution_id"));
		}
		this.paramMap.put("wnr_type_level","Y");
		List<Map<String,Object>> list = this.wtNewsRemindService.findAll(this.paramMap);
		map.put("list", list);
		map.put("formMap", formMap.getFormMap());
//		return "worktask/wt_news_remind_edit";
		return this.platformType(request, "worktask/wt_news_remind_edit", "worktask/mobile/wt_news_remind_edit");
	}
	
	/**
	 * Creating
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/create")
	public String create(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map) throws Exception{
		if((StringUtils.isNotNull(formMap.getFormMap().get("dt_dept_task_id")) || StringUtils.isNotNull(formMap.getFormMap().get("task_execution_id")))
				&& StringUtils.isNotNull(formMap.getFormMap().get("wnr_type"))
				&& StringUtils.isNotNull(formMap.getFormMap().get("wnr_explain"))){
			formMap.getFormMap().put("wnr_mode", "A");
			formMap.getFormMap().put("wnr_user_id", SessionUtil.getLoginUserId(request));
			formMap.getFormMap().put("wnr_time", new Date());
			formMap.getFormMap().put("worktask_id", formMap.getFormMap().get("worktask_id"));
			this.wtNewsRemindService.create(formMap.getFormMap());
			request.getSession().setAttribute("nr_session_mark","CLOSE");
		}
//		return "redirect:/pc/newsremind/listByPage";
//		return "redirect:/pc/newsremind/entryEdit";
		return this.platformType(request, "redirect:/pc/newsremind/entryEdit", "redirect:/pc/worktask/entryView?formMap[worktask_id]="+formMap.getFormMap().get("worktask_id")+"&formMap[opt_mark]=approval");
	}
	
	/**
	 * Modifing
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/modify")
	public String modify(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map) throws Exception{
		this.wtNewsRemindService.modify(formMap.getFormMap());
		return "redirect:/pc/newsremind/listByPage";
	}
	
	/**
	 * Deleting
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/delete")
	public String delete(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map) throws Exception{
		this.wtNewsRemindService.remove(formMap.getFormMap());
		return "redirect:/pc/newsremind/listByPage";
	}
	

	/**
	 * To enter view
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/entryView")
	public String entryView(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map){
		map.put("data",this.wtNewsRemindService.findById(formMap.getFormMap()));
		return "worktask/wt_news_remind_view";
	}

	/**
	 * 设置消息已阅（同步）
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/modifyReadStatus")
	public String modifyReadStatus(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map) throws Exception{
		formMap.getFormMap().put("wnr_is_read","Y");
		this.wtNewsRemindService.modify(formMap.getFormMap());
		return "redirect:/pc/worktask/entryView?formMap[opt_mark]=mytask&formMap[worktask_id]="+formMap.getFormMap().get("worktask_id")+"&formMap[dept_id]="+formMap.getFormMap().get("dept_id")+"&formMap[task_arrange_id]="+formMap.getFormMap().get("task_arrange_id");
	}
	
	/**
	 * 设置消息已阅（异步）
	 * @param formMap
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = "/modifyReadToY", method = RequestMethod.POST, produces = { "application/json;charset=UTF-8" })
	public @ResponseBody Map<String,Object> modifyReadToY(FormMap formMap) throws IOException {
		Map<String,Object> paramMap = new HashMap<String,Object>();
		formMap.getFormMap().put("wnr_is_read","Y");
		try {
			this.wtNewsRemindService.modify(formMap.getFormMap());
		} catch (Exception e) {
		}
		return paramMap;
	}
	
	/**
	 * 批量设置消息已阅
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/updateReadStatusToBatch")
	public String updateReadStatusToBatch(HttpServletRequest request,FormMap formMap,ModelMap map) throws Exception{
		this.wtNewsRemindService.updateReadStatusToBatch(formMap.getFormMap());
		return "redirect:/pc/newsremind/listByPage";
	}
	
	/**
	 * 批量提醒/批量督办
	 * @param formMap
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = "/createBatchOpt", method = RequestMethod.POST, produces = { "application/json;charset=UTF-8" })
	public @ResponseBody Map<String,Object> createBatchOpt(HttpServletRequest request,FormMap formMap) throws IOException {
		Map<String,Object> paramMapA = new HashMap<String,Object>();
		if(StringUtils.isNotNull(formMap.getFormMap().get("worktask_ids")) && StringUtils.isNotNull(formMap.getFormMap().get("wnr_explain")) 
				&& StringUtils.isNotNull(formMap.getFormMap().get("wnr_type"))){
			String[] worktask_ids = formMap.getFormMap().get("worktask_ids").toString().split("-");
			Map<String,Object> createMap = new HashMap<String,Object>();
			List<Map<String,Object>> dtList = new ArrayList<Map<String,Object>>();
			Date currTime = new Date();
			for(String worktask_id : worktask_ids){
				this.paramMap.put("worktask_id", worktask_id.trim());
				this.paramMap.put("dt_is_cancel", "N");
				dtList = this.wtDeptTaskService.findAll(this.paramMap);
				if(ListUtils.isNotNull(dtList)){
					for(Map<String,Object> tempMap : dtList){
						createMap = new HashMap<String,Object>();
						createMap.put("dt_dept_task_id", tempMap.get("dt_dept_task_id"));
						createMap.put("wnr_type", formMap.getFormMap().get("wnr_type"));
						createMap.put("wnr_explain", formMap.getFormMap().get("wnr_explain"));
						createMap.put("wnr_user_id", SessionUtil.getLoginUserId(request));
						createMap.put("wnr_time", currTime);
						createMap.put("worktask_id", tempMap.get("worktask_id"));
						try {
							this.wtNewsRemindService.create(createMap);
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				}
			}
		}
		return paramMapA;
	}
	
	
	/**
	 * 向责任领导/主办单位/协办单位发送消息
	 * @param formMap
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = "/sendMsgToObj", method = RequestMethod.POST, produces = { "application/json;charset=UTF-8" })
	public @ResponseBody Map<String,Object> sendMsgToObj(HttpServletRequest request,FormMap formMap) throws IOException {
		Map<String,Object> paramMapA = new HashMap<String,Object>();
		if(StringUtils.isNotNull(formMap.getFormMap().get("worktask_id")) 
				&& StringUtils.isNotNull(formMap.getFormMap().get("wnr_explain"))
				&& StringUtils.isNotNull(formMap.getFormMap().get("send_obj")) 
				&& StringUtils.isNotNull(formMap.getFormMap().get("wnr_type"))){
			Map<String,Object> createMap = new HashMap<String,Object>();
			Date currTime = new Date();
			this.paramMap.put("worktask_id", formMap.getFormMap().get("worktask_id"));
			if(formMap.getFormMap().get("send_obj").toString().contains("A")){//主办单位
				List<Map<String,Object>> dtList = this.wtDeptTaskService.findAll(this.paramMap);
				if(ListUtils.isNotNull(dtList)){
					for(Map<String,Object> dtMap : dtList){
						createMap = new HashMap<String,Object>();
						createMap.put("worktask_id", formMap.getFormMap().get("worktask_id"));
						createMap.put("dt_dept_task_id", dtMap.get("dt_dept_task_id"));
						createMap.put("wnr_type", formMap.getFormMap().get("wnr_type"));
						createMap.put("wnr_explain", formMap.getFormMap().get("wnr_explain"));
						createMap.put("wnr_user_id", SessionUtil.getLoginUserId(request));
						createMap.put("wnr_time", currTime);
						try {
							this.wtNewsRemindService.create(createMap);
						} catch (Exception e) {
						}
					}
				}
			}
			if(formMap.getFormMap().get("send_obj").toString().contains("B")){//协办单位
				List<Map<String,Object>> aList = this.wtAssistunitService.findAll(this.paramMap);
				if(ListUtils.isNotNull(aList)){
					for(Map<String,Object> aMap : aList){
						createMap = new HashMap<String,Object>();
						createMap.put("worktask_id", formMap.getFormMap().get("worktask_id"));
						createMap.put("at_assistunit_id", aMap.get("at_assistunit_id"));
						createMap.put("wnr_type", formMap.getFormMap().get("wnr_type"));
						createMap.put("wnr_explain", formMap.getFormMap().get("wnr_explain"));
						createMap.put("wnr_user_id", SessionUtil.getLoginUserId(request));
						createMap.put("wnr_time", currTime);
						try {
							this.wtNewsRemindService.create(createMap);
						} catch (Exception e) {
						}
					}
				}
			}
			if(formMap.getFormMap().get("send_obj").toString().contains("C")){//责任领导
				Map<String,Object> wtMap = this.wtWorktaskService.findById(this.paramMap);
				if(StringUtils.isNotNull(wtMap.get("respon_leader"))){
					String[] responLeaders = wtMap.get("respon_leader").toString().replaceAll(" ", "").split(",");
					List<Map<String,Object>> userList = null;
					for(String rl : responLeaders){
						this.paramMap.put("real_name", rl);
						userList = this.sysUserService.findAll(this.paramMap);
						if(StringUtils.isNotNull(userList)){
							createMap = new HashMap<String,Object>();
							createMap.put("worktask_id", formMap.getFormMap().get("worktask_id"));
							createMap.put("rec_user_id", userList.get(0).get("user_id"));
							createMap.put("wnr_type", formMap.getFormMap().get("wnr_type"));
							createMap.put("wnr_explain", formMap.getFormMap().get("wnr_explain"));
							createMap.put("wnr_user_id", SessionUtil.getLoginUserId(request));
							createMap.put("wnr_time", currTime);
							try {
								this.wtNewsRemindService.create(createMap);
							} catch (Exception e) {
							}
						}
					}
				}
			}
		}
		return paramMapA;
	}
	
	/**
	 * 一键检查催报功能
	 * @param formMap
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = "/sendTipToAll", method = RequestMethod.POST, produces = { "application/json;charset=UTF-8" })
	public @ResponseBody Map<String,Object> sendTipToAll(HttpServletRequest request,FormMap formMap) throws IOException {
		Map<String,Object> paramMapA = new HashMap<String,Object>();
		try {
			this.wtNewsRemindService.createForAutomatic(null);
		} catch (Exception e) {
		}
		paramMapA.put("result", "Y");
		return paramMapA;
	}
}	