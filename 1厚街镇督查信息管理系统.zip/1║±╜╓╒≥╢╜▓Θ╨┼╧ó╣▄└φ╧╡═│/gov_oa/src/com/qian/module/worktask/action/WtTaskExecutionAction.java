package com.qian.module.worktask.action;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.gzdec.framework.page.Pagination;
import com.gzdec.framework.util.UniqueIDGenerator;

import com.qian.module.common.action.BaseAction;
import com.qian.module.worktask.dao.WtTaskExecutionDao;
import com.qian.module.worktask.service.inter.WtDeptScheduleService;
import com.qian.module.worktask.service.inter.WtTaskArrangeService;
import com.qian.module.worktask.service.inter.WtTaskExecutionService;
import com.qian.module.worktask.service.inter.WtTemporarySaveService;
import com.qian.module.worktask.service.inter.WtWorktaskService;
import com.qian.util.FormMap;
import com.qian.util.ListUtils;
import com.qian.util.SessionUtil;
import com.qian.util.StringUtils;
import com.qian.util.UploadFile;

/**
 * 描述：工作任务执行
 * @author twg
 */
@Controller
@Scope("prototype")
@RequestMapping(value = "/pc/taskexecution")
public class WtTaskExecutionAction extends BaseAction{
	
	@Autowired
	private WtTaskExecutionService wtTaskExecutionService;
	@Autowired
	private WtTaskExecutionDao wtTaskExecutionDao;
	@Autowired
	private WtTemporarySaveService wtTemporarySaveService;
	@Autowired
	private WtWorktaskService wtWorktaskService;
	@Autowired
	private WtTaskArrangeService wtTaskArrangeService;
	@Autowired
	private WtDeptScheduleService wtDeptScheduleService;
	
	/**
	 * To enter list
	 * @author twg
	 * @param formMap
	 * @param pagination
	 * @return
	 */
	@RequestMapping(value = "/listByPage")
	public String listByPage(HttpServletRequest request,HttpServletResponse response,ModelMap map,FormMap formMap,Pagination p){
		List<Map<String, Object>> list =  this.wtTaskExecutionService.findByPage(formMap.getFormMap(), p);
		map.put("list",list);
		map.put("formMap",formMap.getFormMap());
		map.put("pagination",p);
		return "worktask/wt_task_execution_list";
	}
	
	/**
	 * 上一次进度
	 * @author twg
	 * @param formMap
	 * @param pagination
	 * @return
	 */
	@RequestMapping(value = "/lastTime")
	public String lastTime(HttpServletRequest request,HttpServletResponse response,ModelMap map,FormMap formMap,Pagination p){
		List<Map<String, Object>> list =  this.wtTaskExecutionService.findByPage(formMap.getFormMap(), null);
		map.put("list",list);
		return "worktask/wt_task_execution_history";
	}
	
	/**
	 * To enter edit
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/entryEdit")
	public String entryEdit(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map){
		if(StringUtils.isNotNull(formMap.getFormMap().get("operation_source")) 
				&& "modify_new_schedule".equals(formMap.getFormMap().get("operation_source"))
				&& StringUtils.isNotNull(formMap.getFormMap().get("worktask_id_temp"))
				&& StringUtils.isNotNull(formMap.getFormMap().get("task_arrange_id_temp"))){
			this.paramMap.put("worktask_id", formMap.getFormMap().get("worktask_id_temp"));
			this.paramMap.put("task_arrange_id", formMap.getFormMap().get("task_arrange_id_temp"));
			List<Map<String,Object>> teList = this.wtTaskExecutionService.findAll(this.paramMap);
			if(ListUtils.isNotNull(teList)){
				Map<String,Object> teMap = teList.get(teList.size()-1);
				formMap.getFormMap().put("task_execution_id", teMap.get("task_execution_id"));
			}
		}
		map.put("data",this.wtTaskExecutionService.findById(formMap.getFormMap()));
//		return "worktask/wt_task_execution_edit";
		map.put("formMap", formMap.getFormMap());
		return this.platformType(request, "worktask/wt_task_execution_edit", "worktask/mobile/wt_task_execution_edit");
	}
	
	/**
	 * Creating
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/create")
	public String create(HttpServletRequest request,FormMap formMap,ModelMap map) throws Exception{
		if(StringUtils.isNotNull(formMap.getFormMap().get("worktask_id")) 
				&& StringUtils.isNotNull(formMap.getFormMap().get("task_arrange_id"))){
			this.ifDeptReport(formMap);
			formMap.getFormMap().put("task_execution_id",UniqueIDGenerator.getUUID());//任务执行ID
			formMap.getFormMap().put("id",formMap.getFormMap().get("task_execution_id"));
			UploadFile.uploadAttachment(request, formMap);
			formMap.getFormMap().put("execution_time",new Date());
			formMap.getFormMap().put("user_id",SessionUtil.getLoginUserId(request));
			int count = this.wtTaskExecutionService.create(formMap.getFormMap());
			if(count > 0){
				this.wtTemporarySaveService.removeByOther(formMap.getFormMap());
			}
			formMap.getFormMap().put("login_user_name", SessionUtil.getUserName(request));
//			this.wtTaskExecutionService.updateSchedule(formMap.getFormMap());
			this.wtTaskExecutionDao.updateAllSchedule(formMap.getFormMap());
		}
		return "redirect:/pc/taskarrange/mytask";
	}
	
	/**
	 * Modifing
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/modify")
	public String modify(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map) throws Exception{
//		formMap.getFormMap().put("update_user",SessionUtil.getLoginUserId(request));
		formMap.getFormMap().put("update_user",SessionUtil.getUserName(request));
		formMap.getFormMap().put("update_time",new Date());
		this.ifDeptReport(formMap);
		this.wtTaskExecutionService.modify(formMap.getFormMap());
		this.wtTaskExecutionDao.updateAllSchedule(formMap.getFormMap());//更新所有进度
		request.getSession().setAttribute("tee_session_mark","CLOSE");
		request.getSession().setAttribute("operation_source",formMap.getFormMap().get("operation_source"));
//		return "redirect:/pc/taskexecution/entryEdit";
		return this.platformType(request, "redirect:/pc/taskexecution/entryEdit", "redirect:/pc/taskarrange/mytask");
	}
	
	/**
	 * 判断部门管理员是否已上报当前时间节点进度，如已上报则此职员当前进度直接通过。
	 * @param formMap
	 */
	private void ifDeptReport(FormMap formMap){
		Map<String,Object> taskExecutionMap = null;
		if(StringUtils.isNotNull(formMap.getFormMap().get("task_execution_id"))){
			Map<String,Object> tempMap = new HashMap<String,Object>();
			tempMap.put("task_execution_id", formMap.getFormMap().get("task_execution_id"));
			taskExecutionMap = this.wtTaskExecutionService.findById(tempMap);
			formMap.getFormMap().put("task_arrange_id", taskExecutionMap.get("task_arrange_id"));
			formMap.getFormMap().put("submit_year", taskExecutionMap.get("submit_year"));
			formMap.getFormMap().put("submit_time", taskExecutionMap.get("submit_time"));
		}
		if(StringUtils.isNotNull(formMap.getFormMap().get("worktask_id")) && StringUtils.isNotNull(formMap.getFormMap().get("task_arrange_id"))
				&& StringUtils.isNotNull(formMap.getFormMap().get("submit_year")) && StringUtils.isNotNull(formMap.getFormMap().get("submit_time"))){
			this.paramMap.put("worktask_id", formMap.getFormMap().get("worktask_id"));
			Map<String,Object> wMap = this.wtWorktaskService.findById(this.paramMap);
			this.paramMap.put("task_arrange_id", formMap.getFormMap().get("task_arrange_id"));
			Map<String,Object> taMap = this.wtTaskArrangeService.findById(this.paramMap);
			if(!"E".equals(wMap.get("wt_opt_type").toString())){
				this.paramMap.put("dept_id", taMap.get("dept_id"));
				this.paramMap.put("ds_submit_year", formMap.getFormMap().get("submit_year"));
				this.paramMap.put("ds_submit_time", formMap.getFormMap().get("submit_time"));
				List<Map<String,Object>> list = this.wtDeptScheduleService.findAll(this.paramMap);
				if(ListUtils.isNotNull(list)){//部门管理员已上当前进度，则此职员当前进度直接通过。
					formMap.getFormMap().put("approval_status", "Y");
				}
			}
		}
	}
	
	/**
	 * 更新状态
	 * @param formMap
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/updateStatus", method = RequestMethod.POST, produces = { "application/json;charset=UTF-8" })
	public @ResponseBody Map<String,Object> updateStatus(HttpServletRequest request,FormMap formMap) throws Exception {
		if(StringUtils.isNotNull(formMap.getFormMap().get("task_execution_id"))){
			formMap.getFormMap().put("update_time",new Date());
//			formMap.getFormMap().put("update_user",SessionUtil.getLoginUserId(request));
			formMap.getFormMap().put("update_user",SessionUtil.getUserName(request));
			formMap.getFormMap().put("wnr_mode","A");//消息提醒参数
			formMap.getFormMap().put("wnr_user_id",SessionUtil.getLoginUserId(request));//消息提醒参数
			this.wtTaskExecutionService.modify(formMap.getFormMap());
			paramMap.put("result","Y");
		}else{
			paramMap.put("result","N");
		}
		return paramMap;
	}
	
	/**
	 * Deleting
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/delete")
	public String delete(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map) throws Exception{
		this.wtTaskExecutionService.remove(formMap.getFormMap());
		return "redirect:/pc/taskexecution/listByPage";
	}
	
	/**
	 * 异步删除数据（单个删除）
	 * @param formMap
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/asynchronousDelete", method = RequestMethod.POST, produces = { "application/json;charset=UTF-8" })
	public  @ResponseBody Map<String,Object> asynchronousDelete(FormMap formMap) throws Exception {
		Map<String,Object> resultMap = new HashMap<String,Object>();
		this.paramMap.put("task_execution_id", formMap.getFormMap().get("ids"));
		Map<String,Object> teMap = this.wtTaskExecutionService.findById(this.paramMap);
		this.wtTaskExecutionService.remove(formMap.getFormMap());
		//更新所有关联表进度
		this.wtTaskExecutionDao.updateAllSchedule(teMap);
		return resultMap;
	}
	
	/**
	 * To enter view
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/entryView")
	public String entryView(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map){
		
		return "worktask/wt_task_execution_view";
	}

	
	/**
	 * 协助完成
	 * @param formMap
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/assistOver", method = RequestMethod.POST, produces = { "application/json;charset=UTF-8" })
	public  @ResponseBody Map<String,Object> assistOver(FormMap formMap) throws Exception {
		Map<String,Object> paramMap = new HashMap<String,Object>();
		if(StringUtils.isNotNull(formMap.getFormMap().get("task_execution_id"))){
			this.paramMap.put("task_execution_id",formMap.getFormMap().get("task_execution_id"));
			this.paramMap.put("assist_status","B");
			this.wtTaskExecutionService.modify(this.paramMap);
		}
		return paramMap;
	}
	
}	