package com.qian.module.worktask.service.impl;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.gzdec.framework.page.Pagination;
import com.gzdec.framework.util.UniqueIDGenerator;

import com.qian.module.worktask.dao.WtTaskArrangeDao;
import com.qian.module.worktask.dao.WtTaskExecutionDao;
import com.qian.module.worktask.dao.WtWorktaskDao;
import com.qian.module.worktask.service.inter.WtAssistunitService;
import com.qian.module.worktask.service.inter.WtDeptScheduleService;
import com.qian.module.worktask.service.inter.WtDeptTaskService;
import com.qian.module.worktask.service.inter.WtWorktaskService;
import com.qian.util.DateTimeUtils;
import com.qian.util.ListUtils;
import com.qian.util.StringUtils;

/**
 * @author twg
 */
@Service("wtWorktaskServiceImpl")
public class WtWorktaskServiceImpl implements WtWorktaskService{
	
	@Autowired
	private WtWorktaskDao wtWorktaskDao;
	@Autowired
	private WtTaskArrangeDao wtTaskArrangeDao;
	@Autowired
	private WtTaskExecutionDao wtTaskExecutionDao;
	@Autowired
	private WtDeptTaskService wtDeptTaskService;
	@Autowired
	private WtAssistunitService wtAssistunitService;
	@Autowired
	private WtDeptScheduleService wtDeptScheduleService;
	
	public Map<String,Object> find(Map<String,Object> valueMap) {
		return this.wtWorktaskDao.find(valueMap);
	}
	
	public Map<String,Object> findById(Map<String,Object> valueMap) {
		String id = "";
		if(valueMap.get("worktask_id") != null){
			id = valueMap.get("worktask_id").toString().trim();
		}
		if("".equals(id)){
			return new HashMap<String,Object>();
		}
		return this.wtWorktaskDao.find(valueMap);
	}

	public List<Map<String,Object>> findAll(Map<String,Object> valueMap) {
		return this.wtWorktaskDao.findAll(valueMap);
	}

	public List<Map<String,Object>> findByPage(Map<String,Object> valueMap,Pagination pagination) {
		return this.wtWorktaskDao.findByPage(valueMap, pagination);
	}
	
	public int create(Map<String,Object> valueMap)  throws Exception{
		if(!StringUtils.isNotNull(valueMap.get("worktask_id"))){
			valueMap.put("worktask_id", UniqueIDGenerator.getUUID());
		}
		//任务表
		valueMap.put("task_num", DateTimeUtils.getNowDate("MMddHHmmss"));
		valueMap.put("launch_time", new Date());
		//部门任务安排表
		Map<String,Object> paramMap = new HashMap<String,Object>();
		String dept_ids = valueMap.get("dept_ids").toString();//所有部门ID
		if(dept_ids.trim().length() == 32){//单个部门
			String arrange_explains = valueMap.get("arrange_explains").toString();//所有执行说明
			String dt_start_time = valueMap.get("start_time").toString();//
			String dt_end_time = valueMap.get("end_time").toString();//
			String dt_attach_name = valueMap.get("dt_attach_name").toString();//
			String dt_attach_url = valueMap.get("dt_attach_url").toString();//
			String dt_respon_peoples = valueMap.get("dt_respon_peoples").toString();//
			paramMap.put("worktask_id", valueMap.get("worktask_id"));
			paramMap.put("dt_dept_task_id", UniqueIDGenerator.getUUID());
			paramMap.put("dept_id",dept_ids);
			paramMap.put("dt_task_explain",arrange_explains);
			paramMap.put("dt_start_time",dt_start_time);
			paramMap.put("dt_end_time",dt_end_time);
			paramMap.put("dt_attach_name",dt_attach_name);
			paramMap.put("dt_attach_url",dt_attach_url);
			paramMap.put("dt_respon_people",dt_respon_peoples);
			this.wtDeptTaskService.create(paramMap);
		}else{//多个部门
			String[] dept_ids_arr = (String[]) valueMap.get("dept_ids");
			String[] arrange_explains_arr = (String[]) valueMap.get("arrange_explains");
			String[] dt_start_time = (String[]) valueMap.get("start_time");
			String[] dt_end_time = (String[]) valueMap.get("end_time");
			String[] dt_attach_name = (String[]) valueMap.get("dt_attach_name");
			String[] dt_attach_url = (String[]) valueMap.get("dt_attach_url");
			String[] dt_respon_peoples = (String[]) valueMap.get("dt_respon_peoples");//
			for(int i=0;i<dept_ids_arr.length;i++){
				paramMap = new HashMap<String,Object>();
				paramMap.put("worktask_id", valueMap.get("worktask_id"));
				paramMap.put("dt_dept_task_id", UniqueIDGenerator.getUUID());
				paramMap.put("dept_id",dept_ids_arr[i]);
				paramMap.put("dt_task_explain",arrange_explains_arr[i]);
				paramMap.put("dt_start_time",dt_start_time[i]);
				paramMap.put("dt_end_time",dt_end_time[i]);
				paramMap.put("dt_attach_name",dt_attach_name[i]);
				paramMap.put("dt_attach_url",dt_attach_url[i]);
				paramMap.put("dt_respon_people",dt_respon_peoples[i]);
				this.wtDeptTaskService.create(paramMap);
			}
		}
		this.wtAssistunitService.createMore(valueMap);
		return this.wtWorktaskDao.create(valueMap);
	}	

	public int modify(Map<String,Object> valueMap) throws Exception{
		if(StringUtils.isNotNull(valueMap.get("worktask_id"))){
			return this.wtWorktaskDao.modify(valueMap);
		}else{
			return -1;
		}
	}

	public int remove(Map<String,Object> valueMap) throws Exception{
		String[] idArr = new String[1];
		if(valueMap.get("ids") != null && valueMap.get("ids").toString().length() > 0){
			if (valueMap.get("ids") instanceof String) {
				idArr[0] = valueMap.get("ids").toString();
			}else{
		    		idArr = (String[]) valueMap.get("ids");
			}
			List<Map<String,Object>> list = new ArrayList<Map<String,Object>>();
			String id = "";
			Map<String,Object> toMap = new HashMap<String,Object>();
			for(int i = 0; i < idArr.length; i++){
				id = idArr[i];
				toMap = new HashMap<String,Object>();
				toMap.put("worktask_id", id);
				list.add(toMap);
				this.wtTaskExecutionDao.removeByWorktaskId(toMap);
				this.wtTaskArrangeDao.remove(toMap);
				this.wtAssistunitService.remove(toMap);
				this.wtDeptTaskService.remove(toMap);
				this.wtDeptScheduleService.remove(toMap);
			}
			return this.wtWorktaskDao.remove(list);
		}else{
			return -1;
		}
	}

	@Override
	public int modifyAll(Map<String, Object> valueMap) throws Exception {
		if(StringUtils.isNotNull(valueMap.get("worktask_id"))){
			Map<String,Object> tempMap = new HashMap<String,Object>();
			tempMap.put("worktask_id",valueMap.get("worktask_id"));
			List<Map<String,Object>> list = this.wtDeptTaskService.findAll(tempMap);
			boolean flag = true;
			//部门任务安排表
			Map<String,Object> paramMap = new HashMap<String,Object>();
			String dept_ids = valueMap.get("dept_ids").toString();
			if(dept_ids.trim().length() == 32){
				if(list != null && list.size() > 0){
					for(Map<String,Object> map : list){
						if(dept_ids.trim().equals(map.get("dept_id").toString())){
							flag = false;
						}
					}
				}
				if(flag){
					String arrange_explains = valueMap.get("arrange_explains").toString();//所有执行说明
					String dt_start_time = valueMap.get("start_time").toString();//
					String dt_end_time = valueMap.get("end_time").toString();//
					String dt_attach_name = valueMap.get("dt_attach_name").toString();//
					String dt_attach_url = valueMap.get("dt_attach_url").toString();//
					String dt_respon_peoples = valueMap.get("dt_respon_peoples").toString();//
					paramMap.put("worktask_id", valueMap.get("worktask_id"));
					paramMap.put("dt_dept_task_id", UniqueIDGenerator.getUUID());
					paramMap.put("dept_id",dept_ids);
					paramMap.put("dt_task_explain",arrange_explains);
					paramMap.put("dt_start_time",dt_start_time);
					paramMap.put("dt_end_time",dt_end_time);
					paramMap.put("dt_attach_name",dt_attach_name);
					paramMap.put("dt_attach_url",dt_attach_url);
					paramMap.put("dt_respon_people",dt_respon_peoples);
					this.wtDeptTaskService.create(paramMap);
				}
			}else{
				String[] dept_ids_arr = (String[]) valueMap.get("dept_ids");
				String[] arrange_explains_arr = (String[]) valueMap.get("arrange_explains");
				String[] dt_start_time = (String[]) valueMap.get("start_time");
				String[] dt_end_time = (String[]) valueMap.get("end_time");
				String[] dt_attach_name = (String[]) valueMap.get("dt_attach_name");
				String[] dt_attach_url = (String[]) valueMap.get("dt_attach_url");
				String[] dt_respon_peoples = (String[]) valueMap.get("dt_respon_peoples");//
				for(int i=0;i<dept_ids_arr.length;i++){
					flag = true;
					if(list != null && list.size() > 0){//存在则不允许修改
						for(Map<String,Object> map : list){
							if(dept_ids_arr[i].trim().equals(map.get("dept_id").toString())){
								flag = false;
							}
						}
					}
					if(flag){
						paramMap = new HashMap<String,Object>();
						paramMap.put("worktask_id", valueMap.get("worktask_id"));
						paramMap.put("dt_dept_task_id", UniqueIDGenerator.getUUID());
						paramMap.put("dept_id",dept_ids_arr[i]);
						paramMap.put("dt_task_explain",arrange_explains_arr[i]);
						paramMap.put("dt_start_time",dt_start_time[i]);
						paramMap.put("dt_end_time",dt_end_time[i]);
						paramMap.put("dt_attach_name",dt_attach_name[i]);
						paramMap.put("dt_attach_url",dt_attach_url[i]);
						paramMap.put("dt_respon_people",dt_respon_peoples[i]);
						this.wtDeptTaskService.create(paramMap);
					}
				}
			}
			this.wtAssistunitService.modifyMore(valueMap);
			return this.wtWorktaskDao.modify(valueMap);
		}else{
			return -1;
		}
	}

	@Override
	public int modifyTotalSchedule(Map<String, Object> valueMap) throws Exception {
		if(StringUtils.isNotNull(valueMap.get("worktask_id"))){
			Map<String,Object> paramMap = new HashMap<String,Object>();
			paramMap.put("worktask_id",valueMap.get("worktask_id"));
			List<Map<String,Object>> list = this.wtTaskArrangeDao.findAll(paramMap);
			if(list != null && list.size() > 0){
				double total_schedule = 0;
				for(Map<String,Object> map : list){
					total_schedule += (Integer)map.get("schedule");
				}
				double result = total_schedule/list.size();
				result = Math.ceil(result);
				if(result >= 100){//大于100取100
					paramMap.put("total_schedule",100);
//					paramMap.put("task_status","C");//已完成/已完成
				}else if(result < 1){//小于1取1
					paramMap.put("total_schedule",1);
				}else{
					paramMap.put("total_schedule",result);
				}
				this.wtWorktaskDao.modify(paramMap);
			}
		}
		return 0;
	}

	@Override
	public List<Map<String, Object>> findAllWorkTask(Map<String, Object> valueMap, Pagination pagination) {
		return this.wtWorktaskDao.queryAllWorkTask(valueMap, pagination);
	}

	@Override
	public List<Map<String, Object>> findDeptTask(Map<String, Object> valueMap,Pagination pagination) {
		return this.wtWorktaskDao.queryDeptTask(valueMap, pagination);
	}

	@Override
	public List<Map<String, Object>> findProjectStatistics(Map<String, Object> valueMap) {
		return this.wtWorktaskDao.queryProjectStatistics(valueMap);
	}

	@SuppressWarnings("static-access")
	@Override
	public Map<String, Object> setUnfinishedTime(Map<String, Object> valueMap,String type) {
		Map<String, Object> resultMap = new HashMap<String, Object>();
		Map<String,Object> paramMap = new HashMap<String,Object>();
		paramMap.put("worktask_id", valueMap.get("worktask_id"));
		Map<String,Object> w = this.findById(paramMap);
		if(StringUtils.isNotNull(w.get("wt_opt_type"))){
			Calendar c = Calendar.getInstance();
			int year = c.get(Calendar.YEAR);//当前年份
			int month = c.get(Calendar.MONTH)+1;//当前月份
			int day = c.get(Calendar.DATE);//当前日
			int week = c.get(c.WEEK_OF_YEAR);//当前周
			int whichweek = c.get(Calendar.DAY_OF_WEEK)-1;//当前星期
			if("A".equals(w.get("wt_opt_type").toString())){//每月报
				resultMap.put("wt_opt_type", "A");
				List<Map<String,Object>> list = null;
				if("DEPT".equals(type)){
					valueMap.put("ds_submit_year",year);
					valueMap.put("ds_submit_time",month);
					list = this.wtDeptScheduleService.findAll(valueMap);
				}else{
					valueMap.put("submit_year",year);
					valueMap.put("submit_time",month);
					list = this.wtTaskExecutionDao.findAll(valueMap);
				}
				if(ListUtils.isNotNull(list)){//已报送
					resultMap.put("result", "N");
				}else if(day < 20){//未到报送时间
					resultMap.put("result", "O");
				}else{//未报送
					resultMap.put("result", "Y");
				}
			}else if("B".equals(w.get("wt_opt_type").toString())){//次月报
				resultMap.put("wt_opt_type", "B");
				if(month == 1){
					year = year-1;
					month = 12;
				}else{
					month = month-1;
				}
				List<Map<String,Object>> list = null;
				if("DEPT".equals(type)){
					valueMap.put("ds_submit_year",year);
					valueMap.put("ds_submit_time",month);
					list = this.wtDeptScheduleService.findAll(valueMap);
				}else{
					valueMap.put("submit_year",year);
					valueMap.put("submit_time",month);
					list = this.wtTaskExecutionDao.findAll(valueMap);
				}
				if(ListUtils.isNotNull(list)){//已报送
					resultMap.put("result", "N");
				}else if(day < 20){//未到报送时间
					resultMap.put("result", "O");
				}else{//未报送
					resultMap.put("result", "Y");
				}
			}else if("C".equals(w.get("wt_opt_type").toString())){//每周报
				resultMap.put("wt_opt_type", "C");
				List<Map<String,Object>> list = null;
				if("DEPT".equals(type)){
					valueMap.put("ds_submit_year",year);
					valueMap.put("ds_submit_time",week);
					list = this.wtDeptScheduleService.findAll(valueMap);
				}else{
					valueMap.put("submit_year",year);
					valueMap.put("submit_time",week);
					list = this.wtTaskExecutionDao.findAll(valueMap);
				}
				if(ListUtils.isNotNull(list)){//已报送
					resultMap.put("result", "N");
				}else if(whichweek >= 1 && whichweek < 4){//未到报送时间
					resultMap.put("result", "O");
				}else{//未报送
					resultMap.put("result", "Y");
				}
			}else if("D".equals(w.get("wt_opt_type").toString())){//次周报
				resultMap.put("wt_opt_type", "D");
				if(week == 1){
					year = year-1;
					week=52;
				}else{
					week=week-1;
				}
				List<Map<String,Object>> list = null;
				if("DEPT".equals(type)){
					valueMap.put("ds_submit_year",year);
					valueMap.put("ds_submit_time",week);
					list = this.wtDeptScheduleService.findAll(valueMap);
				}else{
					valueMap.put("submit_year",year);
					valueMap.put("submit_time",week);
					list = this.wtTaskExecutionDao.findAll(valueMap);
				}
				if(ListUtils.isNotNull(list)){//已报送
					resultMap.put("result", "N");
				}else if(whichweek >= 1 && whichweek < 4){//未到报送时间
					resultMap.put("result", "O");
				}else{//未报送
					resultMap.put("result", "Y");
				}
			}else if("E".equals(w.get("wt_opt_type").toString())){//日报
				resultMap.put("wt_opt_type", "E");
			}
			resultMap.put("year", year);//本次需要报送的年份
			resultMap.put("month", month);//本次需要报送的月份
			resultMap.put("week", week);//本次需要报送的周
		}
		return resultMap;
	}

	@Override
	public List<Map<String, Object>> findScheduleEvaluate(
			Map<String, Object> valueMap) {
		return this.wtWorktaskDao.queryScheduleEvaluate(valueMap);
	}
	
	
	
	
}