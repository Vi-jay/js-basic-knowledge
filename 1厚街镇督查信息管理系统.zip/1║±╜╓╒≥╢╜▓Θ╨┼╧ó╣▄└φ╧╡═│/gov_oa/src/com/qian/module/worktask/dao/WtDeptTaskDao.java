package com.qian.module.worktask.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Service;
import com.gzdec.framework.dao.SqlMapBaseDao;
import com.gzdec.framework.page.Pagination;

/**
 * @author twg
 */
@Service
public class WtDeptTaskDao extends SqlMapBaseDao{
	/**
	 * Query List
	 * @author twg
	 * @param valueMap
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<Map<String,Object>> findAll(Map<String,Object> to){
		return this.queryForList("worktask.wtDeptTask.query", to);
	}
	
	/**
	 * Query Page List
	 * @author twg
	 * @param valueMap
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<Map<String,Object>> findByPage(Map<String,Object> to,Pagination pagination){
		return this.queryForList("worktask.wtDeptTask.query", to, pagination);
	}
	
	/**
	 * Get A Record
	 * @author twg
	 * @param to
	 * @return
	 */
	@SuppressWarnings("unchecked")	 
	public Map<String,Object> find(Map<String,Object> to){
		return (Map<String,Object>)this.queryForObject("worktask.wtDeptTask.query", to);
	}
	
	/**
	 * Creating
	 * @author twg
	 * @param to
	 * @return
	 */
	public int create(Map<String,Object> to) throws Exception{
		this.insert("worktask.wtDeptTask.create", to);
		return 1;
	}
	
	/**
	 * Modify
	 * @author twg
	 * @param to
	 * @return
	 */
	public int modify(Map<String,Object> to) throws Exception{
//		if(StringUtils.isNull(to.get("dt_problem_explain"))){
//			to.put("dt_problem_explain", "暂无");
//		}
		return this.update("worktask.wtDeptTask.modify", to);
	}
	
	/**
	 * Deleting
	 * @author twg
	 * @param to
	 * @return
	 */
	public int remove(Map<String,Object> to) throws Exception{
		List<Map<String,Object>> list = new ArrayList<Map<String,Object>>();
		list.add(to);
		return this.remove(list);
	}
	
	/**
	 * Deleting List
	 * @author twg
	 * @param list
	 * @return
	 */
	public int remove(List<Map<String,Object>> list){
		int count = 0;
		if(null == list || list.size() <= 0){
		    return count;
		}
		for(int i = 0; i < list.size(); i++){
		    Map<String,Object> to = list.get(i);
		    count += this.delete("worktask.wtDeptTask.remove", to);
		}
		return count;
	}

	/**
	 * 根据部门ID查询该部门事项信息
	 * @author twg
	 * @param valueMap
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<Map<String,Object>> queryByDeptId(Map<String,Object> to,Pagination pagination){
		return this.queryForList("worktask.wtDeptTask.queryByDeptId", to, pagination);
	}

	/**
	 * 更新部门进度
	 * @author twg
	 * @param to
	 * @return
	 */
	public int updateSchedule(Map<String,Object> to) throws Exception{
		return this.update("worktask.wtDeptTask.updateSchedule", to);
	}
	/**
	 * 部门任务完成率统计报表
	 * @author twg
	 * @param valueMap
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<Map<String,Object>> queryDeptTaskStatistics(Map<String,Object> to){
		return this.queryForList("worktask.wtDeptTask.queryDeptTaskStatistics", to);
	}

	
	/**
	 * 事项计划图表
	 * @author twg
	 * @param valueMap
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<Map<String,Object>> queryForChart(Map<String,Object> to){
		return this.queryForList("worktask.wtDeptTask.queryForChart", to);
	}
	
	
	/**
	 * 查询部门未报送的事项（消息提醒推送）
	 * @author twg
	 * @param valueMap
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<Map<String,Object>> queryUnfinishedProject(Map<String,Object> to){
		return this.queryForList("worktask.wtDeptTask.queryUnfinishedProject", to);
	}
}