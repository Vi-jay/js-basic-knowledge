package com.qian.module.worktask.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Service;
import com.gzdec.framework.dao.SqlMapBaseDao;
import com.gzdec.framework.page.Pagination;

/**
 * @author twg
 */
@Service
public class WtWorktaskDao extends SqlMapBaseDao{
	/**
	 * Query List
	 * @author twg
	 * @param valueMap
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<Map<String,Object>> findAll(Map<String,Object> to){
		return this.queryForList("worktask.wtWorktask.query", to);
	}
	
	/**
	 * Query Page List
	 * @author twg
	 * @param valueMap
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<Map<String,Object>> findByPage(Map<String,Object> to,Pagination pagination){
		return this.queryForList("worktask.wtWorktask.query", to, pagination);
	}
	
	/**
	 * Get A Record
	 * @author twg
	 * @param to
	 * @return
	 */
	@SuppressWarnings("unchecked")	 
	public Map<String,Object> find(Map<String,Object> to){
		return (Map<String,Object>)this.queryForObject("worktask.wtWorktask.query", to);
	}
	
	/**
	 * Creating
	 * @author twg
	 * @param to
	 * @return
	 */
	public int create(Map<String,Object> to) throws Exception{
		this.insert("worktask.wtWorktask.create", to);
		return 1;
	}
	
	/**
	 * Modify
	 * @author twg
	 * @param to
	 * @return
	 */
	public int modify(Map<String,Object> to) throws Exception{
		return this.update("worktask.wtWorktask.modify", to);
	}
	
	/**
	 * Deleting
	 * @author twg
	 * @param to
	 * @return
	 */
	public int remove(Map<String,Object> to) throws Exception{
		List<Map<String,Object>> list = new ArrayList<Map<String,Object>>();
		list.add(to);
		return this.remove(list);
	}
	
	/**
	 * Deleting List
	 * @author twg
	 * @param list
	 * @return
	 */
	public int remove(List<Map<String,Object>> list){
		int count = 0;
		if(null == list || list.size() <= 0){
		    return count;
		}
		for(int i = 0; i < list.size(); i++){
		    Map<String,Object> to = list.get(i);
		    count += this.delete("worktask.wtWorktask.remove", to);
		}
		return count;
	}

	/**
	 * 查询全部工作任务
	 * @author twg
	 * @param valueMap
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<Map<String,Object>> queryAllWorkTask(Map<String,Object> to,Pagination pagination){
		return this.queryForList("worktask.wtWorktask.queryAllWorkTask", to, pagination);
	}

	/**
	 * 根据部门ID查询部门所有任务
	 * @author twg
	 * @param valueMap
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<Map<String,Object>> queryDeptTask(Map<String,Object> to,Pagination pagination){
		return this.queryForList("worktask.wtWorktask.queryDeptTask", to, pagination);
	}

	/**
	 * 事项类型统计报表
	 * @author twg
	 * @param valueMap
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<Map<String,Object>> queryProjectStatistics(Map<String,Object> to){
		return this.queryForList("worktask.wtWorktask.queryProjectStatistics", to);
	}
	
	/**
	 * 进度评价统计报表
	 * @author twg
	 * @param valueMap
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<Map<String,Object>> queryScheduleEvaluate(Map<String,Object> to){
		return this.queryForList("worktask.wtWorktask.queryScheduleEvaluate", to);
	}
}