package com.qian.module.worktask.action;

import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import com.gzdec.framework.page.Pagination;

import com.qian.module.worktask.service.inter.WtDeptScheduleService;
import com.qian.util.FormMap;

/**
 * 描述：部门任务进度
 * @author twg
 */
@Controller
@Scope("prototype")
@RequestMapping(value = "/pc/deptschedule")
public class WtDeptScheduleAction{
	
	@Autowired
	private WtDeptScheduleService wtDeptScheduleService;
	
	/**
	 * To enter list
	 * @author twg
	 * @param formMap
	 * @param pagination
	 * @return
	 */
	@RequestMapping(value = "/listByPage")
	public String listByPage(HttpServletRequest request,ModelMap map,FormMap formMap,Pagination p){
		List<Map<String, Object>> list =  this.wtDeptScheduleService.findByPage(formMap.getFormMap(), p);
		map.put("list",list);
		map.put("formMap",formMap.getFormMap());
		map.put("pagination",p);
		return "worktask/wt_dept_schedule_list";
	}
	
	/**
	 * To enter edit
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/entryEdit")
	public String entryEdit(HttpServletRequest request,FormMap formMap,ModelMap map){
		map.put("data",this.wtDeptScheduleService.findById(formMap.getFormMap()));
		return "worktask/wt_dept_schedule_edit";
	}
	
	/**
	 * Creating
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/create")
	public String create(HttpServletRequest request,FormMap formMap,ModelMap map) throws Exception{
		this.wtDeptScheduleService.create(formMap.getFormMap());
		return "redirect:/pc/deptschedule/listByPage";
	}
	
	/**
	 * Modifing
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/modify")
	public String modify(HttpServletRequest request,FormMap formMap,ModelMap map) throws Exception{
		this.wtDeptScheduleService.modify(formMap.getFormMap());
		return "redirect:/pc/deptschedule/listByPage";
	}
	
	/**
	 * Deleting
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/delete")
	public String delete(HttpServletRequest request,FormMap formMap,ModelMap map) throws Exception{
		this.wtDeptScheduleService.remove(formMap.getFormMap());
		return "redirect:/pc/deptschedule/listByPage";
	}
	

	/**
	 * To enter view
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/entryView")
	public String entryView(HttpServletRequest request,FormMap formMap,ModelMap map){
		map.put("data",this.wtDeptScheduleService.findById(formMap.getFormMap()));
		return "worktask/wt_dept_schedule_view";
	}

}	