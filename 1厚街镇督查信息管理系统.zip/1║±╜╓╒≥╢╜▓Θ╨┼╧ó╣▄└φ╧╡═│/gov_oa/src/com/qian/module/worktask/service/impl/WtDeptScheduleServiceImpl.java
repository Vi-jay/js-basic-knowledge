package com.qian.module.worktask.service.impl;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.gzdec.framework.page.Pagination;
import com.gzdec.framework.util.UniqueIDGenerator;

import com.qian.module.worktask.dao.WtDeptScheduleDao;
import com.qian.module.worktask.service.inter.WtDeptScheduleService;
import com.qian.module.worktask.util.GetCycleListUtil;
import com.qian.util.ListUtils;
import com.qian.util.StringUtils;

/**
 * @author twg
 */
@Service("wtDeptScheduleServiceImpl")
public class WtDeptScheduleServiceImpl implements WtDeptScheduleService{
	
	@Autowired
	private WtDeptScheduleDao wtDeptScheduleDao;
	
	public Map<String,Object> find(Map<String,Object> valueMap) {
		return this.wtDeptScheduleDao.find(valueMap);
	}
	
	public Map<String,Object> findById(Map<String,Object> valueMap) {
		String id = "";
		if(valueMap.get("ds_id") != null){
			id = valueMap.get("ds_id").toString().trim();
		}
		if("".equals(id)){
			return new HashMap<String,Object>();
		}
		return this.wtDeptScheduleDao.find(valueMap);
	}

	public List<Map<String,Object>> findAll(Map<String,Object> valueMap) {
		return this.wtDeptScheduleDao.findAll(valueMap);
	}

	public List<Map<String,Object>> findByPage(Map<String,Object> valueMap,Pagination pagination) {
		return this.wtDeptScheduleDao.findByPage(valueMap, pagination);
	}
	
	public int create(Map<String,Object> valueMap)  throws Exception{
		String id = "";
		if(valueMap.get("ds_id") != null){
			id = valueMap.get("ds_id").toString().trim();
		}
		if("".equals(id)){
			valueMap.put("ds_id", UniqueIDGenerator.getUUID());
		}
		return this.wtDeptScheduleDao.create(valueMap);
	}	

	public int modify(Map<String,Object> valueMap) throws Exception{
		if(valueMap.get("ds_id") != null){
			return this.wtDeptScheduleDao.modify(valueMap);
		}else{
			return -1;
		}
	}

	public int remove(Map<String,Object> valueMap) throws Exception{
//		String[] idArr = new String[1];
//		if(valueMap.get("ids") != null && valueMap.get("ids").toString().length() > 0){
//			if (valueMap.get("ids") instanceof String) {
//				idArr[0] = valueMap.get("ids").toString();
//			}else{
//		    		idArr = (String[]) valueMap.get("ids");
//			}
//			List<Map<String,Object>> list = new ArrayList<Map<String,Object>>();
//			String id = "";
//			Map<String,Object> toMap = new HashMap<String,Object>();
//			for(int i = 0; i < idArr.length; i++){
//				id = idArr[i];
//				toMap = new HashMap<String,Object>();
//				toMap.put("ds_id", id);
//				list.add(toMap);
//			}
//			return this.wtDeptScheduleDao.remove(list);
//		}else{
//			return -1;
//		}
		return this.wtDeptScheduleDao.remove(valueMap);
	}

	@Override
	public List<Map<String, Object>> getReportingPeriod(Map<String, Object> deptTaskMap) {
		if(StringUtils.isNotNull(deptTaskMap.get("worktask_id"))){
			List<Map<String,Object>> rList = GetCycleListUtil.getAllTime((Date)deptTaskMap.get("dt_change_stime"),(Date)deptTaskMap.get("dt_change_etime"),deptTaskMap.get("wt_opt_type").toString());
			Map<String,Object> paramMap = new HashMap<String,Object>();
			paramMap.put("worktask_id", deptTaskMap.get("worktask_id"));
			paramMap.put("dt_dept_task_id", deptTaskMap.get("dt_dept_task_id"));
			paramMap.put("dept_id", deptTaskMap.get("dept_id"));
			List<Map<String,Object>> teList = this.wtDeptScheduleDao.findAll(paramMap);
			if(ListUtils.isNotNull(rList)){
				if(ListUtils.isNotNull(teList)){
					for(Map<String,Object> rMap : rList){
						for(Map<String,Object> teMap : teList){
							if(rMap.get("year").toString().equals(teMap.get("ds_submit_year").toString()) && rMap.get("date").toString().equals(teMap.get("ds_submit_time").toString())){
								rMap.put("is_submit", "Y");//本周期已填报
							}
						}
					}
				}
				return rList; 
			}
		}
		return null;
	}
	
	
}