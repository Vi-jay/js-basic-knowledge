package com.qian.module.worktask.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Service;
import com.gzdec.framework.dao.SqlMapBaseDao;
import com.gzdec.framework.page.Pagination;

/**
 * @author twg
 */
@Service
public class WtAssistunitDao extends SqlMapBaseDao{
	/**
	 * Query List
	 * @author twg
	 * @param valueMap
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<Map<String,Object>> findAll(Map<String,Object> to){
		return this.queryForList("worktask.wtAssistunit.query", to);
	}
	
	/**
	 * Query Page List
	 * @author twg
	 * @param valueMap
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<Map<String,Object>> findByPage(Map<String,Object> to,Pagination pagination){
		return this.queryForList("worktask.wtAssistunit.query", to, pagination);
	}
	
	/**
	 * Get A Record
	 * @author twg
	 * @param to
	 * @return
	 */
	@SuppressWarnings("unchecked")	 
	public Map<String,Object> find(Map<String,Object> to){
		return (Map<String,Object>)this.queryForObject("worktask.wtAssistunit.query", to);
	}
	
	/**
	 * Creating
	 * @author twg
	 * @param to
	 * @return
	 */
	public int create(Map<String,Object> to) throws Exception{
		this.insert("worktask.wtAssistunit.create", to);
		return 1;
	}
	
	/**
	 * Modify
	 * @author twg
	 * @param to
	 * @return
	 */
	public int modify(Map<String,Object> to) throws Exception{
		return this.update("worktask.wtAssistunit.modify", to);
	}
	
	/**
	 * Deleting
	 * @author twg
	 * @param to
	 * @return
	 */
	public int remove(Map<String,Object> to) throws Exception{
		List<Map<String,Object>> list = new ArrayList<Map<String,Object>>();
		list.add(to);
		return this.remove(list);
	}
	
	/**
	 * Deleting List
	 * @author twg
	 * @param list
	 * @return
	 */
	public int remove(List<Map<String,Object>> list){
		int count = 0;
		if(null == list || list.size() <= 0){
		    return count;
		}
		for(int i = 0; i < list.size(); i++){
		    Map<String,Object> to = list.get(i);
		    count += this.delete("worktask.wtAssistunit.remove", to);
		}
		return count;
	}






}