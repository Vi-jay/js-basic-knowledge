package com.qian.module.worktask.action;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.qian.module.common.action.BaseAction;
import com.qian.module.worktask.service.inter.WtNewsRemindService;

/**
 * 进度填报定时提醒
 * @author Administrator
 */
@Service
public class TaskReminderAction extends BaseAction{
	
	@Autowired
	private WtNewsRemindService wtNewsRemindService;
	
	/**
	 * 每天九点钟统计事项进展情况，并执行消息推送
	 * 部门进度填报提醒
	 */
	public void deptTask() {
		try {
			this.wtNewsRemindService.createForAutomatic(null);
		} catch (Exception e) {
		}
    }
	
	/**
	 * 职员进度填报提醒
	 */
	public void userTask() {
		
    }

}