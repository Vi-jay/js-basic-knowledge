package com.qian.module.worktask.service.inter;

import java.util.List;
import java.util.Map;
import com.gzdec.framework.page.Pagination;

/**
 * @author twg
 */
public interface WtDeptScheduleService {

	/**
	 * Query List
	 * @author twg
	 * @param valueMap
	 * @return
	 */
	public List<Map<String,Object>> findAll(Map<String,Object> valueMap);
	
	/**
	 * Query Page List
	 * @author twg
	 * @param valueMap
	 * @return
	 */
	public List<Map<String,Object>> findByPage(Map<String,Object> valueMap,Pagination pagination);
	
	/**
	 * Get A Record
	 * @author twg
	 * @param valueMap
	 * @return
	 */
	public Map<String,Object> find(Map<String,Object> valueMap);
	
	/**
	 * Get A Record
	 * @author twg
	 * @param valueMap
	 * @return
	 */
	public Map<String,Object> findById(Map<String,Object> valueMap);
	
	/**
	 * Creating
	 * @author twg
	 * @param valueMap
	 * @return
	 */
	public int create(Map<String,Object> valueMap) throws Exception;	
	
	/**
	 * Modifing
	 * @author twg
	 * @param valueMap
	 * @return
	 */
	public int modify(Map<String,Object> valueMap) throws Exception;	
	
	/**
	 * Deleting
	 * @author twg
	 * @param valueMap
	 * @return
	 */
	public int remove(Map<String,Object> valueMap) throws Exception;

	/**
	 * 获取进度填写周期列表
	 * @author twg
	 * @param valueMap
	 * @return
	 */
	public List<Map<String,Object>> getReportingPeriod(Map<String, Object> deptTaskMap);




}