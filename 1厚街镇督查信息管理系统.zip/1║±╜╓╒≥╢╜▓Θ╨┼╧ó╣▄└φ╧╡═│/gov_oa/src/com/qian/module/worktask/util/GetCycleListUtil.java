package com.qian.module.worktask.util;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.qian.util.DateCalculationUtils;
import com.qian.util.DateTimeUtils;
import com.qian.util.ListUtils;
import com.qian.util.StringUtils;

public class GetCycleListUtil {
	
	/**获取项目从始至今所有周期*/
	@SuppressWarnings("static-access")
	public static List<Map<String,Object>> getAllTime(Date startTime,Date endTime,String type){
		Calendar c = Calendar.getInstance();
		if(endTime != null && DateCalculationUtils.getTwoDay(DateTimeUtils.getDateForFormat(new Date(), "yyyy-MM-dd"), DateTimeUtils.getDateForFormat(endTime, "yyyy-MM-dd")) > 0){
			c.setTime(endTime);//
		}
		int year = c.get(Calendar.YEAR);//当前年份
		int month = c.get(Calendar.MONTH)+1;//当前月份
		int day = c.get(Calendar.DATE);//当前日
		int week = c.get(c.WEEK_OF_YEAR);//当前周
		int whichweek = c.get(Calendar.DAY_OF_WEEK)-1;//当前星期
		
		
		Calendar cal = Calendar.getInstance();
        cal.setTime(startTime);
        int project_year = cal.get(Calendar.YEAR);//任务开始年份
        int project_month = cal.get(Calendar.MONTH)+1;//任务开始月份
		int project_week = cal.get(Calendar.WEEK_OF_YEAR);//任务开始周
//		int project_day = cal.get(Calendar.DATE);//任务开始日
//		System.out.println("开始月份:"+project_month);
//		System.out.println("当前月份:"+month);
//		System.out.println("开始周:"+project_week);
//		System.out.println("当前周:"+week);
//		System.out.println("类型:"+type);
		
		if(c.getTimeInMillis() > cal.getTimeInMillis()){
			List<Map<String,Object>> resultList = new ArrayList<Map<String,Object>>();
			if("A".equals(type) || "B".equals(type)){//获取从始至今的周期列表
				Map<String,Object> tempMap = null;
				int y = (year-project_year)+1;//年份差
				int m = 1;
				int start_m = 0;
				for(int i=0;i<y;i++){//年
					
					if(i==0){//第一年从项目开始月份开始
						start_m = project_month;
					}else{//其他年份从1月开始
						start_m = 1;
					}
					
					if(i == y-1){//今年在当前月截至
						m = month;
					}else{//今年之前的年份到12月份截至
						m = 12;
					}
					
					for(int j=start_m;j<=m;j++){//月
						if(i == y-1 && j==m && day < 20 && "B".equals(type)){//今年、当前月、小于20号、次月报
						}else{
							tempMap = new HashMap<String,Object>();
							tempMap.put("year",project_year+i);
							tempMap.put("date",j);
							resultList.add(tempMap);
						}
					}
				}
			}else if("C".equals(type) || "D".equals(type)){//获取从始至今的周期列表
				Map<String,Object> tempMap = null;
				int y = (year-project_year)+1;//年份差
				int w = 1;
				int start_w = 0;
				for(int i=0;i<y;i++){//年
					if(i==0){//第一年
						start_w = project_week;//第一年(次周开始)
					}else{start_w = 1;}//其他年份
					
					if(i == y-1){
						w = week;
					}else{w = 52;}
					
					for(int j=start_w;j<=w;j++){//周
						if(i == y-1 && j==w && whichweek >= 1 && whichweek < 4 && "D".equals(type)){
						}else{
							tempMap = new HashMap<String,Object>();
							tempMap.put("year",project_year+i);
							tempMap.put("date",j);
							resultList.add(tempMap);
						}
					}
				}
			}
			return resultList;
		}else{
			return new ArrayList<Map<String,Object>>();
		}
	}
	
	
	public static List<Map<String,Object>> getUnfinishedDate(List<Map<String,Object>> list){
		if(ListUtils.isNotNull(list)){
			StringBuffer buffer = null;
			List<Map<String,Object>> tempList = null;//当前项目所有日期
			String[] finishDateStr = null;//已完成时间
			String[] finishDate = null;
			boolean flag = true;
			for(Map<String,Object> map : list){
				buffer = new StringBuffer();
				if(!"E".equals(map.get("wt_opt_type").toString())){
					tempList = GetCycleListUtil.getAllTime((Date)map.get("dt_start_time"),(Date)map.get("dt_end_time"), map.get("wt_opt_type").toString());//当前项目所有日期
					if(ListUtils.isNotNull(tempList) && StringUtils.isNotNull(map.get("history_dept_schedule"))){
						finishDateStr = map.get("history_dept_schedule").toString().split(",");//已完成时间
						for(Map<String,Object> tempMap : tempList){//所有日期
							flag = true;
							for(String fds : finishDateStr){//已完成日期
								finishDate = fds.split("-");
								if(finishDate[0].equals(tempMap.get("year").toString()) && finishDate[1].equals(tempMap.get("date").toString())){
									flag = false;
								}
							}
							if(flag){
								if("A".equals(map.get("wt_opt_type").toString()) || "B".equals(map.get("wt_opt_type").toString())){
									buffer.append(tempMap.get("year")+"年"+tempMap.get("date")+"月, ");
								}else if("C".equals(map.get("wt_opt_type").toString()) || "D".equals(map.get("wt_opt_type").toString())){
									buffer.append(tempMap.get("year")+"年第"+tempMap.get("date")+"周, ");
								}
							}
						}
					}else{
						for(Map<String,Object> tempMap : tempList){//所有日期
							if("A".equals(map.get("wt_opt_type").toString()) || "B".equals(map.get("wt_opt_type").toString())){
								buffer.append(tempMap.get("year")+"年"+tempMap.get("date")+"月, ");
							}else if("C".equals(map.get("wt_opt_type").toString()) || "D".equals(map.get("wt_opt_type").toString())){
								buffer.append(tempMap.get("year")+"年第"+tempMap.get("date")+"周, ");
							}
						}
					}
					
//					map.put("history_dept_schedule_n", buffer.toString().substring(0, buffer.toString().length()-2));
					map.put("history_dept_schedule", buffer.toString());
					
				}
			}
		}
		return list;
	}
	
	
}