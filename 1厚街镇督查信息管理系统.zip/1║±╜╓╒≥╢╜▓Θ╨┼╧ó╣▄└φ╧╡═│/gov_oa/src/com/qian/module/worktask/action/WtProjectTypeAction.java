package com.qian.module.worktask.action;

import java.util.Date;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import com.gzdec.framework.page.Pagination;
import com.gzdec.framework.util.UniqueIDGenerator;

import com.qian.module.worktask.service.inter.WtProjectTypeService;
import com.qian.util.FormMap;
import com.qian.util.SessionUtil;
import com.qian.util.UploadFile;

/**
 * 描述：事项类型管理
 * @author twg
 */
@Controller
@Scope("prototype")
@RequestMapping(value = "/pc/projecttype")
public class WtProjectTypeAction{
	
	@Autowired
	private WtProjectTypeService wtProjectTypeService;
	
	/**
	 * To enter list
	 * @author twg
	 * @param formMap
	 * @param pagination
	 * @return
	 */
	@RequestMapping(value = "/listByPage")
	public String listByPage(HttpServletRequest request,HttpServletResponse response,ModelMap map,FormMap formMap,Pagination p){
		formMap.getFormMap().put("wpt_is_use", "Y");
		formMap.getFormMap().put("wpt_file_type", "A");
		List<Map<String, Object>> list =  this.wtProjectTypeService.findByPage(formMap.getFormMap(), p);
		map.put("list",list);
		map.put("formMap",formMap.getFormMap());
		map.put("pagination",p);
		return "worktask/wt_project_type_list";
	}
	
	/**
	 * To enter edit
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/entryEdit")
	public String entryEdit(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map){
		map.put("data",this.wtProjectTypeService.findById(formMap.getFormMap()));
		return "worktask/wt_project_type_edit";
	}
	
	/**
	 * Creating
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/create")
	public String create(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map) throws Exception{
		formMap.getFormMap().put("wpt_send_user",SessionUtil.getUserName(request));
		formMap.getFormMap().put("wpt_send_time",new Date());
		formMap.getFormMap().put("wpt_type_id",UniqueIDGenerator.getUUID());
		formMap.getFormMap().put("id",formMap.getFormMap().get("wpt_type_id"));
		UploadFile.uploadAttachment(request, formMap);
		formMap.getFormMap().put("wpt_file",formMap.getFormMap().get("attachment_name"));
		formMap.getFormMap().put("wpt_file_url",formMap.getFormMap().get("attachment"));
		formMap.getFormMap().put("wpt_file_type","A");
		this.wtProjectTypeService.create(formMap.getFormMap());
		return "redirect:/pc/projecttype/listByPage";
	}
	
	/**
	 * Modifing
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/modify")
	public String modify(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map) throws Exception{
		formMap.getFormMap().put("wpt_send_user",SessionUtil.getUserName(request));
		formMap.getFormMap().put("wpt_send_time",new Date());
		formMap.getFormMap().put("id",formMap.getFormMap().get("wpt_type_id"));
		UploadFile.uploadAttachment(request, formMap);
		formMap.getFormMap().put("wpt_file",formMap.getFormMap().get("attachment_name"));
		formMap.getFormMap().put("wpt_file_url",formMap.getFormMap().get("attachment"));
		formMap.getFormMap().put("wpt_file_type","A");
		this.wtProjectTypeService.modify(formMap.getFormMap());
		return "redirect:/pc/projecttype/listByPage";
	}
	
	/**
	 * Deleting
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/delete")
	public String delete(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map) throws Exception{
		this.wtProjectTypeService.remove(formMap.getFormMap());
		return "redirect:/pc/projecttype/listByPage";
	}
	

	/**
	 * To enter view
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/entryView")
	public String entryView(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map){
		map.put("data",this.wtProjectTypeService.findById(formMap.getFormMap()));
		return "worktask/wt_project_type_view";
	}

}	