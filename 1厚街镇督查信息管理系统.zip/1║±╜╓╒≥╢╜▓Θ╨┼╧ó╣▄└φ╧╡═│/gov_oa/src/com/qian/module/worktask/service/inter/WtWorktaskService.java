package com.qian.module.worktask.service.inter;

import java.util.List;
import java.util.Map;
import com.gzdec.framework.page.Pagination;

/**
 * @author twg
 */
public interface WtWorktaskService {

	/**
	 * Query List
	 * @author twg
	 * @param valueMap
	 * @return
	 */
	public List<Map<String,Object>> findAll(Map<String,Object> valueMap);
	
	/**
	 * Query Page List
	 * @author twg
	 * @param valueMap
	 * @return
	 */
	public List<Map<String,Object>> findByPage(Map<String,Object> valueMap,Pagination pagination);
	
	/**
	 * Get A Record
	 * @author twg
	 * @param valueMap
	 * @return
	 */
	public Map<String,Object> find(Map<String,Object> valueMap);
	
	/**
	 * Get A Record
	 * @author twg
	 * @param valueMap
	 * @return
	 */
	public Map<String,Object> findById(Map<String,Object> valueMap);
	
	/**
	 * Creating
	 * @author twg
	 * @param valueMap
	 * @return
	 */
	public int create(Map<String,Object> valueMap) throws Exception;	
	
	/**
	 * Modifing
	 * @author twg
	 * @param valueMap
	 * @return
	 */
	public int modify(Map<String,Object> valueMap) throws Exception;
	
	/**
	 * Modifing
	 * @author twg
	 * @param valueMap
	 * @return
	 */
	public int modifyAll(Map<String,Object> valueMap) throws Exception;
	
	/**
	 * Deleting
	 * @author twg
	 * @param valueMap
	 * @return
	 */
	public int remove(Map<String,Object> valueMap) throws Exception;
	
	/**
	 * 更新任务表总进度
	 * @author twg
	 * @param valueMap
	 * @return
	 */
	public int modifyTotalSchedule(Map<String,Object> valueMap) throws Exception;

	/**
	 * 查询全部工作任务
	 * @author twg
	 * @param valueMap
	 * @return
	 */
	public List<Map<String,Object>> findAllWorkTask(Map<String,Object> valueMap,Pagination pagination);
	/**
	 * 根据部门ID查询部门所有任务
	 * @author twg
	 * @param valueMap
	 * @return
	 */
	public List<Map<String,Object>> findDeptTask(Map<String,Object> valueMap,Pagination pagination);
	/**
	 * 事项类型统计报表
	 * @author twg
	 * @param valueMap
	 * @return
	 */
	public List<Map<String,Object>> findProjectStatistics(Map<String,Object> valueMap);
	
	/**
	 * 进度评价统计报表
	 * @author twg
	 * @param valueMap
	 * @return
	 */
	public List<Map<String,Object>> findScheduleEvaluate(Map<String,Object> valueMap);

	
	/**
	 * 判断并获取填报日期
	 * @author twg
	 * @param valueMap
	 * @return
	 */
	public Map<String,Object> setUnfinishedTime(Map<String,Object> valueMap,String type);
	
}