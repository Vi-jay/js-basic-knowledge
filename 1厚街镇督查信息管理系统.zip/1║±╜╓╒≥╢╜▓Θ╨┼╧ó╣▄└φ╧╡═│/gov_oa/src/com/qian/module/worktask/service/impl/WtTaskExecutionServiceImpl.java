package com.qian.module.worktask.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.gzdec.framework.page.Pagination;
import com.gzdec.framework.util.UniqueIDGenerator;

import com.qian.module.worktask.dao.WtTaskExecutionDao;
import com.qian.module.worktask.service.inter.WtDeptTaskService;
import com.qian.module.worktask.service.inter.WtNewsRemindService;
import com.qian.module.worktask.service.inter.WtTaskArrangeService;
import com.qian.module.worktask.service.inter.WtTaskExecutionService;
import com.qian.module.worktask.service.inter.WtWorktaskService;
import com.qian.module.worktask.util.GetCycleListUtil;
import com.qian.util.ListUtils;
import com.qian.util.StringUtils;

/**
 * @author twg
 */
@Service("wtTaskExecutionServiceImpl")
public class WtTaskExecutionServiceImpl implements WtTaskExecutionService{
	
	@Autowired
	private WtTaskExecutionDao wtTaskExecutionDao;
	@Autowired
	private WtNewsRemindService wtNewsRemindService;
	@Autowired
	private WtWorktaskService wtWorktaskService;
	@Autowired
	private WtDeptTaskService wtDeptTaskService;
	@Autowired
	private WtTaskArrangeService wtTaskArrangeService;
	
	
	public Map<String,Object> find(Map<String,Object> valueMap) {
		return this.wtTaskExecutionDao.find(valueMap);
	}
	
	public Map<String,Object> findById(Map<String,Object> valueMap) {
		String id = "";
		if(valueMap.get("task_execution_id") != null){
			id = valueMap.get("task_execution_id").toString().trim();
		}
		if("".equals(id)){
			return new HashMap<String,Object>();
		}
		return this.wtTaskExecutionDao.find(valueMap);
	}

	public List<Map<String,Object>> findAll(Map<String,Object> valueMap) {
		return this.wtTaskExecutionDao.findAll(valueMap);
	}

	public List<Map<String,Object>> findByPage(Map<String,Object> valueMap,Pagination pagination) {
		return this.wtTaskExecutionDao.findByPage(valueMap, pagination);
	}
	
	public int create(Map<String,Object> valueMap)  throws Exception{
		String id = "";
		if(valueMap.get("task_execution_id") != null){
			id = valueMap.get("task_execution_id").toString().trim();
		}
		if("".equals(id)){
			valueMap.put("task_execution_id", UniqueIDGenerator.getUUID());
		}		
		if(valueMap.get("create_time") == null || (valueMap.get("create_time") != null && valueMap.get("create_time").toString().trim() == "")){
			valueMap.put("create_time",new Date());
		}
		if(StringUtils.isNotNull(valueMap.get("worktask_id")) && StringUtils.isNotNull(valueMap.get("task_arrange_id"))
				&& StringUtils.isNotNull(valueMap.get("user_id"))){
			return this.wtTaskExecutionDao.create(valueMap);
		}else{
			return 0;
		}
	}	

	public int modify(Map<String,Object> valueMap) throws Exception{
		if(valueMap.get("task_execution_id") != null){
			if(valueMap.get("update_time") == null || (valueMap.get("update_time") != null && valueMap.get("update_time").toString().trim() == "")){
				valueMap.put("update_time",new Date());
			}
			int count = this.wtTaskExecutionDao.modify(valueMap);
			if(count > 0){
				this.wtNewsRemindService.addMsg(valueMap);
			}
			return count;
		}else{
			return -1;
		}
	}

	public int remove(Map<String,Object> valueMap) throws Exception{
		String[] idArr = new String[1];
		if(valueMap.get("ids") != null && valueMap.get("ids").toString().length() > 0){
			if (valueMap.get("ids") instanceof String) {
				idArr[0] = valueMap.get("ids").toString();
			}else{
		    	idArr = (String[]) valueMap.get("ids");
			}
			List<Map<String,Object>> list = new ArrayList<Map<String,Object>>();
			String id = "";
			Map<String,Object> toMap = new HashMap<String,Object>();
			for(int i = 0; i < idArr.length; i++){
				id = idArr[i];
				toMap = new HashMap<String,Object>();
				toMap.put("task_execution_id", id);
				this.wtNewsRemindService.removeByTeId(toMap);
				list.add(toMap);
			}
			return this.wtTaskExecutionDao.remove(list);
		}else{
			return -1;
		}
	}

	@Override
	public List<Map<String, Object>> findAssistTask(Map<String, Object> valueMap) {
		return this.wtTaskExecutionDao.queryAssistTask(valueMap);
	}

	@Override
	public int modifyAssistStatus(Map<String, Object> valueMap)throws Exception {
		return this.wtTaskExecutionDao.modifyAssistStatus(valueMap);
	}

	@Override
	public List<Map<String, Object>> findReportResult(Map<String, Object> valueMap) {
		return this.wtTaskExecutionDao.queryReportResult(valueMap);
	}

	@Override
	public List<Map<String, Object>> findInfoByWorkTaskId(
			Map<String, Object> valueMap) {
		return this.wtTaskExecutionDao.queryInfoByWorkTaskId(valueMap);
	}

	@Override
	public boolean updateSchedule(Map<String, Object> valueMap) throws Exception {
		Map<String,Object> paramMap = new HashMap<String,Object>();
		//更新安排表进度
		paramMap.put("task_arrange_id", valueMap.get("task_arrange_id"));
		int schedule = 0;
		if(StringUtils.isNotNull(valueMap.get("schedule"))){
			schedule = Integer.parseInt(valueMap.get("schedule").toString());
		}
		paramMap.put("schedule",schedule);
		if(schedule == 100){
			paramMap.put("task_status","E");
//			this.wtTaskExecutionService.modifyAssistStatus(valueMap);
		}else{
			paramMap.put("task_status","C");
		}
		this.wtTaskArrangeService.modify(paramMap);
		//更新部门进度
		this.wtDeptTaskService.updateSchedule(valueMap);
		//更新任务总进度
		this.wtWorktaskService.modifyTotalSchedule(valueMap);
		return true;
	}

	@Override
	public List<Map<String, Object>> getReportingPeriod(Map<String, Object> worktask,Map<String, Object> taskArrange) {
		if(StringUtils.isNotNull(worktask.get("worktask_id")) && StringUtils.isNotNull(taskArrange.get("task_arrange_id"))){
			List<Map<String,Object>> rList = GetCycleListUtil.getAllTime((Date)taskArrange.get("arr_start_time"),(Date)taskArrange.get("arr_end_time"),worktask.get("wt_opt_type").toString());
			Map<String,Object> paramMap = new HashMap<String,Object>();
			paramMap.put("worktask_id", worktask.get("worktask_id"));
			paramMap.put("task_arrange_id", taskArrange.get("task_arrange_id"));
			paramMap.put("user_id", taskArrange.get("user_id"));
			List<Map<String,Object>> teList = this.wtTaskExecutionDao.findAll(paramMap);
			if(ListUtils.isNotNull(rList)){
				if(ListUtils.isNotNull(teList)){
					for(Map<String,Object> rMap : rList){
						for(Map<String,Object> teMap : teList){
							if(rMap.get("year").toString().equals(teMap.get("submit_year").toString()) && rMap.get("date").toString().equals(teMap.get("submit_time").toString())){
								rMap.put("is_submit", "Y");//本周期已填报
							}
						}
					}
				}
				return rList; 
			}
		}
		return null;
	}

	@Override
	public int modifyToY(Map<String, Object> valueMap) throws Exception {
		int count = this.wtTaskExecutionDao.updateToY(valueMap);
		return count;
	}
	
	
	
	
	
	
	
	
	
}