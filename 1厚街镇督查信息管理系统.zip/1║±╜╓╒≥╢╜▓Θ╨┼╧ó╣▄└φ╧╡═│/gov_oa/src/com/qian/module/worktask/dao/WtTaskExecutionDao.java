package com.qian.module.worktask.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Service;
import com.gzdec.framework.dao.SqlMapBaseDao;
import com.gzdec.framework.page.Pagination;
import com.qian.util.ListUtils;
import com.qian.util.StringUtils;

/**
 * @author twg
 */
@Service
public class WtTaskExecutionDao extends SqlMapBaseDao{
	/**
	 * Query List
	 * @author twg
	 * @param valueMap
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<Map<String,Object>> findAll(Map<String,Object> to){
		return this.queryForList("worktask.wtTaskExecution.query", to);
	}
	
	/**
	 * Query Page List
	 * @author twg
	 * @param valueMap
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<Map<String,Object>> findByPage(Map<String,Object> to,Pagination pagination){
		return this.queryForList("worktask.wtTaskExecution.query", to, pagination);
	}
	
	/**
	 * Get A Record
	 * @author twg
	 * @param to
	 * @return
	 */
	@SuppressWarnings("unchecked")	 
	public Map<String,Object> find(Map<String,Object> to){
		return (Map<String,Object>)this.queryForObject("worktask.wtTaskExecution.query", to);
	}
	
	/**
	 * Creating
	 * @author twg
	 * @param to
	 * @return
	 */
	public int create(Map<String,Object> to) throws Exception{
		if(StringUtils.isNull(to.get("assist_explain"))){
			to.put("assist_explain","暂无");
		}
		this.insert("worktask.wtTaskExecution.create", to);
		return 1;
	}
	
	/**
	 * Modify
	 * @author twg
	 * @param to
	 * @return
	 */
	public int modify(Map<String,Object> to) throws Exception{
		return this.update("worktask.wtTaskExecution.modify", to);
	}
	
	/**
	 * Deleting
	 * @author twg
	 * @param to
	 * @return
	 */
	public int remove(Map<String,Object> to) throws Exception{
		List<Map<String,Object>> list = new ArrayList<Map<String,Object>>();
		list.add(to);
		return this.remove(list);
	}
	
	/**
	 * Deleting List
	 * @author twg
	 * @param list
	 * @return
	 */
	public int remove(List<Map<String,Object>> list){
		int count = 0;
		if(null == list || list.size() <= 0){
		    return count;
		}
		for(int i = 0; i < list.size(); i++){
		    Map<String,Object> to = list.get(i);
		    count += this.delete("worktask.wtTaskExecution.remove", to);
		}
		return count;
	}

	/**
	 * 通过worktask_id批量删除数据
	 * @author twg
	 * @param to
	 * @return
	 */
	public int removeByWorktaskId(Map<String,Object> to) throws Exception{
		return this.delete("worktask.wtTaskExecution.removeByWorktaskId", to);
	}
	
	/**
	 * 根据用户ID查询用户协助任务
	 * @author twg
	 * @param valueMap
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<Map<String,Object>> queryAssistTask(Map<String,Object> to){
		return this.queryForList("worktask.wtTaskExecution.queryAssistTask", to);
	}

	/**
	 * 当任务结束时，将所有状态为协助中改为已完成
	 * @author twg
	 * @param to
	 * @return
	 */
	public int modifyAssistStatus(Map<String,Object> to) throws Exception{
		return this.update("worktask.wtTaskExecution.modifyAssistStatus", to);
	}

	/**
	 * 根据搜索条件查询事项报表结果
	 * @author twg
	 * @param valueMap
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<Map<String,Object>> queryReportResult(Map<String,Object> to){
		return this.queryForList("worktask.wtTaskExecution.queryReportResult", to);
	}
	
	
	/**
	 * 根据事项ID查询审核中，不通过，已退回的任务执行信息
	 * @author twg
	 * @param valueMap
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<Map<String,Object>> queryInfoByWorkTaskId(Map<String,Object> to){
		return this.queryForList("worktask.wtTaskExecution.queryInfoByWorkTaskId", to);
	}
	
	
	/**
	 * 逐级往上更新进度（脱离事务方式）
	 * @author twg
	 * @param to
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public boolean updateAllSchedule(Map<String,Object> to) throws Exception{
		if(StringUtils.isNull(to.get("worktask_id")) || StringUtils.isNull(to.get("task_arrange_id"))){
			return false;
		}
		String worktask_id = to.get("worktask_id").toString();
		String task_arrange_id = to.get("task_arrange_id").toString();
		Map<String,Object> paramMap = new HashMap<String,Object>();
		paramMap.put("task_arrange_id", task_arrange_id);
		Map<String,Object> taMap = (Map<String,Object>)this.queryForObject("worktask.wtTaskArrange.query", paramMap);
		String dept_id = taMap.get("dept_id").toString();
		
		paramMap.clear();
		paramMap.put("worktask_id", worktask_id);
		paramMap.put("task_arrange_id", task_arrange_id);
		int schedule = 0;
		List<Map<String,Object>> teList = this.queryForList("worktask.wtTaskExecution.query", paramMap);
		if(ListUtils.isNotNull(teList)){//存在执行数据则获取最新一条记录进度
			schedule = Integer.parseInt(teList.get(teList.size()-1).get("schedule").toString());
		}
		//更新职员任务安排表进度
		paramMap.clear();
		paramMap.put("task_arrange_id",task_arrange_id);
		paramMap.put("schedule",schedule);
		if(schedule == 100){
			paramMap.put("task_status","E");
			paramMap.put("task_status_time",new Date());
		}else{
			paramMap.put("task_status","C");
		}
		this.update("worktask.wtTaskArrange.modify", paramMap);
		//更新部门进度
		paramMap.clear();
		paramMap.put("worktask_id", worktask_id);
		paramMap.put("dept_id", dept_id);
		List<Map<String,Object>> taList = this.queryForList("worktask.wtTaskArrange.query", paramMap);
		if(taList != null && taList.size() > 0){
			this.calculationSchedule(paramMap, taList);
			this.update("worktask.wtDeptTask.updateSchedule", paramMap);
		}
		//更新项目总进度
		paramMap.clear();
		paramMap.put("worktask_id",worktask_id);
		List<Map<String,Object>> dtList = this.queryForList("worktask.wtDeptTask.query", paramMap);
		if(dtList != null && dtList.size() > 0){
			this.calculationSchedule(paramMap, dtList);
			this.update("worktask.wtWorktask.modify", paramMap);
		}
		return true;
	}
	
	/**计算项目进度*/
	private void calculationSchedule(Map<String,Object> paramMap,List<Map<String,Object>> list){
		double total_schedule = 0;
		for(Map<String,Object> map : list){
			if(StringUtils.isNotNull(map.get("schedule"))){
				total_schedule += (Integer)map.get("schedule");
			}else{
				total_schedule += (Integer)map.get("dt_schedule");
			}
		}
		double result = total_schedule/list.size();
		result = Math.ceil(result);
		if(result >= 100){//大于100取100
			paramMap.put("dt_schedule",100);
			paramMap.put("total_schedule",100);
		}else if(result < 1){//小于1取1
			paramMap.put("dt_schedule",1);
			paramMap.put("total_schedule",1);
		}else{
			paramMap.put("dt_schedule",result);
			paramMap.put("total_schedule",result);
		}
	}
	
	/**
	 * 部门管理员上报部门进度时，将全部任务执行步骤改为审核通过
	 * @author twg
	 * @param to
	 * @return
	 */
	public int updateToY(Map<String,Object> to) throws Exception{
		return this.update("worktask.wtTaskExecution.updateToY", to);
	}
	
}