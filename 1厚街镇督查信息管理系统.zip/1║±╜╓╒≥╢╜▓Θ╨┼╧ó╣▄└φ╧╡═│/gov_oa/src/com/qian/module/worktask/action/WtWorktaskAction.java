package com.qian.module.worktask.action;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.sf.json.JSONArray;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.gzdec.framework.page.Pagination;
import com.gzdec.framework.util.UniqueIDGenerator;

import com.qian.module.common.action.BaseAction;
import com.qian.module.user.service.inter.MbSysDeptService;
import com.qian.module.user.service.inter.SysDeptGroupService;
import com.qian.module.worktask.service.inter.WtAssistunitService;
import com.qian.module.worktask.service.inter.WtDeptScheduleService;
import com.qian.module.worktask.service.inter.WtDeptTaskService;
import com.qian.module.worktask.service.inter.WtTaskArrangeService;
import com.qian.module.worktask.service.inter.WtTaskExecutionService;
import com.qian.module.worktask.service.inter.WtWorktaskService;
import com.qian.module.worktask.util.GetCycleListUtil;
import com.qian.module.worktask.util.NewsRemindUtil;
import com.qian.util.FormMap;
import com.qian.util.SearchParamUtils;
import com.qian.util.SessionUtil;
import com.qian.util.StringUtils;
import com.qian.util.UploadFile;

/**
 * 描述：事项实施管理
 * @author twg
 */
@Controller
@Scope("prototype")
@RequestMapping(value = "/pc/worktask")
public class WtWorktaskAction extends BaseAction{
	
	@Autowired
	private WtWorktaskService wtWorktaskService;
	@Autowired
	private WtTaskArrangeService wtTaskArrangeService;
	@Autowired
	private WtTaskExecutionService wtTaskExecutionService;
	@Autowired
	private WtDeptTaskService wtDeptTaskService;
	@Autowired
	private MbSysDeptService mbSysDeptService;
	@Autowired
	private WtAssistunitService wtAssistunitService;
	@Autowired
	private SysDeptGroupService sysDeptGroupService;
	@Autowired
	private WtDeptScheduleService wtDeptScheduleService;
	
	/**
	 * To enter list
	 * @author twg
	 * @param formMap
	 * @param pagination
	 * @return
	 */
	@RequestMapping(value = "/listByPage")
	public String listByPage(HttpServletRequest request,HttpServletResponse response,ModelMap map,FormMap formMap,Pagination p){
		if(StringUtils.isNotNull(formMap.getFormMap().get("task_status"))){
		}else{
			formMap.getFormMap().put("task_status","A");
		}
		formMap.getFormMap().put("launch_user",SessionUtil.getLoginUserId(request));
		SearchParamUtils.saveOrGetSearchParam(request, formMap, "WtWorktaskAction_listByPage");
		List<Map<String, Object>> list =  this.wtWorktaskService.findByPage(formMap.getFormMap(), p);
		map.put("list",list);
		map.put("formMap",formMap.getFormMap());
		map.put("pagination",p);
		this.loadData(map);
		return "worktask/wt_worktask_list";
	}
	
	/**
	 * 统计各种状态数量
	 * @param formMap
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = "/listByPageCount", method = RequestMethod.POST, produces = { "application/json;charset=UTF-8" })
	public  @ResponseBody Map<String,Object> listByPageCount(HttpServletRequest request,FormMap formMap) throws IOException {
		Map<String,Object> resultMap = new HashMap<String,Object>();
		formMap.getFormMap().put("launch_user",SessionUtil.getLoginUserId(request));
		Pagination p = new Pagination();
		formMap.getFormMap().put("task_status","A");
		this.wtWorktaskService.findByPage(formMap.getFormMap(), p);
		resultMap.put("A", p.getCount());
		
		p = new Pagination();
		formMap.getFormMap().put("task_status","B");
		this.wtWorktaskService.findByPage(formMap.getFormMap(), p);
		resultMap.put("B", p.getCount());
		
		p = new Pagination();
		formMap.getFormMap().put("task_status","C");
		this.wtWorktaskService.findByPage(formMap.getFormMap(), p);
		resultMap.put("C", p.getCount());
		
		p = new Pagination();
		formMap.getFormMap().put("task_status","D");
		this.wtWorktaskService.findByPage(formMap.getFormMap(), p);
		resultMap.put("D", p.getCount());
		return resultMap;
	}
	
	/**
	 * 查询全部工作任务
	 * @author twg
	 * @param formMap
	 * @param pagination
	 * @return
	 */
	@RequestMapping(value = "/findAllWorkTask")
	public String findAllWorkTask(HttpServletRequest request,HttpServletResponse response,ModelMap map,FormMap formMap,Pagination p){
		formMap.getFormMap().put("is_delete","N");
		
		if(StringUtils.isNull(formMap.getFormMap().get("dt_is_lock_type"))){//微信端报表
			formMap.getFormMap().put("dt_is_lock_type", "N");
		}
		SearchParamUtils.saveOrGetSearchParam(request, formMap, "WtWorktaskAction_findAllWorkTask");
		List<Map<String, Object>> list =  this.wtWorktaskService.findAllWorkTask(formMap.getFormMap(), p);
		map.put("list",list);
		this.loadData(map);
		map.put("formMap",formMap.getFormMap());
		map.put("pagination",p);
//		return "worktask/wt_worktask_all_list";
		return this.platformType(request, "worktask/wt_worktask_all_list", "worktask/mobile/wt_worktask_all_list");
	}
	
	
	/**
	 * 查询全部工作任务
	 * @author twg
	 * @param formMap
	 * @param pagination
	 * @return
	 */
	@RequestMapping(value = "/findAllWorkTaskForMobile")
	public String findAllWorkTaskForMobile(HttpServletRequest request,HttpServletResponse response,ModelMap map,FormMap formMap,Pagination p){
		this.setMobileReportParam(request, map, formMap);
		List<Map<String, Object>> list =  this.wtWorktaskService.findAllWorkTask(formMap.getFormMap(), p);
		map.put("list",list);
		this.loadData(map);
		map.put("formMap",formMap.getFormMap());
		map.put("pagination",p);
//		return "worktask/wt_worktask_all_list";
		return this.platformType(request, "worktask/wt_worktask_all_list", "worktask/mobile/wt_worktask_all_list");
	}
	
	/**进入微信端报表时加载参数*/
	private void setMobileReportParam(HttpServletRequest request,ModelMap map,FormMap formMap){
		formMap.getFormMap().put("is_delete","N");

		Object obj = request.getSession().getAttribute("respon_leader_mobile");
		if(StringUtils.isNotNull(obj)){
			formMap.getFormMap().put("respon_leader", obj.toString());
		}
		
		HttpSession session = request.getSession();
		if(StringUtils.isNotNull(formMap.getFormMap().get("request_source")) && "wwrs".equals(formMap.getFormMap().get("request_source").toString())){
			session.removeAttribute("fwfm_wpt_type_id");
			session.removeAttribute("fwfm_evaluate");
			session.removeAttribute("fwfm_to_doing");
			session.setAttribute("fwfm_wpt_type_id", formMap.getFormMap().get("wpt_type_id"));
			try {
				if(StringUtils.isNotNull(formMap.getFormMap().get("evaluate"))){
					String evaluate = URLDecoder.decode(formMap.getFormMap().get("evaluate").toString(), "UTF-8");
					session.setAttribute("fwfm_evaluate", evaluate);
					formMap.getFormMap().put("evaluate", evaluate);
				}
			} catch (UnsupportedEncodingException e) {
			}
			session.setAttribute("fwfm_to_doing", formMap.getFormMap().get("to_doing"));
		}else{
			Object wpt_type_id = session.getAttribute("fwfm_wpt_type_id");
			Object evaluate = session.getAttribute("fwfm_evaluate");
			Object to_doing = session.getAttribute("fwfm_to_doing");
			Object arr_start_time = session.getAttribute("fwfm_arr_start_time");
			Object arr_end_time = session.getAttribute("fwfm_arr_end_time");
			if(StringUtils.isNotNull(wpt_type_id)){
				formMap.getFormMap().put("wpt_type_id", wpt_type_id.toString());
			}
			if(StringUtils.isNotNull(evaluate)){
				formMap.getFormMap().put("evaluate", evaluate.toString());
			}
			if(StringUtils.isNotNull(to_doing)){
				formMap.getFormMap().put("to_doing", to_doing.toString());
			}
			if(StringUtils.isNotNull(arr_start_time)){
				formMap.getFormMap().put("arr_start_time", arr_start_time.toString());
			}
			if(StringUtils.isNotNull(arr_end_time)){
				formMap.getFormMap().put("arr_end_time", arr_end_time.toString());
			}
		}
	}
	
	/**
	 * 统计各种状态数量
	 * @param formMap
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = "/findAllWorkTaskCount", method = RequestMethod.POST, produces = { "application/json;charset=UTF-8" })
	public  @ResponseBody Map<String,Object> findAllWorkTaskCount(HttpServletRequest request,FormMap formMap,Pagination p) throws IOException {
		formMap.getFormMap().put("is_delete","N");
		Object obj = request.getSession().getAttribute("respon_leader_mobile");
		if(StringUtils.isNotNull(obj)){
			formMap.getFormMap().put("respon_leader", obj.toString());
		}
		formMap.getFormMap().put("dt_is_lock_type", "N");
		this.wtWorktaskService.findAllWorkTask(formMap.getFormMap(), p);
		resultMap.put("N", p.getCount());
		formMap.getFormMap().put("dt_is_lock_type", "Y");
		this.wtWorktaskService.findAllWorkTask(formMap.getFormMap(), p);
		resultMap.put("Y", p.getCount());
		return resultMap;
	}
	
	@RequestMapping(value = "/chartForMobile")
	public String chartForMobile(HttpServletRequest request,ModelMap map,FormMap formMap){
		int index = Integer.parseInt(formMap.getFormMap().get("index").toString());//
		formMap.getFormMap().put("index",index);
		formMap.getFormMap().put("is_delete","N");
		
		this.setMobileReportParam(request, map, formMap);
		List<Map<String, Object>> list = this.wtWorktaskService.findAllWorkTask(formMap.getFormMap(), null);
		Map<String, Object> workTask = null;
		if(list != null && list.size() > 0 && index < list.size()){
			workTask = list.get(index);
		}else{
			workTask = list.get(list.size()-1);
			formMap.getFormMap().put("index",index-1);
		}
		map.put("workTask", workTask);//事项信息
		this.paramMap.put("worktask_id",workTask.get("worktask_id"));
		List<Map<String, Object>> deptTaskList = this.wtDeptTaskService.findForChart(this.paramMap);
		map.put("deptTaskList", deptTaskList);//部门任务列表
		if(deptTaskList != null && deptTaskList.size() > 0){
			Double d_plan = 0.0;
			for(Map<String, Object> deptTask : deptTaskList){
				//原计划
				int s_index = Integer.parseInt(deptTask.get("s_index").toString());
				int e_index = Integer.parseInt(deptTask.get("e_index").toString());
				int day_count = Integer.parseInt(deptTask.get("day_count").toString());
				int now_day_count = Integer.parseInt(deptTask.get("now_day_count").toString());
				if(s_index == 0){//未到计划开始时间
					deptTask.put("plan",0);
				}else if(e_index == 0){//已经超过计划结束时间
					deptTask.put("plan",100);
				}else if(s_index == 1 && e_index == 1){
					d_plan = Math.floor((((double)100/day_count)*now_day_count));
					deptTask.put("plan",d_plan.intValue());
				}
			}
		}
		map.put("dt_list",JSONArray.fromObject(deptTaskList));
		map.put("formMap",formMap.getFormMap());
		return "worktask/mobile/wt_worktask_all_list_chart";
	}
	
	/**加载基础信息*/
	private void loadData(ModelMap map){
		Map<String,Object> tempMap = new HashMap<String,Object>();
		//加载事项类型
		List<Map<String,Object>> projectTypeList = this.getProjectTypeList("A");
		map.put("projectTypeList", projectTypeList);
		//加载部门信息
		tempMap.clear();
		tempMap.put("is_delete","N");
		List<Map<String,Object>> deptList = this.mbSysDeptService.findAll(tempMap);
		map.put("deptList", deptList);
	}
	
	/**
	 * 进入阶段审核列表页
	 * @author twg
	 * @param formMap
	 * @param pagination
	 * @return
	 */
	@RequestMapping(value = "/entryApprovalList")
	public String entryApprovalList(HttpServletRequest request,HttpServletResponse response,ModelMap map,FormMap formMap,Pagination p){
		if(StringUtils.isNull(formMap.getFormMap().get("approval_status"))){
			formMap.getFormMap().put("approval_status","O");
		}
		formMap.getFormMap().put("is_delete","N");
		formMap.getFormMap().put("login_user_id",SessionUtil.getLoginUserId(request));
		NewsRemindUtil.getAllTime(formMap.getFormMap());
		formMap.getFormMap().put("opt_mark", "approval");
		List<Map<String, Object>> list =  this.wtWorktaskService.findDeptTask(formMap.getFormMap(), p);
		map.put("list",GetCycleListUtil.getUnfinishedDate(list));
		map.put("formMap",formMap.getFormMap());
		map.put("pagination",p);
		
		//加载事项类型
		List<Map<String,Object>> projectTypeList = this.getProjectTypeList("A");
		map.put("projectTypeList", projectTypeList);
//		return "worktask/wt_task_execution_approval";
		NewsRemindUtil.setPageParam(map);
		return this.platformType(request, "worktask/wt_task_execution_approval", "worktask/mobile/wt_task_execution_approval");
	}
	
	/**
	 * 统计各种状态数量
	 * @param formMap
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = "/approvalCount", method = RequestMethod.POST, produces = { "application/json;charset=UTF-8" })
	public  @ResponseBody Map<String,Object> approvalCount(HttpServletRequest request,FormMap formMap) throws IOException {
		Map<String,Object> resultMap = new HashMap<String,Object>();
		formMap.getFormMap().put("is_delete","N");
		formMap.getFormMap().put("login_user_id",SessionUtil.getLoginUserId(request));
		
		Pagination p = new Pagination();
		formMap.getFormMap().put("approval_status","O");
		this.wtWorktaskService.findDeptTask(formMap.getFormMap(), p);
		resultMap.put("O", p.getCount());
		
		p = new Pagination();
		formMap.getFormMap().remove("approval_status");
		formMap.getFormMap().put("approval_status","Y");
		this.wtWorktaskService.findDeptTask(formMap.getFormMap(), p);
		resultMap.put("Y", p.getCount());
		
		return resultMap;
	}
	
	
	/**
	 * To enter edit
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/entryEdit")
	public String entryEdit(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map){
		Map<String,Object> workTaskMap = this.wtWorktaskService.findById(formMap.getFormMap());
		map.put("data",workTaskMap);
		if(workTaskMap != null && workTaskMap.size() > 0){
			this.paramMap.put("worktask_id", workTaskMap.get("worktask_id"));
			List<Map<String,Object>> deptTaskList = this.wtDeptTaskService.findAll(this.paramMap);
			map.put("deptTaskList", deptTaskList);
			
			List<Map<String,Object>> auList = this.wtAssistunitService.findAll(this.paramMap);
			map.put("auList", auList);
			
//			if(ListUtils.isNotNull(deptTaskList)){
//				if(ListUtils.isNotNull(auList)){
//					List<Map<String,Object>> tempList = null;
//					for(Map<String,Object> deptTaskMap : deptTaskList){
//						tempList = new ArrayList<Map<String,Object>>();
//						for(Map<String,Object> auMap : auList){
//							if(deptTaskMap.get("dept_id").toString().equals(auMap.get("dt_dept_id").toString())){
//								tempList.add(auMap);
//							}
//						}
//						deptTaskMap.put("assistUnitList", tempList);
//					}
//				}
//			}
		}
		
		//加载事项类型
		List<Map<String,Object>> projectTypeList = this.getProjectTypeList("A");
		map.put("projectTypeList", projectTypeList);
		return "worktask/wt_worktask_edit";
	}
	
	/**
	 * Creating
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/create")
	public String create(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map) throws Exception{
		formMap.getFormMap().put("launch_user",SessionUtil.getLoginUserId(request));
		formMap.getFormMap().put("worktask_id",UniqueIDGenerator.getUUID());
		formMap.getFormMap().put("id",formMap.getFormMap().get("worktask_id"));
		UploadFile.uploadAttachment(request, formMap);
		this.setDeptGroup(formMap.getFormMap());
		this.wtWorktaskService.create(formMap.getFormMap());
		return "redirect:/pc/worktask/listByPage";
	}
	
	private void setDeptGroup(Map<String,Object> formMap){
		if(StringUtils.isNotNull(formMap.get("sg_id"))){
			List<Map<String,Object>> list = this.sysDeptGroupService.findAll(formMap);
			String[] dept_ids = new String[list.size()];//所有部门ID
			String[] arrange_explains = new String[list.size()];//所有执行说明
			String[] dt_start_time = new String[list.size()];//
			String[] dt_end_time = new String[list.size()];//
			String[] dt_attach_name = new String[list.size()];//
			String[] dt_attach_url = new String[list.size()];//
			String[] dt_respon_peoples = new String[list.size()];//
			int size = list.size();
			for(int i=0;i<size;i++){
				dept_ids[i] = (String) list.get(i).get("sd_dept_id");
				arrange_explains[i] = formMap.get("arrange_explains").toString();//所有执行说明
				dt_start_time[i] = formMap.get("start_time").toString();//
				dt_end_time[i] = formMap.get("end_time").toString();//
				dt_attach_name[i] = formMap.get("dt_attach_name").toString();//
				dt_attach_url[i] = formMap.get("dt_attach_url").toString();//
				dt_respon_peoples[i] = formMap.get("dt_respon_peoples").toString();//
			}
			formMap.put("dept_ids",dept_ids);//所有部门ID
			formMap.put("arrange_explains",arrange_explains);//所有执行说明
			formMap.put("start_time",dt_start_time);//
			formMap.put("end_time",dt_end_time);//
			formMap.put("dt_attach_name",dt_attach_name);//
			formMap.put("dt_attach_url",dt_attach_url);//
			formMap.put("dt_respon_peoples",dt_respon_peoples);//
		}
	}
	
	/**
	 * Modifing
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/modify")
	public String modify(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map) throws Exception{
		formMap.getFormMap().put("id",formMap.getFormMap().get("worktask_id"));
		UploadFile.uploadAttachment(request, formMap);
		this.wtWorktaskService.modifyAll(formMap.getFormMap());
		return "redirect:/pc/worktask/listByPage";
	}
	
	/**
	 * 暂停与启用
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/modifyToSuspend")
	public String modifyToSuspend(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map) throws Exception{
		this.wtWorktaskService.modify(formMap.getFormMap());
		return "redirect:/pc/worktask/listByPage";
	}
	
	/**
	 * Deleting
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/delete")
	public String delete(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map) throws Exception{
		this.wtWorktaskService.remove(formMap.getFormMap());
		return "redirect:/pc/worktask/listByPage";
	}
	

	/**
	 * To enter view
	 * @author twg
	 * @param formMap
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value = "/entryView")
	public String entryView(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map) throws Exception{
		Map<String,Object> wtMap = this.wtWorktaskService.findById(formMap.getFormMap());
		map.put("data",wtMap);
		this.paramMap.put("worktask_id",wtMap.get("worktask_id"));
		this.paramMap.put("dept_id",formMap.getFormMap().get("dept_id"));
		if(StringUtils.isNotNull(formMap.getFormMap().get("opt_mark")) 
				&& ("mytask".equals(formMap.getFormMap().get("opt_mark").toString()) ||
						"approval".equals(formMap.getFormMap().get("opt_mark").toString()))){
			this.paramMap.put("login_user_id",SessionUtil.getLoginUserId(request));//只能够查看用户所在部门信息（我的任务或者任务审批）
			if("approval".equals(formMap.getFormMap().get("opt_mark").toString())){
				this.paramMap.put("dt_dept_task_id",formMap.getFormMap().get("dt_dept_task_id"));//
			}
		}else{
			this.paramMap.put("approval_status", "Y");//非当前任务执行者，只允许查看已经通过审核的信息
		}
		//部门任务列表
		List<Map<String,Object>> deptList = this.wtDeptTaskService.findAll(this.paramMap);
		map.put("deptTaskList", deptList);
		if(StringUtils.isNotNull(formMap.getFormMap().get("opt_mark")) && "approval".equals(formMap.getFormMap().get("opt_mark").toString())){
			map.put("cycle_list",this.wtDeptScheduleService.getReportingPeriod(deptList.get(0)));
		}
		if(StringUtils.isNotNull(formMap.getFormMap().get("opt_mark")) && "unit".equals(formMap.getFormMap().get("opt_mark").toString())){
			this.paramMap.put("dt_dept_id",formMap.getFormMap().get("dept_id"));//主办单位ID
			this.paramMap.put("login_user_id",SessionUtil.getLoginUserId(request));//不允许查看其他协助单位信息
		}
		Map<String,Object> tempMap = new HashMap<String,Object>();
		tempMap.put("worktask_id",wtMap.get("worktask_id"));
		List<Map<String,Object>> auList = this.wtAssistunitService.findAll(tempMap);
		map.put("auList", auList);
		
		if(StringUtils.isNotNull(formMap.getFormMap().get("opt_mark")) && 
				("mytask".equals(formMap.getFormMap().get("opt_mark").toString()) 
						|| "approval".equals(formMap.getFormMap().get("opt_mark").toString()))){
			
			if(StringUtils.isNotNull(formMap.getFormMap().get("opt_mark")) 
					&& "mytask".equals(formMap.getFormMap().get("opt_mark").toString())){
				this.paramMap.put("user_id",SessionUtil.getLoginUserId(request));//只显示自己任务
			}
			List<Map<String,Object>> arrList = this.wtTaskArrangeService.findAll(this.paramMap);
//		if("approval".equals(formMap.getFormMap().get("opt_mark"))){
//			this.paramMap.put("approval_status","O");
//		}
			this.setParamMapVal(this.paramMap, "worktask_id,dept_id");
			Map<String,Object> dMap = this.wtWorktaskService.setUnfinishedTime(this.paramMap, "DEPT");
			map.put("resultMap",dMap);
			if(StringUtils.isNotNull(formMap.getFormMap().get("opt_mark")) 
					&& "approval".equals(formMap.getFormMap().get("opt_mark").toString())
					&& (!"E".equals(wtMap.get("wt_opt_type")))){
				this.paramMap.put("submit_year", dMap.get("year"));
				if("A".equals(wtMap.get("wt_opt_type")) || "B".equals(wtMap.get("wt_opt_type"))){
					this.paramMap.put("submit_time", dMap.get("month"));
				}else{
					this.paramMap.put("submit_time", dMap.get("week"));
				}
				if(StringUtils.isNotNull(formMap.getFormMap().get("submit_year"))){
					this.paramMap.put("submit_year", formMap.getFormMap().get("submit_year"));
					this.paramMap.put("submit_time", formMap.getFormMap().get("submit_time"));
				}
				map.put("paramMap", this.paramMap);
			}
			List<Map<String,Object>> exeList = this.wtTaskExecutionService.findAll(this.paramMap);
//		List<Map<String,Object>> evaList = this.wtEvaluateService.findAll(this.paramMap);//暂时去掉评价内容
			if(exeList != null && exeList.size() > 0){
				List<Map<String,Object>> detailList = new ArrayList<Map<String,Object>>();
//			List<Map<String,Object>> evaDetailList = new ArrayList<Map<String,Object>>();
				for(Map<String,Object> arrMap : arrList){//任务分配集合
					detailList = new ArrayList<Map<String,Object>>();
					for(Map<String,Object> exeMap : exeList){//任务执行操作集合
						if(arrMap.get("user_id").toString().equals(exeMap.get("user_id").toString())){
							detailList.add(exeMap);
						}
//					evaDetailList = new ArrayList<Map<String,Object>>();
//					if(evaList != null && evaList.size() > 0){
//						for(Map<String,Object> evaMap : evaList){//阶段评价集合
//							if(exeMap.get("task_execution_id").toString().equals(evaMap.get("task_execution_id").toString())){
//								evaDetailList.add(evaMap);
//							}
//						}
//						exeMap.put("evaDetailList", evaDetailList);
//					}
					}
					arrMap.put("detailList", detailList);
				}
			}
			map.put("detail",arrList);
		}
		
		this.wtTaskArrangeService.modifyAlreadyRead(formMap.getFormMap());
		map.put("formMap",formMap.getFormMap());
//		return "worktask/wt_worktask_view";
		return this.platformType(request, "worktask/wt_worktask_view", "worktask/mobile/wt_worktask_view");
	}
	
	/**
	 * 标记操作
	 * @param formMap
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/toSign", method = RequestMethod.POST, produces = { "application/json;charset=UTF-8" })
	public  @ResponseBody Map<String,Object> toSign(FormMap formMap) throws Exception {
		Map<String,Object> paramMap = new HashMap<String,Object>();
		if(StringUtils.isNotNull(formMap.getFormMap().get("worktask_id")) && StringUtils.isNotNull(formMap.getFormMap().get("is_sign"))){
			this.wtWorktaskService.modify(formMap.getFormMap());
		}
		return paramMap;
	}
	
	/**
	 * 结束任务（任务已完成）
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/overTasks")
	public String overTasks(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map) throws Exception{
		if(StringUtils.isNotNull(formMap.getFormMap().get("worktask_id"))){
			this.paramMap.put("worktask_id",formMap.getFormMap().get("worktask_id"));
			//修改为可随时结束事项
//			List<Map<String,Object>> dtList = this.wtDeptTaskService.findAll(this.paramMap);
//			if(ListUtils.isNotNull(dtList)){
//				for(Map<String,Object> dtMap : dtList){
//					if("N".equals(dtMap.get("dt_is_cancel").toString()) && 
//							(StringUtils.isNull(dtMap.get("dt_schedule_describe")) || "N".equals(dtMap.get("dt_opt_status").toString()))){
//						request.getSession().setAttribute("result_msg", "结束失败，个别主办单位任务未报送或未处理完毕");
//						return "redirect:/pc/worktask/listByPage";
//					}
//				}
//			}
			
			this.paramMap.put("task_status","C");
			this.wtWorktaskService.modify(this.paramMap);
//			int count = this.wtWorktaskService.modify(this.paramMap);
//			if(count > 0){
//				this.wtTaskExecutionService.modifyAssistStatus(this.paramMap);
//			}
		}
		return "redirect:/pc/worktask/listByPage";
	}
	
	/**
	 * 查询并验证能否符合结束当前事项条件
	 * @param formMap
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/isOverTasks", method = RequestMethod.POST, produces = { "application/json;charset=UTF-8" })
	public  @ResponseBody Map<String,Object> isOverTasks(FormMap formMap) throws Exception {
		if(StringUtils.isNotNull(formMap.getFormMap().get("worktask_id"))){
			List<Map<String, Object>> list = this.wtTaskExecutionService.findInfoByWorkTaskId(formMap.getFormMap());
			if(list != null && list.size() > 0){
				this.paramMap.put("result", "N");//存在未处理数据
//				this.paramMap.put("list", list);
			}else{
				this.paramMap.put("result", "Y");
			}
		}else{
			this.paramMap.put("result", "N");
		}
		return paramMap;
	}
	
	/**
	 * To enter view
	 * @author twg
	 * @param formMap
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value = "/isOverTasksPage")
	public String isOverTasksPage(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map) throws Exception{
		List<Map<String, Object>> list = this.wtTaskExecutionService.findInfoByWorkTaskId(formMap.getFormMap());
		map.put("list",list);
		return "worktask/wt_worktask_over_tip";
	}
	
	/**
	 * 更新事项评价
	 * @param formMap
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/updateEvaluate", method = RequestMethod.POST, produces = { "application/json;charset=UTF-8" })
	public  @ResponseBody Map<String,Object> updateEvaluate(FormMap formMap) throws Exception {
		Map<String,Object> paramMap = new HashMap<String,Object>();
		if(StringUtils.isNotNull(formMap.getFormMap().get("worktask_id")) && StringUtils.isNotNull(formMap.getFormMap().get("evaluate"))){
			this.wtWorktaskService.modify(formMap.getFormMap());
		}
		return paramMap;
	}
	
	
	/**
	 * 进入事项图形报表页
	 * @author twg
	 * @param formMap
	 * @param pagination
	 * @return
	 */
	@RequestMapping(value = "/projectReport")
	public String projectReport(HttpServletRequest request,HttpServletResponse response,ModelMap map,FormMap formMap,Pagination p){
		//加载事项类型
		this.paramMap.put("wpt_is_use","Y");
		List<Map<String,Object>> projectTypeList = this.getProjectTypeList("A");
		map.put("projectTypeList", projectTypeList);
		//加载部门信息
		this.paramMap.clear();
		this.paramMap.put("is_delete","N");
		List<Map<String,Object>> deptList = this.mbSysDeptService.findAll(this.paramMap);
		map.put("deptList", deptList);
		if(projectTypeList != null && projectTypeList.size() > 0 && StringUtils.isNull(formMap.getFormMap().get("wpt_type_id"))){
			formMap.getFormMap().put("wpt_type_id",projectTypeList.get(0).get("wpt_type_id"));
		}
		List<Map<String,Object>> wtList = this.wtWorktaskService.findAllWorkTask(formMap.getFormMap(), null);
		if(wtList != null && wtList.size() > 0){
			map.put("wtList",JSONArray.fromObject(wtList));
		}else{
			map.put("wtList",new JSONArray());
		}
		map.put("formMap",formMap.getFormMap());

		return "worktask/wt_worktask_report";
	}
	
	
	/**
	 * 进入其他事项报表页（表格报表）
	 * @author twg
	 * @param formMap
	 * @param pagination
	 * @return
	 */
	@RequestMapping(value = "/otherReport")
	public String otherReport(HttpServletRequest request,HttpServletResponse response,ModelMap map,FormMap formMap,Pagination p){
		//加载事项类型
//		this.paramMap.put("wpt_is_use","Y");
//		List<Map<String,Object>> projectTypeList = this.wtProjectTypeService.findAll(this.paramMap);
//		map.put("projectTypeList", projectTypeList);
		//加载部门信息
		this.paramMap.clear();
		this.paramMap.put("is_delete","N");
		List<Map<String,Object>> deptList = this.mbSysDeptService.findAll(this.paramMap);
		map.put("deptList", deptList);
		
//		if(projectTypeList != null && projectTypeList.size() > 0 && deptList != null && deptList.size() > 0){
			//事项统计报表（综合统计分析）
//			List<Map<String,Object>> totalByType = this.wtTaskArrangeService.statisticsByDeptAndType(formMap.getFormMap());
//			List<String> valList = new ArrayList<String>();
//			Integer count = 0;
//			for(Map<String,Object> dept : deptList){
//				valList = new ArrayList<String>();
//				count = 0;
//				for(Map<String,Object> projectTypeMap : projectTypeList){
//					boolean flag = true;
//					for(Map<String,Object> ttMap : totalByType){
//						if(projectTypeMap.get("wpt_type_id").toString().equals(ttMap.get("wpt_type_id").toString())
//								&& dept.get("dept_id").toString().equals(ttMap.get("dept_id").toString())){
//							count += Integer.parseInt(ttMap.get("dept_task_count").toString());
//							valList.add(ttMap.get("dept_task_count").toString());
//							flag = false;
//							break;
//						}
//					}
//					if(flag){valList.add("0");}
//				}
//				valList.add(count.toString());
//				dept.put("count_list",valList);
//			}
//		}
		//事项进度报表
		formMap.getFormMap().put("order_by","wdt.dept_id");
		p.setPageCount(200);
		map.put("wtlist",this.wtDeptTaskService.findByPage(formMap.getFormMap(), p));
		//部门任务报表
		map.put("dtlist",this.wtDeptTaskService.findDeptTaskStatistics(formMap.getFormMap()));
		//类型统计报表
		map.put("plist",this.wtWorktaskService.findProjectStatistics(formMap.getFormMap()));
		
		request.getSession().removeAttribute("respon_leader_mobile");
		if(StringUtils.isNotNull(formMap.getFormMap().get("respon_leader"))){
			request.getSession().setAttribute("respon_leader_mobile", formMap.getFormMap().get("respon_leader"));
		}
		
		map.put("formMap",formMap.getFormMap());
//		return "worktask/wt_worktask_report_statistics";
		return this.platformType(request, "worktask/wt_worktask_report_statistics", "worktask/mobile/wt_worktask_report_statistics");
	}
	
	/**
	 * 
	 * @author twg
	 * @param formMap
	 * @param pagination
	 * @return
	 */
	@RequestMapping(value = "/otherReportForMobile")
	public String otherReportForMobile(HttpServletRequest request,HttpServletResponse response,ModelMap map,FormMap formMap,Pagination p){
		formMap.getFormMap().put("is_delete","N");
		//类型统计报表
		map.put("plist",this.wtWorktaskService.findScheduleEvaluate(formMap.getFormMap()));
		
		request.getSession().removeAttribute("respon_leader_mobile");
		if(StringUtils.isNotNull(formMap.getFormMap().get("respon_leader"))){
			request.getSession().setAttribute("respon_leader_mobile", formMap.getFormMap().get("respon_leader"));
		}
		
		HttpSession session = request.getSession();
		session.removeAttribute("fwfm_arr_start_time");
		session.removeAttribute("fwfm_arr_end_time");
		session.setAttribute("fwfm_arr_start_time", formMap.getFormMap().get("arr_start_time"));
		session.setAttribute("fwfm_arr_end_time", formMap.getFormMap().get("arr_end_time"));
		
		map.put("formMap",formMap.getFormMap());
		return this.platformType(request, "worktask/wt_worktask_report_statistics", "worktask/mobile/wt_worktask_report_statistics");
	}
	
//	/**
//	 * 事项报表输出页（旧版）
//	 * @author twg
//	 * @param formMap
//	 * @param pagination
//	 * @return
//	 */
//	@RequestMapping(value = "/reportResult")
//	public String reportResult(HttpServletRequest request,ModelMap map,FormMap formMap,Pagination p){
//		//部门任务
//		List<Map<String, Object>> deptTaskList = this.wtDeptTaskService.findByDeptId(formMap.getFormMap(),null);
//		//任务安排
//		List<Map<String, Object>> taskArrangeList = this.wtTaskArrangeService.findAll(formMap.getFormMap());
//		//阶段执行
//		formMap.getFormMap().put("approval_status","Y");
//		List<Map<String, Object>> taskExecutionList = this.wtTaskExecutionService.findAll(formMap.getFormMap());
//		if(deptTaskList != null && deptTaskList.size() > 0 && taskArrangeList != null && taskArrangeList.size() > 0
//				 && taskExecutionList != null && taskExecutionList.size() > 0){
//			List<Map<String, Object>> taList = null;
//			List<Map<String, Object>> teList = null;
//			for(Map<String, Object> deptTask : deptTaskList){//部门任务
//				taList = new ArrayList<Map<String, Object>>();
//				for(Map<String, Object> taskArrange : taskArrangeList){//任务分配
//					if(deptTask.get("worktask_id").toString().equals(taskArrange.get("worktask_id").toString())){
//						taList.add(taskArrange);
//					}
//					teList = new ArrayList<Map<String, Object>>();
//					for(Map<String, Object> taskExecution : taskExecutionList){//任务执行
//						if(taskArrange.get("task_arrange_id").toString().equals(taskExecution.get("task_arrange_id").toString())){
//							teList.add(taskExecution);
//						}
//					}
//					taskArrange.put("taskExecutionList", teList);
//				}
//				deptTask.put("taskArrangeList", taList);
//			}
//			map.put("deptTaskList", deptTaskList);
//		}
//		formMap.getFormMap().put("now_time",DateTimeUtils.getNowDate("yyyy-MM-dd HH:mm"));
//		map.put("formMap",formMap.getFormMap());
//		return "worktask/wt_worktask_report_detail";
//	}
	
	
	/**
	 * 进入事项详情报表页
	 * @author twg
	 * @param formMap
	 * @param pagination
	 * @return
	 */
	@SuppressWarnings({ "unchecked"})
	@RequestMapping(value = "/reportResult")
	public String reportResult(HttpServletRequest request,ModelMap map,FormMap formMap,Pagination p){
		this.loadData(map);
		if(StringUtils.isNotNull(formMap.getFormMap().get("wpt_type_id"))){
			this.paramMap.put("wpt_type_id",formMap.getFormMap().get("wpt_type_id"));
		}else{
			List<Map<String, Object>> projectTypeList = (List<Map<String, Object>>) map.get("projectTypeList");
			this.paramMap.put("wpt_type_id",projectTypeList.get(0).get("wpt_type_id"));
			formMap.getFormMap().put("wpt_type_id",projectTypeList.get(0).get("wpt_type_id"));
		}
		this.paramMap.put("dt_schedule_evaluate",formMap.getFormMap().get("dt_schedule_evaluate"));
		this.paramMap.put("start_time",formMap.getFormMap().get("start_time"));
		this.paramMap.put("end_time",formMap.getFormMap().get("start_time"));
//		//事项列表
//		this.paramMap.put("group_by","Y");
//		List<Map<String, Object>> worktaskList = this.wtDeptTaskService.findByDeptId(this.paramMap,null);
//		map.put("worktaskList", worktaskList);
//		//部门任务
//		this.paramMap.remove("group_by");
//		this.paramMap.remove("start_time");
//		this.paramMap.remove("end_time");
		if(StringUtils.isNotNull(formMap.getFormMap().get("login_user_id"))){
			this.paramMap.put("login_user_id",formMap.getFormMap().get("login_user_id"));
		}
		if(StringUtils.isNotNull(formMap.getFormMap().get("ds_submit_year"))
				&& (StringUtils.isNotNull(formMap.getFormMap().get("submit_month")) || StringUtils.isNotNull(formMap.getFormMap().get("submit_week")))){
			this.paramMap.put("ds_submit_year", formMap.getFormMap().get("ds_submit_year"));
			if(StringUtils.isNotNull(formMap.getFormMap().get("submit_month"))){
				this.paramMap.put("ds_submit_time", formMap.getFormMap().get("submit_month"));
				this.paramMap.put("submit_month", formMap.getFormMap().get("submit_month"));
			}else{
				this.paramMap.put("ds_submit_time", formMap.getFormMap().get("submit_week"));
				this.paramMap.put("submit_week", formMap.getFormMap().get("submit_week"));
			}
			map.put("search_mark", "Y");
			this.paramMap.put("group_by_ddti","Y");
		}
		this.paramMap.put("respon_leader", formMap.getFormMap().get("respon_leader"));
		List<Map<String, Object>> deptTaskList = this.wtDeptTaskService.findByDeptId(this.paramMap,p);
		map.put("deptTaskList", deptTaskList);
		map.put("formMap",formMap.getFormMap());
		
		NewsRemindUtil.setPageParam(map);
		return "worktask/wt_worktask_report_detail";
	}
	
}	