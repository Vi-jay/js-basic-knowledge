package com.qian.module.worktask.action;

import java.util.Date;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import com.gzdec.framework.page.Pagination;

import com.qian.module.worktask.service.inter.WtTemporarySaveService;
import com.qian.util.FormMap;
import com.qian.util.SessionUtil;
import com.qian.util.StringUtils;

/**
 * 描述：任务暂存管理
 * @author twg
 */
@Controller
@Scope("prototype")
@RequestMapping(value = "/pc/temporarysave")
public class WtTemporarySaveAction{
	
	@Autowired
	private WtTemporarySaveService wtTemporarySaveService;
	
	/**
	 * To enter list
	 * @author twg
	 * @param formMap
	 * @param pagination
	 * @return
	 */
	@RequestMapping(value = "/listByPage")
	public String listByPage(HttpServletRequest request,ModelMap map,FormMap formMap,Pagination p){
		List<Map<String, Object>> list =  this.wtTemporarySaveService.findByPage(formMap.getFormMap(), p);
		map.put("list",list);
		map.put("formMap",formMap.getFormMap());
		map.put("pagination",p);
		return "worktask/wt_temporary_save_list";
	}
	
	/**
	 * To enter edit
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/entryEdit")
	public String entryEdit(HttpServletRequest request,FormMap formMap,ModelMap map){
		map.put("data",this.wtTemporarySaveService.findById(formMap.getFormMap()));
		return "worktask/wt_temporary_save_edit";
	}
	
	/**
	 * Creating
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/create")
	public String create(HttpServletRequest request,FormMap formMap,ModelMap map) throws Exception{
		formMap.getFormMap().put("user_id",SessionUtil.getLoginUserId(request));
		formMap.getFormMap().put("execution_time",new Date());
		String result = this.wtTemporarySaveService.create(formMap.getFormMap());
		if(StringUtils.isNotNull(result)){
			request.getSession().setAttribute("result_msg","暂存成功");
		}
//		return "redirect:/pc/temporarysave/listByPage";
		return "redirect:/pc/taskarrange/entryEdit?formMap[task_arrange_id]="+formMap.getFormMap().get("task_arrange_id")+"&formMap[worktask_id]="+formMap.getFormMap().get("worktask_id")+"&formMap[dept_id]="+formMap.getFormMap().get("dept_id")+"&formMap[opt_mark]=mytask";
	}
	
	/**
	 * Modifing
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/modify")
	public String modify(HttpServletRequest request,FormMap formMap,ModelMap map) throws Exception{
		this.wtTemporarySaveService.modify(formMap.getFormMap());
		return "redirect:/pc/temporarysave/listByPage";
	}
	
	/**
	 * Deleting
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/delete")
	public String delete(HttpServletRequest request,FormMap formMap,ModelMap map) throws Exception{
		this.wtTemporarySaveService.remove(formMap.getFormMap());
		return "redirect:/pc/temporarysave/listByPage";
	}
	

	/**
	 * To enter view
	 * @author twg
	 * @param formMap
	 * @return
	 */
	@RequestMapping(value = "/entryView")
	public String entryView(HttpServletRequest request,FormMap formMap,ModelMap map){
		map.put("data",this.wtTemporarySaveService.findById(formMap.getFormMap()));
		return "worktask/wt_temporary_save_view";
	}

}	