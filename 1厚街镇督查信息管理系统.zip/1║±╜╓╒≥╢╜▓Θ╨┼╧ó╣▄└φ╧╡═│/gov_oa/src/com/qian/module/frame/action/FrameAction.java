package com.qian.module.frame.action;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.qian.module.common.action.BaseAction;
import com.qian.module.user.service.inter.SysUserService;
import com.qian.module.worktask.service.inter.WtDeptTaskService;
import com.qian.module.worktask.service.inter.WtProjectTypeService;
import com.qian.module.worktask.service.inter.WtTaskArrangeService;
import com.qian.module.worktask.service.inter.WtWorktaskService;
import com.qian.util.FormMap;
import com.qian.util.ListUtils;
import com.qian.util.SessionUtil;
import com.qian.util.StringUtils;
import com.gzdec.framework.page.Pagination;


/**
 * 
 * @author twg
 */
@Controller
@Scope("prototype")
@RequestMapping(value = "/pc/frame")
public class FrameAction extends BaseAction{
	
	@Autowired
	private SysUserService sysUserService;
	@Autowired
	private WtTaskArrangeService wtTaskArrangeService;
	@Autowired
	private WtDeptTaskService wtDeptTaskService;
	@Autowired
	private WtWorktaskService wtWorktaskService;
	@Autowired
	private WtProjectTypeService wtProjectTypeService;
	
	/**
	 * 首次进入框架页
	 * @return
	 */
	@RequestMapping(value = "/index")
	public String index(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map){
		
		return "frame/index";
	}
	
	/**
	 * 进入首页（移动网页端）
	 * @return
	 */
	@RequestMapping(value = "/mobileIndex")
	public String mobileIndex(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map){
		
		return "frame/mobile/index";
	}
	
	/**
	 * 加载顶部信息（顶部）
	 * @return
	 */
	@RequestMapping(value = "/top")
	public String top(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map){
		this.paramMap.put("user_id", SessionUtil.getLoginUserId(request));
		List<Map<String,Object>> list = this.sysUserService.findUserOtherInfo(this.paramMap, null);
		if(ListUtils.isNotNull(list)){
			if(StringUtils.isNotNull(list.get(0).get("role_names"))){
				String role_names = list.get(0).get("role_names").toString();
				String[] role_name = role_names.split(",");
				map.put("first_user_role_name", role_name[0]);
			}
		}
		return "frame/top";
	}
	
	/**
	 * 加载底部信息（底部）
	 * @return
	 */
	@RequestMapping(value = "/bottom")
	public String bottom(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map){
		
		return "frame/bottom";
	}
	
	@RequestMapping(value = "/topSeedlingField", method = RequestMethod.POST, produces = { "application/json;charset=UTF-8" })
	public  @ResponseBody Map<String, Object> topSeedlingField(HttpServletRequest request,FormMap formMap) throws IOException {
		Map<String,Object> resultMap = new HashMap<String,Object>();
		return resultMap;
	}
	
	/**
	 * 加载菜单信息（左边）
	 * @return
	 */
	@RequestMapping(value = "/left")
	public String left(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map){
		HashMap<String, Object> fm = new HashMap<String,Object>();
		fm.put("create_user", SessionUtil.getLoginUserId(request));
		fm.put("shelves", "O");
		return "frame/left";
	}
	
	/**
	 * 加载首页（右边）
	 * @return
	 */
	@RequestMapping(value = "/main")
	public String main(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map,Pagination p){
		p.setPageCount(5);
		try{
			//通知公告
			formMap.getFormMap().put("wpt_is_use","Y");
			formMap.getFormMap().put("wpt_file_type","B");
			List<Map<String, Object>> pt_list =  this.wtProjectTypeService.findByPage(formMap.getFormMap(), p);
			map.put("pt_list",pt_list);
			//我的任务
			formMap.getFormMap().put("user_id",SessionUtil.getLoginUserId(request));
			formMap.getFormMap().put("my_task_status","Y");
			List<Map<String, Object>> mytask_list =  this.wtTaskArrangeService.findMyWorkTask(formMap.getFormMap(),p);
			map.put("mytask_list",mytask_list);
			//任务分配
			formMap.getFormMap().clear();
			formMap.getFormMap().put("login_user_id",SessionUtil.getLoginUserId(request));
			formMap.getFormMap().put("dt_status","N");
			formMap.getFormMap().put("task_status","A");
			formMap.getFormMap().put("is_delete","N");
			List<Map<String, Object>> dt_list =  this.wtDeptTaskService.findByDeptId(formMap.getFormMap(), p);
			map.put("dt_list",dt_list);
			//阶段审核
			formMap.getFormMap().clear();
			formMap.getFormMap().put("is_delete","N");
			formMap.getFormMap().put("login_user_id",SessionUtil.getLoginUserId(request));
			formMap.getFormMap().put("approval_status","O");
			List<Map<String, Object>> approval_list =  this.wtWorktaskService.findDeptTask(formMap.getFormMap(), p);
			map.put("approval_list",approval_list);
		}catch(Exception e){
			map.put("link_list",new JSONArray());
		}
		return "frame/main";
	}
	
	/**
	 * 通讯录
	 * @return
	 */
	@RequestMapping(value = "mailList")
	public String mailList(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map,Pagination p){
		formMap.getFormMap().put("user_type","A");
		formMap.getFormMap().put("is_frozen","N");
		p.setPageCount(100);
//		List<Map<String, Object>> list =  this.sysUserService.findByPage(formMap.getFormMap(), p);
		List<Map<String, Object>> list =  this.sysUserService.findUserOtherInfo(formMap.getFormMap(), p);
		map.put("list",list);
		map.put("formMap",formMap.getFormMap());
		map.put("pagination",p);
		return "frame/mail_list";
	}
	
	/**
	 * 版本说明
	 * @param request
	 * @param response
	 * @param formMap
	 * @param map
	 * @param p
	 * @return
	 */
	@RequestMapping(value = "versionDescription")
	public String versionDescription(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map,Pagination p){
		return "frame/version_description";
	}
	
	/**
	 * 退出系统
	 * @return
	 */
	@RequestMapping(value = "exit")
	public String exit(HttpServletRequest request,FormMap formMap,ModelMap map){
		request.getSession().invalidate();
		if(StringUtils.isNotNull(formMap.getFormMap().get("platformType"))){
			return "redirect:/pc/system/mlogin";
		}else{
			return "redirect:/pc/system/entryLogin";
		}
	}
	
	
	/**
	 * 弹出常用地址链接编辑框
	 * @param request
	 * @param response
	 * @param formMap
	 * @param map
	 * @return
	 */
	@RequestMapping(value = "/commonLink")
	public String commonLink(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map){
		try{
			Map<String,Object> tempMap = new HashMap<String,Object>();
			tempMap.put("user_id", SessionUtil.getLoginUserId(request));
			Map<String,Object> userInfo = this.sysUserService.findById(tempMap);
			if(StringUtils.isNotNull(userInfo.get("user_email"))){
				map.put("link_list", JSONArray.parse(userInfo.get("user_email").toString()));
			}else{
				map.put("link_list",new JSONArray());	
			}
		}catch(Exception e){
			map.put("link_list",new JSONArray());
		}
		return "frame/common_link";
	}
	
	/**
	 * 保存常用链接
	 * @param request
	 * @param response
	 * @param formMap
	 * @param map
	 * @return
	 */
	@RequestMapping(value = "/createCommonLink")
	public String createCommonLink(HttpServletRequest request,HttpServletResponse response,FormMap formMap,ModelMap map){
		try{
			String[] titles = (String[]) formMap.getFormMap().get("title");
			String[] fNames = (String[]) formMap.getFormMap().get("f_name");
			String[] fUrls = (String[]) formMap.getFormMap().get("f_url");
			String[] sNames = (String[]) formMap.getFormMap().get("s_name");
			String[] sUrls = (String[]) formMap.getFormMap().get("s_url");
			JSONArray ja = new JSONArray();
			JSONObject obj = null;
			for(int i = 0;i<titles.length;i++){
				obj = new JSONObject();
				if(StringUtils.isNotNull(titles[i]) && StringUtils.isNotNull(fNames[i]) && StringUtils.isNotNull(fUrls[i])){
					obj.put("title",titles[i]);
					obj.put("f_name",fNames[i]);
					obj.put("f_url",fUrls[i]);
					obj.put("s_name",sNames[i]);
					obj.put("s_url",sUrls[i]);
				}else{
//					obj.put("title","—");
//					obj.put("f_name","—");
//					obj.put("f_url","javascript:void(0);");
//					obj.put("s_name","");
//					obj.put("s_url","javascript:void(0);");
				}
				ja.add(obj);
			}
			this.paramMap.put("user_id",SessionUtil.getLoginUserId(request));
			this.paramMap.put("user_email",ja.toJSONString());
			this.sysUserService.modify(this.paramMap);
		}catch(Exception e){
		}
		map.put("opt_status","OK");
		return "frame/common_link";
	}
	
}
